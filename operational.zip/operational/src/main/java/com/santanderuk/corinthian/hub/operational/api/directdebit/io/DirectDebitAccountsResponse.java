package com.santanderuk.corinthian.hub.operational.api.directdebit.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DirectDebitAccountsResponse extends ModelBase {
    private DirectDebitAccounts directDebitAccounts;
    private ServiceInfo info;
}

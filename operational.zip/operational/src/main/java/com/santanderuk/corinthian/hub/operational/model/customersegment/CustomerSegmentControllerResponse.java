package com.santanderuk.corinthian.hub.operational.model.customersegment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.commons.utilities.ServiceInfo;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Setter
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerSegmentControllerResponse extends ModelBase {

    private DataResponse dataResponse;
    private ServiceInfo info;
}


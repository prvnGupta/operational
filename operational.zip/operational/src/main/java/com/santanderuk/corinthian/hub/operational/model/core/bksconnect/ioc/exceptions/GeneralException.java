package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by C0232937 on 17/01/2017.
 **/
public class GeneralException extends Exception {
    private final String code;

    public GeneralException(String code, String message, Exception e) {
        // Constructor for creating the GeneralException based in any other exception
        super(message, e);
        this.code = code;
    }

    public GeneralException(String code, String message) {
        super(message);
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("code", code)
                .append("message", super.getMessage())
                .toString();
    }
}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities;


import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.commons.exceptions.business.ExcBusIoc;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * Created by C0229411 on 23/06/2017.
 **/

@Component
public class IOCConnection {
    private static final Logger log = LoggerFactory.getLogger(IOCConnection.class);
    private static final String CALLING_ENDPOINT = "Calling endpoint: {}";
    private static final String JSON_REQUEST = "JSON Request: {}";
    private static final String JSON_RESPONSE = "JSON Response -> {}";
    private static final String EXC_IOCCORE_CALL = "EXC_IOCCORE_CALL";
    private static final String JWT = "JWT: {}";
    private static final String AUTHORIZATION = "authorization";
    private static final String CARRIAGE_RETURN = "[\r\n]";
    private static final String STR_EMPTY = "";
    private static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";

    private RestTemplate restTemplate = new RestTemplate();

    @Cacheable(value = "operational-retrieve-mcc", key = "#retrieveMccControllerRequest", cacheManager = "cacheManagerLongLife")
    public RetrieveMccControllerResponse retrieveMcc(
            String serviceUrl,
            RetrieveMccControllerRequest retrieveMccControllerRequest,
            String jwtAuth, String clientId) throws GeneralException {

        ResponseEntity<RetrieveMccControllerResponse> responseEntity;

        log.info("retrieveMcc - > Adding JWT token to request headers");
        log.debug(JWT, jwtAuth.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(AUTHORIZATION, jwtAuth);
        headers.add(X_IBM_CLIENT_ID, clientId);
        HttpEntity httpEntity = new HttpEntity(retrieveMccControllerRequest, headers);


        try {
            log.info("retrieveMcc - > Calling RetrieveMcc IOC Core microservice: ");
            log.debug(CALLING_ENDPOINT, serviceUrl.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.debug(JSON_REQUEST, retrieveMccControllerRequest.toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            responseEntity = restTemplate.postForEntity(
                    serviceUrl,
                    httpEntity,
                    RetrieveMccControllerResponse.class
            );
            log.debug(JSON_RESPONSE, responseEntity.getBody().toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.info("retrieveMcc - > RetrieveMcc IOC Core microservice: Response received ");
        } catch (Exception e) {
            log.error("retrieveMcc - > Error while connecting to  RetrieveMcc IOC Core microservice");
            log.error(e.getMessage());
            throw new GeneralException(EXC_IOCCORE_CALL, "An error occurred while calling RetrieveMcc from LDAP User service", e);
        }

        HttpStatus httpStatus = responseEntity.getStatusCode();
        if (httpStatus != HttpStatus.OK) {
            log.error("IOC retrieveMcc microservice response KO.  Response Status: {}", httpStatus);
            throw new ExcBusIoc();
        }

        return responseEntity.getBody();

    }

    @Cacheable(value = "operational-retrieve-mcc-info", key = "#retrieveMccInfoControllerRequest", cacheManager = "cacheManagerLongLife")
    public RetrieveMccInfoControllerResponse retrieveMccInfo(String serviceUrl, RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest, String jwtAuth, String clientId) throws GeneralException {

        ResponseEntity<RetrieveMccInfoControllerResponse> responseEntity;
        log.info("retrieveMccInfo - > Adding JWT token to request headers");
        log.debug(JWT, jwtAuth.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(AUTHORIZATION, jwtAuth);
        headers.add(X_IBM_CLIENT_ID, clientId);
        HttpEntity httpEntity = new HttpEntity(retrieveMccInfoControllerRequest, headers);


        try {
            log.info("retrieveMccInfo - > Calling RetrieveMccInfo IOC Core microservice: ");
            log.debug(CALLING_ENDPOINT, serviceUrl.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.debug(JSON_REQUEST, retrieveMccInfoControllerRequest.toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            responseEntity = restTemplate.postForEntity(
                    serviceUrl,
                    httpEntity,
                    RetrieveMccInfoControllerResponse.class
            );
            log.debug(JSON_RESPONSE, responseEntity.getBody().toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.info("retrieveMccInfo - > RetrieveMcc IOC Core microservice: Response received ");
        } catch (Exception e) {
            log.error("retrieveMccInfo - > Error while connecting to  RetrieveMccInfo IOC Core microservice");
            throw new GeneralException(EXC_IOCCORE_CALL, "An error occurred while calling RetrieveMccInfo", e);
        }

        HttpStatus httpStatus = responseEntity.getStatusCode();
        if (httpStatus != HttpStatus.OK) {
            log.error("IOC retrieveMccInfo microservice response KO. Response Status: {}", httpStatus);
            throw new ExcBusIoc();
        }
        return responseEntity.getBody();

    }

    @Cacheable(value = "operational-contracts-in-mcc", key = "#contractsInMccControllerRequest", cacheManager = "cacheManagerLongLife")
    public ContractsInMccControllerResponse contractsInMcc(String serviceUrl, ContractsInMccControllerRequest contractsInMccControllerRequest, String jwtAuth, String clientId) throws GeneralException {

        ResponseEntity<ContractsInMccControllerResponse> responseEntity;

        log.info("ContractsIneMcc - > Adding JWT token to request headers");
        log.debug(JWT, jwtAuth.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(AUTHORIZATION, jwtAuth);
        headers.add(X_IBM_CLIENT_ID, clientId);
        HttpEntity httpEntity = new HttpEntity(contractsInMccControllerRequest, headers);


        try {
            log.info("ContractsInMcc - > Calling ContractsInMcc IOC Core microservice");
            log.debug(CALLING_ENDPOINT, serviceUrl.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.debug(JSON_REQUEST, contractsInMccControllerRequest.toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            responseEntity = restTemplate.postForEntity(
                    serviceUrl,
                    httpEntity,
                    ContractsInMccControllerResponse.class
            );
            log.debug(JSON_RESPONSE, responseEntity.getBody().toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.info("ContractsInMcc - > ContractsInMcc IOC Core microservice: Response received ");
        } catch (Exception e) {
            log.error("ContractsInMcc - > Error while connecting to  ContractsInMcc IOC Core microservice");
            throw new GeneralException(EXC_IOCCORE_CALL, "An error occurred while calling ContractsInMcc service", e);
        }

        HttpStatus httpStatus = responseEntity.getStatusCode();
        if (httpStatus != HttpStatus.OK) {
            log.error("IOC ContractsInMcc microservice response KO.  Response Status: {}", httpStatus);
            throw new ExcBusIoc();
        }

        return responseEntity.getBody();

    }


}

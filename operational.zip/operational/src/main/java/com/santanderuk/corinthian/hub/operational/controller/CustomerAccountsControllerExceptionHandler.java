package com.santanderuk.corinthian.hub.operational.controller;

import com.santanderuk.corinthian.hub.commons.utilities.ServiceInfo;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.CustomerAccountsControllerResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CustomerAccountsControllerExceptionHandler {

    @ExceptionHandler(ConnectionException.class)
    public ResponseEntity<CustomerAccountsControllerResponse> handleConnectionException(ConnectionException e) {
        CustomerAccountsControllerResponse response = new CustomerAccountsControllerResponse();
        ServiceInfo info = new ServiceInfo("ko", e.getCode(), e.getMessage());
        response.setInfo(info);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ValidationsException.class)
    public ResponseEntity<CustomerAccountsControllerResponse> handleValidationsException(ValidationsException e) {
        CustomerAccountsControllerResponse response = new CustomerAccountsControllerResponse();
        ServiceInfo info = new ServiceInfo("ko", e.getCode(), e.getMessage());
        response.setInfo(info);
        return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

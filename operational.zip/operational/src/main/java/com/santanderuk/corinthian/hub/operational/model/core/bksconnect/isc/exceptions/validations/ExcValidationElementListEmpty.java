package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.validations;


import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.GeneralException;

/**
 * Created by C0229411 on 12/09/2017.
 **/

public class ExcValidationElementListEmpty extends GeneralException {
    public ExcValidationElementListEmpty() {
        super(
                ExceptionValidationEnum.EXC_VAL_ELEMENTLIST_EMPTY.getErrorCode(),
                ExceptionValidationEnum.EXC_VAL_ELEMENTLIST_EMPTY.getErrorMessage()
        );
    }

    @Override
    public String toString() {
        return super.toString();
    }
}

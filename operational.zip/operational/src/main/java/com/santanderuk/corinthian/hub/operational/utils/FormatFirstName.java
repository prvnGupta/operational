package com.santanderuk.corinthian.hub.operational.utils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Locale;

@Component
public class FormatFirstName {

    public String formatFirstName(String firstName) {
        try {
            String toLowerCase = firstName.toLowerCase(Locale.ROOT);
            String capitalized;
            if (toLowerCase.contains("-")) {
                StringBuilder stringBuilder = new StringBuilder();
                String[] parts = toLowerCase.split("-");
                for (String part : parts) {
                    stringBuilder.append(StringUtils.capitalize(part)).append('-');
                }
                capitalized = StringUtils.removeEnd(stringBuilder.toString(), "-");
            } else {
                capitalized = StringUtils.capitalize(toLowerCase);
            }
            return capitalized;
        } catch (Exception e) {
            return "";
        }
    }
}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.validations;


import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.BdpCustomer;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Profile;

/**
 * Created by C0232937 on 16/01/2017. PROJECT: simulations
 **/

public class Validations {

    public static final String FOUR_DIGITS = "[0-9]{4}";
    public static final String THREE_DIGITS = "[0-9]{3}";
    public static final String SEVEN_DIGITS = "[0-9]{7}";

    private Validations() {
    }

    public static boolean isPartenonContract(PartenonContract partenonContract) {
        return
                // Check if null
                partenonContract != null
                        && partenonContract.getCentre().getCompany() != null
                        // Check if matches
                        && partenonContract.getCentre().getCompany().matches(FOUR_DIGITS)
                        && (partenonContract.getCentre().getCentreCode() == null
                        || partenonContract.getCentre().getCentreCode().equalsIgnoreCase("")
                        || partenonContract.getCentre().getCentreCode().matches(FOUR_DIGITS))
                        && (partenonContract.getProductTypeCode() == null
                        || partenonContract.getProductTypeCode().equalsIgnoreCase("")
                        || partenonContract.getProductTypeCode().matches(THREE_DIGITS))
                        && (partenonContract.getContractNumber() == null
                        || partenonContract.getContractNumber().equalsIgnoreCase("")
                        || partenonContract.getContractNumber().matches(SEVEN_DIGITS));
    }

    public static boolean isChannel(String channel) {
        return channel == null || channel.equalsIgnoreCase("") || channel.matches("[a-zA-Z0-9]{3}");
    }

    public static boolean isProfile(Profile profile) {
        return profile == null
                || ((profile.getChannel() == null || profile.getChannel().equalsIgnoreCase("") || profile.getChannel().matches("[a-zA-Z0-9]{3}"))
                && (profile.getCompany() == null || profile.getCompany().equalsIgnoreCase("") || profile.getCompany().matches(FOUR_DIGITS)));
    }

    public static boolean isCompany(String company) {
        return company == null
                || company.equalsIgnoreCase("")
                || company.matches(FOUR_DIGITS);
    }

    public static boolean isOperation(String operation) {
        return operation == null
                || operation.equalsIgnoreCase("")
                || operation.matches("[a-zA-Z0-9]{1}");
    }

    public static boolean isBdpCustomer(BdpCustomer bdpCustomer) {
        return bdpCustomer == null
                || (
                (bdpCustomer.getBdpCustomertype() == null || bdpCustomer.getBdpCustomertype().equalsIgnoreCase("") || bdpCustomer.getBdpCustomertype().matches("[F|J]{1}"))
                        && (String.valueOf(bdpCustomer.getBdpCustomerCode()) == null || String.valueOf(bdpCustomer.getBdpCustomerCode()).matches("[0-9]{1,9}"))
        );
    }
}

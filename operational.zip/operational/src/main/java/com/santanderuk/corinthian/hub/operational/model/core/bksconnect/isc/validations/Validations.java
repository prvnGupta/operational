package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.validations;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.BdpCustomer;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.Cesta;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.ProductSubtype;

/**
 * Created by C0229411 on 12/09/2017.
 **/

public class Validations {
    public static final String FOUR_DIGITS = "[0-9]{4}";
    public static final String THREE_DIGITS = "[0-9]{3}";
    public static final String SEVEN_DIGITS = "[0-9]{7}";

    private Validations() {
    }

    public static boolean isBdpCustomerType(String bdpCustomerType) {
        return bdpCustomerType != null && bdpCustomerType.matches("[F|J]");
    }

    public static boolean isBdpCustomerNumber(String bdpCustomerNumber) {
        return bdpCustomerNumber != null && bdpCustomerNumber.matches("[0-9]{1,9}") && Integer.parseInt(bdpCustomerNumber) != 0;
    }

    public static boolean isCesta(Cesta cesta) {
        return cesta != null && cesta.getCestaCompany().matches(FOUR_DIGITS) && cesta.getCestaCode().matches("[a-zA-Z0-9]{1,4}");
    }

    public static boolean isPartenonContract(PartenonContract partenonContract) {
        return
                // Check if null
                partenonContract != null
                        && partenonContract.getCentre() != null
                        && partenonContract.getContractNumber() != null
                        && partenonContract.getProductTypeCode() != null
                        && partenonContract.getCentre().getCentreCode() != null
                        && partenonContract.getCentre().getCompany() != null
                        // Check if matches
                        && partenonContract.getCentre().getCompany().matches(FOUR_DIGITS)
                        && partenonContract.getCentre().getCentreCode().matches(FOUR_DIGITS)
                        && partenonContract.getProductTypeCode().matches(THREE_DIGITS)
                        && partenonContract.getContractNumber().matches(SEVEN_DIGITS);
    }

    public static boolean isProductSubtype(ProductSubtype productSubtype) {
        return productSubtype == null || (productSubtype.getProductType().getProductTypeCode().matches(THREE_DIGITS)
                && productSubtype.getProductType().getCompany().matches(FOUR_DIGITS)
                && productSubtype.getProductSubtypeCode().matches(THREE_DIGITS));
    }

    public static boolean isCompany(String company) {
        return company.matches(FOUR_DIGITS);
    }

    public static boolean isChannel(String channel) {
        return channel == null || channel.matches("[a-zA-Z0-9]{3}");
    }

    public static boolean isBdpCustomer(BdpCustomer bdpCustomer) {
        return isBdpCustomerType(bdpCustomer.getBdpCustomertype()) && isBdpCustomerNumber(bdpCustomer.getBdpCustomerCode());
    }
}

package com.santanderuk.corinthian.hub.operational.api.directdebit.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class DirectDebitAccounts extends ModelBase {
    private List<Account> accounts;
}

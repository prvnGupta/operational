package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.business;


import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.GeneralException;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by C0229411 on 23/06/2017.
 **/

public class ExcBusIsc extends GeneralException {

    public static final String EXC_BUS_ISC_CODE = "EXC_BUS_ISC";
    public static final String EXC_BUS_ISC_MSG = "Error detected in ISC response";

    public ExcBusIsc() {
        super(
                EXC_BUS_ISC_CODE,
                EXC_BUS_ISC_MSG
        );
    }

    public ExcBusIsc(String message) {
        super(
                EXC_BUS_ISC_CODE,
                message
        );
    }

    public ExcBusIsc(Exception e) {
        super(
                EXC_BUS_ISC_CODE,
                EXC_BUS_ISC_MSG,
                e
        );
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("code", EXC_BUS_ISC_CODE)
                .append("message", EXC_BUS_ISC_MSG)
                .toString();
    }
}

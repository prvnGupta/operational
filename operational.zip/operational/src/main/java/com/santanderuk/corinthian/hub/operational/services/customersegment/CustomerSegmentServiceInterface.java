package com.santanderuk.corinthian.hub.operational.services.customersegment;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.customersegment.DataResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;


public interface CustomerSegmentServiceInterface {
    DataResponse getCustomerSegment(String ldapUid, String jwtToken) throws GeneralException, ConnectionException;
}

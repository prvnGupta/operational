package com.santanderuk.corinthian.hub.operational.services.customeraccounts;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.DataResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;

/**
 * Created by C0229411 on 14/06/2017.
 **/
public interface CustomerAccountsServiceInterface {
    DataResponse getCustomerAccounts(String ldapUid, String jwtAuth) throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException;
}

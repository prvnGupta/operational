package com.santanderuk.corinthian.hub.operational.uidverifier;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.commons.exceptions.security.AuthorizationException;
import com.santanderuk.corinthian.hub.commons.utilities.JwtUtilities;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;

@Slf4j
public class UidVerifier {

    private static final String CARRIAGE_RETURN = "[\r\n]";
    private static final String STR_EMPTY = "";
    private static UidVerifier instance;

    private UidVerifier() {

    }

    public static synchronized UidVerifier getInstance() {

        if (instance == null) {
            instance = new UidVerifier();
        }
        return instance;
    }


    public void verify(String jwtToken, @NotNull String uid) throws AuthorizationException {

        try {
            if (!JwtUtilities.getLdapUidFromJWT(jwtToken).equalsIgnoreCase(uid)) {
                log.error("UID seems to be tampered - UID has been unauthorised to continue with the operation");
                throw new AuthorizationException();
            }
        } catch (GeneralException e) {
            log.error("Unable to parse Jwt");
            throw new AuthorizationException();
        }
        log.debug("UID {} has been authorised to continue with the operation", uid.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
    }

}

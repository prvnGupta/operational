package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "countryCode",
        "checkDigits",
        "accNumber"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Iban implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("countryCode")
    private String countryCode;
    @JsonProperty("checkDigits")
    private String checkDigits;
    @JsonProperty("accNumber")
    private String accNumber;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("countryCode", countryCode)
                .append("checkDigits", checkDigits)
                .append("accNumber", accNumber)
                .toString();
    }
}

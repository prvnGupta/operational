package com.santanderuk.corinthian.hub.operational.api.directdebit;

import com.santanderuk.corinthian.hub.operational.api.directdebit.io.Account;
import com.santanderuk.corinthian.hub.operational.api.directdebit.io.DirectDebitAccounts;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.clients.directdebit.io.InternalAccountsResponse;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Component
public class DirectDebitAccountsMapper {

    public DirectDebitAccounts mapDirectDebitAccounts(InternalAccountsResponse directDebitAccounts, AccountBalancesResponse balancesResponse) {
        DirectDebitAccounts accounts = new DirectDebitAccounts();
        List<Account> arrayList = new ArrayList<>();
        balancesResponse.getAccountBalances().forEach(accountBalance -> {
            com.santanderuk.corinthian.services.commons.clients.directdebit.io.Account matchedAccount = directDebitAccounts.getAccounts().stream().filter(account -> account.getPartenonContract().equals(accountBalance.getPartenonContractId())).findFirst().get();
            Account account = new Account();
            account.setAlias(matchedAccount.getAlias());
            account.setCurrency(matchedAccount.getCurrency());
            account.setSortCode(matchedAccount.getSortCode());
            account.setAccountNumber(matchedAccount.getLocalNumber());
            account.setBalance(convertToBigDecimal(accountBalance.getAvailableBalance()));
            account.setBalanceIncPending(convertToBigDecimal(accountBalance.getBalanceIncPending()));
            arrayList.add(account);
        });
        accounts.setAccounts(arrayList);
        return accounts;
    }

    private BigDecimal convertToBigDecimal(String amount) {
        if (null == amount) {
            return BigDecimal.ZERO;
        } else {
            String sanitisedString = amount.replace(",", "");
            String[] split = sanitisedString.split(" ");
            if (split[1].equalsIgnoreCase("c")) {
                return new BigDecimal(split[0]);
            } else {
                return new BigDecimal("-" + split[0]);
            }
        }
    }
}

package com.santanderuk.corinthian.hub.operational;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/**
 * Created by C0232937 on 19/05/2017.
 */
@SpringBootApplication
@EnableCaching
public class OperationalApplication {
    public static void main(String[] args) {
        SpringApplication.run(OperationalApplication.class, args);
    }
}

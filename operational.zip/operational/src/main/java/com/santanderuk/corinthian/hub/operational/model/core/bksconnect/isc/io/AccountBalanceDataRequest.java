package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "elementList",
        "company",
        "bdpCustomer",
        "channel"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AccountBalanceDataRequest {

    @JsonProperty("elementList")
    private ElementList elementList;
    @JsonProperty("company")
    private String company;
    @JsonProperty("bdpCustomer")
    private BdpCustomer bdpCustomer;
    @JsonProperty("channel")
    private String channel;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("elementList", elementList)
                .append("company", company)
                .append("bdpCustomer", bdpCustomer)
                .append("channel", channel)
                .toString();
    }
}

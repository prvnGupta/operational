package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "codError",
        "descError",
        "next",
        "nextTRX"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class KcError implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("codError")
    private String codError;
    @JsonProperty("descError")
    private String descError;
    @JsonProperty("next")
    private String next;
    @JsonProperty("nextTRX")
    private String nextTRX;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("codError", codError)
                .append("descError", descError)
                .append("next", next)
                .append("nextTRX", nextTRX)
                .toString();
    }
}

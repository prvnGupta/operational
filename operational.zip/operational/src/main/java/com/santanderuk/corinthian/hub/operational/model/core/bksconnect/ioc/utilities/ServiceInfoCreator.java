package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.ServiceInfo;

/**
 * Created by C0232937 on 17/01/2017.
 */
public class ServiceInfoCreator {
    private ServiceInfoCreator() {
    }

    public static ServiceInfo ok() {
        return new ServiceInfo("ok", "", "Data found");
    }

    public static ServiceInfo exception(GeneralException e) {
        return new ServiceInfo("ko", e.getCode(), e.getMessage());
    }
}

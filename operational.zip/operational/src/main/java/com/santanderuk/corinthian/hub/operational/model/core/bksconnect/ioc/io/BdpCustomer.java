package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "bdpCustomertype",
        "bdpCustomerCode"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BdpCustomer implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("bdpCustomertype")
    private String bdpCustomertype;
    @JsonProperty("bdpCustomerCode")
    private int bdpCustomerCode;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("bdpCustomertype", bdpCustomertype)
                .append("bdpCustomerCode", bdpCustomerCode)
                .toString();
    }
}

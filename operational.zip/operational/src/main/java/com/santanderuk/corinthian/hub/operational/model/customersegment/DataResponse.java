package com.santanderuk.corinthian.hub.operational.model.customersegment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DataResponse extends ModelBase {

    private String firstName;
    private String lastName;
    private String segmentCode;
    private String segmentName;
}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.BdpCustomer;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Cesta;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Profile;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "profile",
        "operation",
        "conexionChannel",
        "electronicChannel",
        "personalizationChannel",
        "reposCardPan",
        "cesta",
        "reposCesta",
        "bdpCustomer",
        "mccPartenonContract",
        "reposPartenonContract",
        "company",
        "service",
        "reposPresOrder"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Input implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("profile")
    private Profile profile;
    @JsonProperty("operation")
    private String operation;
    @JsonProperty("conexionChannel")
    private String conexionChannel;
    @JsonProperty("electronicChannel")
    private String electronicChannel;
    @JsonProperty("personalizationChannel")
    private String personalizationChannel;
    @JsonProperty("reposCardPan")
    private String reposCardPan;
    @JsonProperty("cesta")
    private Cesta cesta;
    @JsonProperty("reposCesta")
    private Cesta reposCesta;
    @JsonProperty("bdpCustomer")
    private BdpCustomer bdpCustomer;
    @JsonProperty("mccPartenonContract")
    private PartenonContract mccPartenonContract;
    @JsonProperty("reposPartenonContract")
    private PartenonContract reposPartenonContract;
    @JsonProperty("company")
    private String company;
    @JsonProperty("service")
    private String service;
    @JsonProperty("reposPresOrder")
    private Integer reposPresOrder;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("profile", profile)
                .append("operation", operation)
                .append("conexionChannel", conexionChannel)
                .append("electronicChannel", electronicChannel)
                .append("personalizationChannel", personalizationChannel)
                .append("reposCardPan", reposCardPan)
                .append("cesta", cesta)
                .append("reposCesta", reposCesta)
                .append("bdpCustomer", bdpCustomer)
                .append("mccPartenonContract", mccPartenonContract)
                .append("reposPartenonContract", reposPartenonContract)
                .append("company", company)
                .append("service", service)
                .append("reposPresOrder", reposPresOrder)
                .toString();
    }
}

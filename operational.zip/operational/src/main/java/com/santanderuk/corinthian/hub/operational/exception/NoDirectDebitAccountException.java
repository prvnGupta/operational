package com.santanderuk.corinthian.hub.operational.exception;

import lombok.Getter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

@Getter
public class NoDirectDebitAccountException extends Exception {

    private final String code;

    public NoDirectDebitAccountException(String code, String message) {
        super(message);
        this.code = code;
    }

    public String toString() {
        return (new ToStringBuilder(this, ToStringStyle.JSON_STYLE)).append("code", this.code).append("message", super.getMessage()).toString();
    }
}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "partenonContract",
        "productSubtype",
        "balance1",
        "balance2",
        "limit",
        "return",
        "cesta",
        "contractStatus"
})
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OutElement implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("partenonContract")
    private PartenonContract partenonContract;
    @JsonProperty("productSubtype")
    private ProductSubtype productSubtype;
    @JsonProperty("balance1")
    private Balance1 balance1;
    @JsonProperty("balance2")
    private Balance2 balance2;
    @JsonProperty("limit")
    private Limit limit;
    @JsonProperty("return")
    private String outReturn;
    @JsonProperty("cesta")
    private Cesta cesta;
    @JsonProperty("contractStatus")
    private String contractStatus;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("partenonContract", partenonContract)
                .append("productSubtype", productSubtype)
                .append("balance1", balance1)
                .append("balance2", balance2)
                .append("limit", limit)
                .append("return", outReturn)
                .append("cesta", cesta)
                .append("contractStatus", contractStatus)
                .toString();
    }
}

package com.santanderuk.corinthian.hub.operational.api.directdebit;

import com.santanderuk.corinthian.hub.commons.exceptions.security.AuthorizationException;
import com.santanderuk.corinthian.hub.operational.api.directdebit.io.DirectDebitAccounts;
import com.santanderuk.corinthian.hub.operational.api.directdebit.io.DirectDebitAccountsResponse;
import com.santanderuk.corinthian.hub.operational.exception.NoDirectDebitAccountException;
import com.santanderuk.corinthian.hub.operational.uidverifier.UidVerifier;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class DirectDebitAccountsController {

    private final DirectDebitAccountsService service;

    public DirectDebitAccountsController(DirectDebitAccountsService service) {
        this.service = service;
    }

    @ApiOperation("Endpoint to get the direct-debit eligible internal accounts")
    @GetMapping(path = "/{ldapUid}/direct-debit-internal-accounts", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DirectDebitAccountsResponse> directDebitAccounts(@RequestHeader(name = "authorization") String jwtToken, @PathVariable(value = "ldapUid") String ldapUid) throws AuthorizationException, GeneralException, NoDirectDebitAccountException {
        log.info("ldapUid: {}, /{ldapUid} received.", ldapUid.replaceAll("[\r\n]",""));
        log.debug("JwtToken: {}", jwtToken.replaceAll("[\r\n]", ""));

        UidVerifier.getInstance().verify(jwtToken, ldapUid);

        DirectDebitAccounts accounts = service.getDirectDebitAccounts(ldapUid);

        return new ResponseEntity<>(createResponseWrapper(accounts), HttpStatus.OK);
    }

    private DirectDebitAccountsResponse createResponseWrapper(DirectDebitAccounts accounts) {
        DirectDebitAccountsResponse response = new DirectDebitAccountsResponse();
        response.setInfo(ServiceInfoCreator.ok());
        response.setDirectDebitAccounts(accounts);
        log.debug(response.toString());
        return response;
    }

    @ExceptionHandler(AuthorizationException.class)
    private ResponseEntity<DirectDebitAccountsResponse> handlingConnectionExc(final AuthorizationException unauthorized) {
        final DirectDebitAccountsResponse wrapper = new DirectDebitAccountsResponse();
        ServiceInfo info = ServiceInfoCreator.exception(unauthorized);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(NoDirectDebitAccountException.class)
    private ResponseEntity<DirectDebitAccountsResponse> handlingNoDirectDebitAccountExc(final NoDirectDebitAccountException noAccounts) {
        final DirectDebitAccountsResponse wrapper = new DirectDebitAccountsResponse();
        ServiceInfo info = ServiceInfoCreator.exception(noAccounts);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.OK);
    }

    @ExceptionHandler(GeneralException.class)
    private ResponseEntity<DirectDebitAccountsResponse> handlingGeneralException(final GeneralException generalExc) {
        final DirectDebitAccountsResponse wrapper = new DirectDebitAccountsResponse();
        ServiceInfo info = ServiceInfoCreator.exception(generalExc);
        wrapper.setInfo(info);
        return new ResponseEntity<>(wrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}

package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.commons.exceptions.validations.ExcValidationLdapUidEmpty;
import com.santanderuk.corinthian.hub.commons.validations.Validations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by C0232937 on 22/05/2017.
 **/

public class OperationalIocDataValidation {

    private static final Logger log = LoggerFactory.getLogger(OperationalIocDataValidation.class);

    private OperationalIocDataValidation() {
        //default constructor to prevent instance creation
    }

    public static void validate(String ldapUid) throws GeneralException {

        if (Validations.isLdapUidEmpty(ldapUid)) {
            log.error("Error validating ldapUid.");
            throw new ExcValidationLdapUidEmpty();
        }
    }
}

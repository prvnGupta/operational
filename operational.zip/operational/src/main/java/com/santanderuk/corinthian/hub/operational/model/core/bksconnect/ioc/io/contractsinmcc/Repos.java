package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Cesta;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "reposCesta",
        "reposPartenonContract",
        "reposPresOrder",
        "reposCardPan"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Repos implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("reposCesta")
    private Cesta reposCesta;
    @JsonProperty("reposPartenonContract")
    private PartenonContract reposPartenonContract;
    @JsonProperty("reposPresOrder")
    private int reposPresOrder;
    @JsonProperty("reposCardPan")
    private String reposCardPan;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("reposCesta", reposCesta)
                .append("reposPartenonContract", reposPartenonContract)
                .append("reposPresOrder", reposPresOrder)
                .append("reposCardPan", reposCardPan)
                .toString();
    }
}

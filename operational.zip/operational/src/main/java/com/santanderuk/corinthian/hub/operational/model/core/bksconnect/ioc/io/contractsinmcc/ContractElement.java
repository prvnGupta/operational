package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Cesta;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.ProductSubtype;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.xml.datatype.XMLGregorianCalendar;
import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "endDate",
        "alias",
        "cardPan",
        "outCesta",
        "productSubtype",
        "contractDetails",
        "intervinientInd",
        "relationInd",
        "statusIndicator",
        "presOrder",
        "interventionType",
        "intervinientQuality",
        "cardCaducity",
        "pcasConcept",
        "subTypeName",
        "interventionForm"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContractElement implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("endDate")
    private XMLGregorianCalendar endDate;
    @JsonProperty("alias")
    private String alias;
    @JsonProperty("cardPan")
    private String cardPan;
    @JsonProperty("outCesta")
    private Cesta outCesta;
    @JsonProperty("productSubtype")
    private ProductSubtype productSubtype;
    @JsonProperty("contractDetails")
    private ContractDetails contractDetails;
    @JsonProperty("intervinientInd")
    private String intervinientInd;
    @JsonProperty("relationInd")
    private String relationInd;
    @JsonProperty("statusIndicator")
    private String statusIndicator;
    @JsonProperty("presOrder")
    private Integer presOrder;
    @JsonProperty("interventionType")
    private String interventionType;
    @JsonProperty("intervinientQuality")
    private String intervinientQuality;
    @JsonProperty("cardCaducity")
    private Integer cardCaducity;
    @JsonProperty("pcasConcept")
    private PcasConcept pcasConcept;
    @JsonProperty("subTypeName")
    private String subTypeName;
    @JsonProperty("interventionForm")
    private String interventionForm;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("endDate", endDate)
                .append("alias", alias)
                .append("cardPan", cardPan)
                .append("outCesta", outCesta)
                .append("productSubtype", productSubtype)
                .append("contractDetails", contractDetails)
                .append("intervinientInd", intervinientInd)
                .append("relationInd", relationInd)
                .append("statusIndicator", statusIndicator)
                .append("presOrder", presOrder)
                .append("interventionType", interventionType)
                .append("intervinientQuality", intervinientQuality)
                .append("cardCaducity", cardCaducity)
                .append("pcasConcept", pcasConcept)
                .append("subTypeName", subTypeName)
                .append("interventionForm", interventionForm)
                .toString();
    }
}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.KcError2;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.OperativeSecurity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "operativeSecurityOutput",
        "kcError",
        "listEnd",
        "repos",
        "dataList",
        "mccAccessType",
        "mccType"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContractsInMccDataResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("operativeSecurityOutput")
    private OperativeSecurity operativeSecurityOutput;
    @JsonProperty("kcError")
    private KcError2 kcError;
    @JsonProperty("listEnd")
    private String listEnd;
    @JsonProperty("repos")
    private Repos repos;
    @JsonProperty("dataList")
    private DataList dataList;
    @JsonProperty("mccAccessType")
    private MccAccessType mccAccessType;
    @JsonProperty("mccType")
    private String mccType;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("operativeSecurityOutput", operativeSecurityOutput)
                .append("kcError", kcError)
                .append("listEnd", listEnd)
                .append("repos", repos)
                .append("dataList", dataList)
                .append("mccAccessType", mccAccessType)
                .append("mccType", mccType)
                .toString();
    }
}

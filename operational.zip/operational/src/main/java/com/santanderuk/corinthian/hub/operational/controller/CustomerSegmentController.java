package com.santanderuk.corinthian.hub.operational.controller;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.commons.exceptions.security.AuthorizationException;
import com.santanderuk.corinthian.hub.commons.utilities.ServiceInfo;
import com.santanderuk.corinthian.hub.commons.utilities.ServiceInfoCreator;
import com.santanderuk.corinthian.hub.operational.model.customersegment.CustomerSegmentControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.customersegment.DataResponse;
import com.santanderuk.corinthian.hub.operational.services.customersegment.CustomerSegmentServiceInterface;
import com.santanderuk.corinthian.hub.operational.uidverifier.UidVerifier;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
public class CustomerSegmentController {
    private static final String CARRIAGE_RETURN = "[\r\n]";
    private static final String STR_EMPTY = "";
    @Autowired
    public CustomerSegmentServiceInterface customerSegmentService;

    @ApiOperation("Endpoint used to get the segment for a used id. In case of any error it return Personal Banking (PD)")
    @RequestMapping(
            path = "/customer/{ldapuid}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CustomerSegmentControllerResponse> getCustomerSegment(@RequestHeader(name = "authorization", required = true) String jwtToken, @PathVariable(value = "ldapuid") String ldapUid) throws ConnectionException {
        log.info("CustomerSegmentController Request received:");
        log.debug("Request ldapUid: {}", ldapUid.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
        log.debug("Request jwtToken: {}", jwtToken.replaceAll(CARRIAGE_RETURN, STR_EMPTY));

        CustomerSegmentControllerResponse customerSegmentControllerResponse = new CustomerSegmentControllerResponse();
        HttpStatus httpStatus;
        DataResponse dataResponse = new DataResponse();
        try {
            UidVerifier.getInstance().verify(jwtToken, ldapUid);
            dataResponse = customerSegmentService.getCustomerSegment(ldapUid, jwtToken);
            ServiceInfo serviceInfo = new ServiceInfo("200", "", "");
            httpStatus = HttpStatus.OK;
            customerSegmentControllerResponse.setInfo(serviceInfo);
            customerSegmentControllerResponse.setDataResponse(dataResponse);
        } catch (AuthorizationException ae) {
            log.error("Operative Security exception");
            httpStatus = HttpStatus.UNAUTHORIZED;
            ServiceInfo serviceInfo = ServiceInfoCreator.exception(ae);
            customerSegmentControllerResponse.setInfo(serviceInfo);
            dataResponse.setSegmentCode("");
            dataResponse.setSegmentName("");
            customerSegmentControllerResponse.setDataResponse(dataResponse);
            return new ResponseEntity<>(customerSegmentControllerResponse, httpStatus);
        } catch (GeneralException e) {
            log.error("GeneralException while calling CustomerProfileService", e);
            log.warn("We hardcode default segment code in the response");
            httpStatus = HttpStatus.OK;
            ServiceInfo serviceInfo = new ServiceInfo("200", "", "");
            customerSegmentControllerResponse.setInfo(serviceInfo);
            dataResponse.setSegmentCode("PD");
            dataResponse.setSegmentName("PERSONAL");
            customerSegmentControllerResponse.setDataResponse(dataResponse);
            return new ResponseEntity<>(customerSegmentControllerResponse, httpStatus);
        }
        return new ResponseEntity<>(customerSegmentControllerResponse, httpStatus);
    }
}

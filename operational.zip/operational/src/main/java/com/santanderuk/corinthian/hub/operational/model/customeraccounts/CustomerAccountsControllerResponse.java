package com.santanderuk.corinthian.hub.operational.model.customeraccounts;

import com.santanderuk.corinthian.hub.commons.utilities.ServiceInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerAccountsControllerResponse {

    private DataResponse dataResponse;
    private ServiceInfo info;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("dataResponse", dataResponse)
                .append("info", info)
                .toString();
    }
}


package com.santanderuk.corinthian.hub.operational.api.directdebit.io;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@JsonPropertyOrder(alphabetic = true)
public class Account extends ModelBase {
    private String alias;
    private String sortCode;
    private String accountNumber;
    private String currency;
    private BigDecimal balance;
    private BigDecimal balanceIncPending;
}

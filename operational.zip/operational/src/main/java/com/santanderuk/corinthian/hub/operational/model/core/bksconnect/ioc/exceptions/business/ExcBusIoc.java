package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.GeneralException;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by C0229411 on 23/06/2017.
 **/

public class ExcBusIoc extends GeneralException {

    public static final String EXC_BUS_IOC_CODE = "EXC_BUS_IOC";
    public static final String EXC_BUS_IOC_MSG = "Error detected in IOC response";

    public ExcBusIoc() {
        super(
                EXC_BUS_IOC_CODE,
                EXC_BUS_IOC_MSG
        );
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("code", EXC_BUS_IOC_CODE)
                .append("message", EXC_BUS_IOC_MSG)
                .toString();
    }
}

package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.classes.PartenonAccountNumber;
import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.DataResponse;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.OperationalIocData;
import com.santanderuk.corinthian.hub.operational.services.customeraccounts.CustomerAccountsServiceInterface;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class OperationalIocServiceImplementation implements CustomerAccountsServiceInterface {

    private static final Logger log = LoggerFactory.getLogger(OperationalIocServiceImplementation.class);

    private final OperationalIocDataAccess operationalIocDataAccess;
    private final OperationIocDataConverter operationIocDataConverter;

    public OperationalIocServiceImplementation(OperationalIocDataAccess operationalIocDataAccess, OperationIocDataConverter operationIocDataConverter) {
        this.operationalIocDataAccess = operationalIocDataAccess;
        this.operationIocDataConverter = operationIocDataConverter;
    }

    public DataResponse getCustomerAccounts(String ldapUid, String jwtAuth) throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {

        log.info("Operational - > CustomerAccounts. Validating input data...");
        OperationalIocDataValidation.validate(ldapUid);
        log.info("Calling operationalIocDataAccess.getData");
        OperationalIocData operationalIocData = operationalIocDataAccess.getData(ldapUid, jwtAuth);
        log.info("transforming IOC to customerAccounts response.");


        if (operationalIocData.getContractsInMccControllerResponse().getDataResponse() == null) {
            PartenonContract partenonContract = operationalIocData.getRetrieveMccControllerResponse().getDataResponse().getMccContract().getPartenonContract();
            if (partenonContract != null) {
                DataResponse dataResponse = new DataResponse();
                PartenonAccountNumber mccContract = new PartenonAccountNumber();
                mccContract.setCentre(partenonContract.getCentre().getCentreCode());
                mccContract.setCompany(partenonContract.getCentre().getCompany());
                mccContract.setContract(partenonContract.getContractNumber());
                mccContract.setProduct(partenonContract.getProductTypeCode());
                dataResponse.setMccContract(mccContract);

                return dataResponse;

            } else {
                return new DataResponse();
            }
        } else {
            return operationIocDataConverter.iocToCorinthian(operationalIocData);
        }
    }
}

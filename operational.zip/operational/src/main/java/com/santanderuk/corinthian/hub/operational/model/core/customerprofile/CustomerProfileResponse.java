package com.santanderuk.corinthian.hub.operational.model.core.customerprofile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerProfileResponse {

    private CustomerProfile customerProfile;
    private String code;
    private String message;

}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "input",
        "securityInput"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContractsInMccDataRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("input")
    private Input input;
    @JsonProperty("securityInput")
    private SecurityInput securityInput;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("input", input)
                .append("securityInput", securityInput)
                .toString();
    }
}

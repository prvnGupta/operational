package com.santanderuk.corinthian.hub.operational.services.customersegment.implementation;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.config.OperationalConfig;
import com.santanderuk.corinthian.hub.operational.model.core.customerprofile.CustomerProfileResponse;
import com.santanderuk.corinthian.hub.operational.model.customersegment.DataResponse;
import com.santanderuk.corinthian.hub.operational.services.customersegment.CustomerSegmentServiceInterface;
import com.santanderuk.corinthian.hub.operational.utils.ExtractCustomerIdFromJwt;
import com.santanderuk.corinthian.hub.operational.utils.FormatFirstName;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.CustomerInformationClient;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerInformationResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class CustomerSegmentServiceImplementation implements CustomerSegmentServiceInterface {

    public static final String KEY = "operational-customer";
    private static final String CALLING_ENDPOINT = "Endpoint: {}";
    private static final String LDAP_UID = "ldapUid: {}";
    private static final String JSON_RESPONSE = "Json Response: {}";
    private static final String EXC_CUST_PROFILE_CORE_CALL = "EXC_CUSTOMER_PROFILE_CORE_CALL";
    private static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";

    private final RestTemplate restTemplate;
    private final OperationalConfig config;
    private final CustomerInformationClient customerInformationClient;
    private final ExtractCustomerIdFromJwt extractCustomerIdFromJwt;
    private final FormatFirstName formatFirstName;

    public CustomerSegmentServiceImplementation(RestTemplate restTemplate, OperationalConfig config, CustomerInformationClient customerInformationClient, ExtractCustomerIdFromJwt extractCustomerIdFromJwt, FormatFirstName formatFirstName) {
        this.restTemplate = restTemplate;
        this.config = config;
        this.customerInformationClient = customerInformationClient;
        this.extractCustomerIdFromJwt = extractCustomerIdFromJwt;
        this.formatFirstName = formatFirstName;
    }

    @Cacheable(value = "operational-customer", key = "#root.target.KEY + #ldapUid", cacheManager = "cacheManagerLongLife")
    public DataResponse getCustomerSegment(String ldapUid, String jwtToken) throws GeneralException, ConnectionException {
        CustomerProfileResponse customerProfileResponse = getCustomerProfileCoreService(ldapUid);
        CustomerInformationResponse customerInformation = customerInformationClient.getCustomerInformation(config.getCustomerInformationUrl(), extractCustomerIdFromJwt.getCustomerIdZeroLeftPadded(jwtToken));
        DataResponse dataResponse = new DataResponse();
        dataResponse.setFirstName(formatFirstName.formatFirstName(customerInformation.getCustomerBasicDataEnquire().getFirstName()));
        dataResponse.setLastName(formatFirstName.formatFirstName(customerInformation.getCustomerBasicDataEnquire().getLastName()));
        if ((null != customerProfileResponse.getCustomerProfile()) && (null != customerProfileResponse.getCustomerProfile().getSegmentCode())) {
            dataResponse.setSegmentCode(customerProfileResponse.getCustomerProfile().getSegmentCode().trim());
            dataResponse.setSegmentName(customerProfileResponse.getCustomerProfile().getSegmentName().trim());
        } else {
            log.error("getCustomerProfileCoreService - > Not able to read customer segment from customer profile core service response");
            throw new GeneralException(EXC_CUST_PROFILE_CORE_CALL, "Not able to read customer segment from customer profile core service response");
        }
        return dataResponse;
    }

    public CustomerProfileResponse getCustomerProfileCoreService(String ldapUid) throws GeneralException {
        ResponseEntity<CustomerProfileResponse> responseEntity;

        log.debug("getCustomerProfileCoreService - > Adding client-id to header");
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(X_IBM_CLIENT_ID, config.getClientId());
        HttpEntity httpEntity = new HttpEntity(null, headers);


        try {
            log.info("getCustomerProfileCoreService - > Calling CustomerProfile Core Microservice");
            String serviceUrl = config.getBrandEndpoint().replace("{ldapuid}", ldapUid);
            log.debug(LDAP_UID, ldapUid);
            log.debug(CALLING_ENDPOINT, serviceUrl);
            responseEntity = restTemplate.exchange(
                    serviceUrl,
                    HttpMethod.GET,
                    httpEntity,
                    CustomerProfileResponse.class
            );
            log.info("getCustomerProfileCoreService - > Customer Profile Core microservice response received");
            log.debug(JSON_RESPONSE, responseEntity.getBody());

        } catch (Exception e) {
            log.error("getCustomerProfileCoreService - > Error while connecting to Customer Profile Core microservice", e);
            throw new GeneralException(EXC_CUST_PROFILE_CORE_CALL, "An exception occurred while calling Customer Profile Core microservice", e);
        }

        HttpStatus httpStatus = responseEntity.getStatusCode();
        if (httpStatus != HttpStatus.OK) {
            log.error("Customer Profile Core microservice response KO.  Response Status: {}", httpStatus);
            throw new GeneralException(EXC_CUST_PROFILE_CORE_CALL, "An error occurred while calling Customer Profile Core microservice");
        }

        return responseEntity.getBody();
    }
}

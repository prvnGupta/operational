package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.validations;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by C0229411 on 12/09/2017.
 **/

public enum ExceptionValidationEnum {
    EXC_VAL_DATAREQUEST_EMPTY("EXC_VAL_DATAREQUEST_EMPTY", "Mandatory Input dataRequest field is empty"),
    EXC_VAL_ELEMENTLIST_EMPTY("EXC_VAL_ELEMENTLIST_EMPTY", "Mandatory Input elementList field is empty"),
    EXC_VAL_ELEMENT_EMPTY("EXC_VAL_ELEMENT_EMPTY", "Mandatory Input element field is empty"),
    EXC_VAL_CESTA("EXC_VAL_CESTA", "Mandatory Input cesta field format is not valid"),
    EXC_VAL_PARTENONCONTRACT("EXC_VAL_PARTENONCONTRACT", "Mandatory Input partenonContract field format is not valid"),
    EXC_VAL_PRODUCTSUBTYPE("EXC_VAL_PRODUCTSUBTYPE", "Input productSubType field format is not valid"),
    EXC_VAL_COMPANY("EXC_VAL_COMPANY", "Mandatory Input company field format is not valid"),
    EXC_VAL_BDPCUSTOMER("EXC_VAL_BDPCUSTOMER", "Mandatory Input bdpCustomer field format is not valid"),
    EXC_VAL_CHANNEL("EXC_VAL_CHANNEL", "Input channel field format is not valid");


    private String errorCode;
    private String errorMessage;

    ExceptionValidationEnum(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("errorCode", errorCode)
                .append("errorMessage", errorMessage)
                .toString();
    }
}

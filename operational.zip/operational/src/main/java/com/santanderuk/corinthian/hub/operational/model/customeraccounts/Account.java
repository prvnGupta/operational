package com.santanderuk.corinthian.hub.operational.model.customeraccounts;

import com.santanderuk.corinthian.hub.commons.classes.PartenonAccountNumber;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class Account implements Serializable {

    private static final long serialVersionUID = 1L;

    private String localContractSortCode;
    private String localContractAccountNumber;
    private String alias;
    private BigDecimal balance;
    private BigDecimal balanceIncPending;
    private BigDecimal overdraftRemaining;
    private boolean overdraftAuthorisedFlag;
    private String currency;
    private PartenonAccountNumber partenonAccountNumber;
    private String status;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("localContractSortCode", localContractSortCode)
                .append("localContractAccountNumber", localContractAccountNumber)
                .append("alias", alias)
                .append("balance", balance)
                .append("currency", currency)
                .append("partenonAccountNumber", partenonAccountNumber)
                .append("status", status)
                .toString();
    }
}

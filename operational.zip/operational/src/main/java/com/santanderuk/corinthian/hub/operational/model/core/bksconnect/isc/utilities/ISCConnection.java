package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.utilities;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.business.ExcBusIsc;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.AccountBalanceControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.AccountBalanceControllerResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * Created by C0229411 on 23/06/2017.
 **/
@Component
public class ISCConnection {
    private static final Logger log = LoggerFactory.getLogger(ISCConnection.class);
    private static final String CALLING_ENDPOINT = "Calling endpoint: {}";
    private static final String JSON_REQUEST = "JSON Request: {}";
    private static final String JSON_RESPONSE = "JSON Response -> {}";
    private static final String JWT = "JWT: {}";
    private static final String AUTHORIZATION = "authorization";
    private static final String CARRIAGE_RETURN = "[\r\n]";
    private static final String STR_EMPTY = "";
    private static final String X_IBM_CLIENT_ID = "X-IBM-Client-Id";


    private RestTemplate restTemplate = new RestTemplate();

    /**
     * @param serviceUrl
     * @param accountBalanceControllerRequest
     * @param jwtAuth
     * @return AccountBalanceControllerResponse
     * @throws GeneralException
     */
    public AccountBalanceControllerResponse accountBalance(
            String serviceUrl,
            AccountBalanceControllerRequest accountBalanceControllerRequest,
            String jwtAuth, String clientId) throws GeneralException {


        ResponseEntity<AccountBalanceControllerResponse> responseEntity;

        log.info("AccountBalance - > Adding JWT token to request headers");
        log.debug(JWT, jwtAuth.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(AUTHORIZATION, jwtAuth);
        headers.add(X_IBM_CLIENT_ID, clientId);
        HttpEntity httpEntity = new HttpEntity(accountBalanceControllerRequest, headers);

        try {
            log.info("AccountBalance - > Calling AccountBalance ISC Core microservice");
            log.debug(CALLING_ENDPOINT, serviceUrl.replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.debug(JSON_REQUEST, accountBalanceControllerRequest.toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            responseEntity = restTemplate.postForEntity(
                    serviceUrl,
                    httpEntity,
                    AccountBalanceControllerResponse.class
            );
            log.debug(JSON_RESPONSE, responseEntity.getBody().toString().replaceAll(CARRIAGE_RETURN, STR_EMPTY));
            log.info("AccountBalance - > AccountBalance ISC Core microservice: Response received");
        } catch (Exception e) {
            log.error("AccountBalance - > Error while connecting to  AccountBalance ISC Core microservice");
            log.error(e.getMessage());
            throw new GeneralException("EXC_ISCCORE_CALL", "An error occurred while calling AccountBalance ISC Core service", e);
        }
        String error = responseEntity.getBody().getInfo().getCode();
        if (error.length() != 0) {
            log.error("ISC AccountBalance microservice response not expected. About to throw ExcBusIsc()");
            throw new ExcBusIsc(error);
        }
        return responseEntity.getBody();

    }

}
package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "productType",
        "productSubtypeCode"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductSubtype implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("productType")
    private ProductType productType;
    @JsonProperty("productSubtypeCode")
    private String productSubtypeCode;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("productType", productType)
                .append("productSubtypeCode", productSubtypeCode)
                .toString();
    }
}

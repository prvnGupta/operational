package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.classes.PartenonAccountNumber;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractElement;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.Account;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.DataResponse;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.OperationalIocData;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalance;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;


@Component
public class OperationIocDataConverter {

    public DataResponse iocToCorinthian(OperationalIocData operationalIocData) {
        DataResponse dataResponse = new DataResponse();
        List<Account> accountList = new ArrayList<>();
        List<ContractElement> filteredListOfContractElements = filterOutContractElementsWithoutBalances(operationalIocData.getContractsInMccControllerResponse().getDataResponse().getDataList().getContractElement(), operationalIocData.getAccountBalancesResponse());
        filteredListOfContractElements.forEach(
                contractElement -> {
                    AccountBalance accountBalance = fetchMatchingAccount(contractElement.getContractDetails().getPartenonContract(), operationalIocData.getAccountBalancesResponse().getAccountBalances());
                    Account account = new Account();
                    account.setAlias(contractElement.getAlias());
                    account.setBalance(convertAmountStringToBigDecimal(accountBalance.getFinancialBalance()));
                    account.setBalanceIncPending(convertAmountStringToBigDecimal(accountBalance.getBalanceIncPending()));
                    account.setOverdraftRemaining(new BigDecimal("1000.00").setScale(1, RoundingMode.HALF_UP));
                    account.setCurrency(accountBalance.getCurrencyCode());
                    account.setLocalContractAccountNumber(contractElement.getContractDetails().getLocalContract().getLocalContractNumber().substring(6));
                    account.setLocalContractSortCode(contractElement.getContractDetails().getLocalContract().getLocalContractNumber().substring(0, 6));
                    account.setPartenonAccountNumber(new PartenonAccountNumber(
                            contractElement.getContractDetails().getPartenonContract().getCentre().getCompany(),
                            contractElement.getContractDetails().getPartenonContract().getCentre().getCentreCode(),
                            contractElement.getContractDetails().getPartenonContract().getProductTypeCode(),
                            contractElement.getContractDetails().getPartenonContract().getContractNumber()
                    ));
                    account.setStatus(contractElement.getStatusIndicator());
                    account.setOverdraftRemaining(convertAmountStringToBigDecimal(accountBalance.getOverdraftRemaining()));
                    account.setOverdraftAuthorisedFlag(hasOverdraft(convertAmountStringToBigDecimal(accountBalance.getAuthorizedOverdraft()), convertAmountStringToBigDecimal(accountBalance.getTemporaryOverdraft())));
                    accountList.add(account);
                }
        );
        dataResponse.setAccounts(accountList);
        PartenonAccountNumber mccContract = new PartenonAccountNumber();
        mccContract.setCompany(operationalIocData.getRetrieveMccControllerResponse().getDataResponse().getMccContract().getPartenonContract().getCentre().getCompany());
        mccContract.setCentre(operationalIocData.getRetrieveMccControllerResponse().getDataResponse().getMccContract().getPartenonContract().getCentre().getCentreCode());
        mccContract.setProduct(operationalIocData.getRetrieveMccControllerResponse().getDataResponse().getMccContract().getPartenonContract().getProductTypeCode());
        mccContract.setContract(operationalIocData.getRetrieveMccControllerResponse().getDataResponse().getMccContract().getPartenonContract().getContractNumber());
        dataResponse.setMccContract(mccContract);
        return dataResponse;
    }

    private List<ContractElement> filterOutContractElementsWithoutBalances(List<ContractElement> contractElements, AccountBalancesResponse accountBalancesResponse) {

        List<ContractElement> filteredList = new ArrayList<>();

        contractElements.forEach(contractElement -> {
            accountBalancesResponse.getAccountBalances().forEach(accountBalance -> {
                PartenonContract partenonContract = contractElement.getContractDetails().getPartenonContract();
                if (partenonContract.getCentre().getCompany().concat(partenonContract.getCentre().getCentreCode()).concat(partenonContract.getProductTypeCode()).concat(partenonContract.getContractNumber()).equalsIgnoreCase(accountBalance.getPartenonContractId())) {
                    filteredList.add(contractElement);
                }
            });
        });

        return filteredList;
    }

    private AccountBalance fetchMatchingAccount(PartenonContract partenonContract, List<AccountBalance> accountBalances) {
        final AccountBalance[] accountBalanceToReturn = new AccountBalance[1];
        accountBalances.forEach(
                accountBalance -> {
                    if (partenonContract.getCentre().getCompany().concat(partenonContract.getCentre().getCentreCode()).concat(partenonContract.getProductTypeCode()).concat(partenonContract.getContractNumber()).equalsIgnoreCase(accountBalance.getPartenonContractId())) {
                        accountBalanceToReturn[0] = accountBalance;
                    }
                }
        );
        return accountBalanceToReturn[0];
    }

    private BigDecimal convertAmountStringToBigDecimal(String amount) {

        if (null != amount) {
            String sanitisedString = amount.replace(",", "");
            String[] split = sanitisedString.split(" ");
            if (split[1].equalsIgnoreCase("c")) {
                return new BigDecimal(split[0]).setScale(2, RoundingMode.HALF_UP);
            } else {
                return new BigDecimal("-" + split[0]).setScale(2, RoundingMode.HALF_UP);
            }
        } else {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }
    }

    private boolean hasOverdraft(BigDecimal authorizedOverdraft, BigDecimal temporaryOverdraft) {
        return authorizedOverdraft.add(temporaryOverdraft).compareTo(BigDecimal.ZERO) > 0;
    }

}

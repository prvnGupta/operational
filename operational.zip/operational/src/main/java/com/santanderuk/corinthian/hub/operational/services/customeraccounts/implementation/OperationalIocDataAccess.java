package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.config.OperationalConfig;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Centre;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Profile;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.*;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccDataRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoDataRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities.IOCConnection;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.OperationalIocData;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.AccountBalancesClient;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class OperationalIocDataAccess {

    private static final Logger log = LoggerFactory.getLogger(OperationalIocDataAccess.class);

    private final IOCConnection iocConnection;
    private final OperationalConfig operationalConfig;
    private final AccountBalancesClient accountBalancesClient;

    @Autowired
    public OperationalIocDataAccess(IOCConnection iocConnection, OperationalConfig operationalConfig, AccountBalancesClient accountBalancesClient) {
        this.iocConnection = iocConnection;
        this.operationalConfig = operationalConfig;
        this.accountBalancesClient = accountBalancesClient;
    }

    public OperationalIocData getData(String ldapUid, String jwtAuth) throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {
        OperationalIocData operationalIocData;

        operationalIocData = getMCCActions(ldapUid, jwtAuth);
        if (!operationalIocData.getRetrieveMccControllerResponse().getInfo().getCode().equalsIgnoreCase(ExcBusViewOnly.EXC_BUS_CODE)) {
            log.info("Mcc contract Found");
            operationalIocData = contractsInMCCActions(jwtAuth, operationalIocData);
            if (checkHaveContractsInMccDataResponse(operationalIocData)) {
                fetchBalancesForAccounts(operationalIocData);
            }
        } else {
            throw new ExcBusViewOnly();
        }


        return operationalIocData;
    }

    public boolean checkHaveContractsInMccDataResponse(OperationalIocData operationalIocData) {
        ContractsInMccDataResponse dataResponse = operationalIocData.getContractsInMccControllerResponse().getDataResponse();
        return null != dataResponse;
    }

    public OperationalIocData getMCCActions(String ldapUid, String jwtAuth) throws GeneralException {
        OperationalIocData operationalIocData = new OperationalIocData();
        //prepare request to call retrieveMcc service
        RetrieveMccControllerRequest retrieveMccControllerRequest = generateRetrieveMccRequest(ldapUid);

        //Call RetrieveMccFromLdapUser IOC Core Service
        RetrieveMccControllerResponse retrieveMccControllerResponse = iocConnection.retrieveMcc(operationalConfig.getIocRetrieveMccEndpoint(), retrieveMccControllerRequest, jwtAuth, operationalConfig.getClientId());
        operationalIocData.setRetrieveMccControllerResponse(retrieveMccControllerResponse);

        return operationalIocData;
    }

    public OperationalIocData contractsInMCCActions(String jwtAuth, OperationalIocData operationalIocData) throws GeneralException {
        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = generateRetrieveMccInfoRequest(operationalIocData);

        //Call RetrieveMccInfo IOC Core Service
        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = iocConnection.retrieveMccInfo(operationalConfig.getIocRetrieveMccInfoEndpoint(), retrieveMccInfoControllerRequest, jwtAuth, operationalConfig.getClientId());
        operationalIocData.setRetrieveMccInfoControllerResponse(retrieveMccInfoControllerResponse);

        //prepare input to call IOC Contracts in Mcc core service
        ContractsInMccControllerRequest contractsInMccControllerRequest = generateContractsInMccRequest(operationalIocData);

        //Call ContractsInMcc IOC Core Service
        ContractsInMccControllerResponse contractsInMccControllerResponse = iocConnection.contractsInMcc(operationalConfig.getIocContractsInMccEndpoint(), contractsInMccControllerRequest, jwtAuth, operationalConfig.getClientId());
        operationalIocData.setContractsInMccControllerResponse(contractsInMccControllerResponse);
        return operationalIocData;
    }

    private void fetchBalancesForAccounts(OperationalIocData operationalIocData) throws ConnectionException, ValidationsException {
        List<String> partenonContractIds = generateListOfPartenonContractIds(operationalIocData);
        AccountBalancesResponse accountBalancesResponse = accountBalancesClient.fetchBalances(operationalConfig.getAccountBalancesUrl(), partenonContractIds);
        operationalIocData.setAccountBalancesResponse(accountBalancesResponse);
    }

    private List<String> generateListOfPartenonContractIds(OperationalIocData operationalIocData) {
        List<String> partenonContractIds = new ArrayList<>();
        operationalIocData.getContractsInMccControllerResponse().getDataResponse().getDataList().getContractElement().forEach(contractElement -> {
                    PartenonContract partenonContract = contractElement.getContractDetails().getPartenonContract();
                    String id = partenonContract.getCentre().getCompany().concat(partenonContract.getCentre().getCentreCode()).concat(partenonContract.getProductTypeCode()).concat(partenonContract.getContractNumber());
                    partenonContractIds.add(id);
                }
        );
        return partenonContractIds;
    }

    private ContractsInMccControllerRequest generateContractsInMccRequest(OperationalIocData operationalIocData) {
        ContractsInMccControllerRequest contractsInMccControllerRequest = new ContractsInMccControllerRequest();
        ContractsInMccDataRequest dataRequest = new ContractsInMccDataRequest();
        SecurityInput securityInput = new SecurityInput();
        securityInput.setChannel(operationalConfig.getIocContractsInMccSecurityInputChannel());
        dataRequest.setSecurityInput(securityInput);
        Input input = new Input();
        input.setOperation(operationalConfig.getIocContractsInMccInputOperation());
        input.setConexionChannel(operationalConfig.getIocContractsInMccInputConexionChannel());
        input.setPersonalizationChannel(operationalConfig.getIocContractsInMccInputPersonalizationChannel());
        input.setElectronicChannel(operationalConfig.getIocContractsInMccInputElectronicChannel());
        input.setBdpCustomer(operationalIocData.getRetrieveMccInfoControllerResponse().getDataResponse().getBdpCustomer());
        input.setMccPartenonContract(operationalIocData.getRetrieveMccControllerResponse().getDataResponse().getMccContract().getPartenonContract());
        input.setCompany(operationalConfig.getIocContractsInMccInputCompany());
        input.setService(operationalConfig.getIocContractsInMccInputService());
        dataRequest.setInput(input);
        contractsInMccControllerRequest.setDataRequest(dataRequest);
        return contractsInMccControllerRequest;
    }

    private RetrieveMccInfoControllerRequest generateRetrieveMccInfoRequest(OperationalIocData operationalIocData) {
        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = new RetrieveMccInfoControllerRequest();
        RetrieveMccInfoDataRequest dataRequest = new RetrieveMccInfoDataRequest();
        dataRequest.setCompany(operationalConfig.getIocRetrieveMccInfoComnpany());
        dataRequest.setConexionChannel(operationalConfig.getIocRetrieveMccInfoConexionChannel());
        dataRequest.setMccPartenonContract(operationalIocData.getRetrieveMccControllerResponse().getDataResponse().getMccContract().getPartenonContract());
        retrieveMccInfoControllerRequest.setDataRequest(dataRequest);
        return retrieveMccInfoControllerRequest;
    }

    private RetrieveMccControllerRequest generateRetrieveMccRequest(String ldapUid) {
        RetrieveMccControllerRequest retrieveMccControllerRequest = new RetrieveMccControllerRequest();
        RetrieveMccDataRequest datarequest = new RetrieveMccDataRequest();
        Profile profile = new Profile();
        profile.setCompany(operationalConfig.getIocRetrieveMccProfileComnpany());
        profile.setChannel(operationalConfig.getIocRetrieveMccProfileChannel());
        datarequest.setProfile(profile);
        datarequest.setInputChannel(operationalConfig.getIocRetrieveMccInputChannel());
        datarequest.setOption(operationalConfig.getIocRetrieveMccOption());
        PartenonContract partenonContract = new PartenonContract();
        Centre partenonContractCentre = new Centre();
        partenonContractCentre.setCompany(operationalConfig.getIocRetrieveMccContractCompany());
        partenonContractCentre.setCentreCode("");
        partenonContract.setCentre(partenonContractCentre);
        partenonContract.setProductTypeCode("");
        partenonContract.setContractNumber("");
        datarequest.setPartenonContract(partenonContract);
        datarequest.setLdapUid(ldapUid);
        retrieveMccControllerRequest.setDataRequest(datarequest);
        return retrieveMccControllerRequest;
    }
}

package com.santanderuk.corinthian.hub.operational.utils;

import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class ExtractCustomerIdFromJwt {

    public String getCustomerIdZeroLeftPadded(String jwtToken) {
        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(jwtToken);
        String customerId = bdpCustomer.getCustomerType() + zeroLeftPadCustomerNumber(bdpCustomer.getCustomerNumber());
        log.debug("customerIdZeroLeftPadded - {}", customerId);
        return (customerId);
    }

    private String zeroLeftPadCustomerNumber(int customerNumber) {
        return StringUtils.leftPad(String.valueOf(customerNumber), 9, "0");
    }
}

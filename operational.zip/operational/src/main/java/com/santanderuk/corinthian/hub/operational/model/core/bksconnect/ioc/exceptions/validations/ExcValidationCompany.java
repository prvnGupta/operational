package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.validations;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.GeneralException;

/**
 * Created by C0229411 on 12/09/2017.
 **/

public class ExcValidationCompany extends GeneralException {
    public ExcValidationCompany() {
        super(
                ExceptionValidationEnum.EXC_VAL_COMPANY.getErrorCode(),
                ExceptionValidationEnum.EXC_VAL_COMPANY.getErrorMessage()
        );
    }

    @Override
    public String toString() {
        return super.toString();
    }
}

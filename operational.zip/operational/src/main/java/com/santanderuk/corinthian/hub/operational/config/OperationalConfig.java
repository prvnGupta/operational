package com.santanderuk.corinthian.hub.operational.config;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.AccountBalancesClient;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.CustomerInformationClient;
import com.santanderuk.corinthian.services.commons.clients.directdebit.InternalAccountsClient;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import com.santanderuk.corinthian.services.commons.utilities.LoggingRequestInterceptor;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Configuration
@Getter
public class OperationalConfig {

    @Value("${apimanager.client-id-value}")
    private String clientId;
    @Value("${operational.endpoints.ioc.retrievemcc}")
    private String iocRetrieveMccEndpoint;
    @Value("${brand.endpoint}")
    private String brandEndpoint;
    @Value("${operational.endpoints.ioc.retrievemccinfo}")
    private String iocRetrieveMccInfoEndpoint;
    @Value("${operational.endpoints.ioc.contractsinmcc}")
    private String iocContractsInMccEndpoint;
    @Value("${operational.endpoints.accountBalances}")
    private String accountBalancesUrl;
    @Value("${ioc.retrievemcc.profile.company}")
    private String iocRetrieveMccProfileComnpany;
    @Value("${ioc.retrievemcc.profile.channel}")
    private String iocRetrieveMccProfileChannel;
    @Value("${ioc.retrievemcc.inputchannel}")
    private String iocRetrieveMccInputChannel;
    @Value("${ioc.retrievemcc.option}")
    private String iocRetrieveMccOption;
    @Value("${ioc.retrievemcc.partenoncontract.company}")
    private String iocRetrieveMccContractCompany;
    @Value("${ioc.retrievemccinfo.company}")
    private String iocRetrieveMccInfoComnpany;
    @Value("${ioc.retrievemccinfo.conexionchannel}")
    private String iocRetrieveMccInfoConexionChannel;
    @Value("${ioc.contractsinmcc.securityinput.channel}")
    private String iocContractsInMccSecurityInputChannel;
    @Value("${ioc.contractsinmcc.input.operation}")
    private String iocContractsInMccInputOperation;
    @Value("${ioc.contractsinmcc.input.personalizationchannel}")
    private String iocContractsInMccInputConexionChannel;
    @Value("${ioc.contractsinmcc.input.conexionchannel}")
    private String iocContractsInMccInputPersonalizationChannel;
    @Value("${ioc.contractsinmcc.input.electronicchannel}")
    private String iocContractsInMccInputElectronicChannel;
    @Value("${ioc.contractsinmcc.input.company}")
    private String iocContractsInMccInputCompany;
    @Value("${ioc.contractsinmcc.input.service}")
    private String iocContractsInMccInputService;
    @Value("${customers-information.url}")
    private String customerInformationUrl;

    @Bean
    public RestTemplate restTemplate() {
        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        interceptors.add(new LoggingRequestInterceptor());
        restTemplate.setInterceptors(interceptors);
        return restTemplate;
    }

    @Bean
    public ApiManagerConfig apiManagerConfig() {
        return new ApiManagerConfig();
    }

    @Bean
    public InternalAccountsClient internalAccountsClient() {
        return new InternalAccountsClient(restTemplate());
    }

    @Bean
    public CustomerInformationClient customerInformationClient() {
        return new CustomerInformationClient(restTemplate(), apiManagerConfig());
    }

    @Bean
    public AccountBalancesClient accountBalancesClient() {
        return new AccountBalancesClient(restTemplate(), apiManagerConfig());
    }
}

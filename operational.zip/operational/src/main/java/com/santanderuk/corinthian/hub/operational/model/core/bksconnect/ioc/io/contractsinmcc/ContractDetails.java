package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Iban;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.LocalContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "localContract",
        "partenonContract",
        "iban",
        "multiCountryIndicator",
        "country",
        "searchType"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContractDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("localContract")
    private LocalContract localContract;
    @JsonProperty("partenonContract")
    private PartenonContract partenonContract;
    @JsonProperty("iban")
    private Iban iban;
    @JsonProperty("multiCountryIndicator")
    private String multiCountryIndicator;
    @JsonProperty("country")
    private String country;
    @JsonProperty("searchType")
    private String searchType;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("localContract", localContract)
                .append("partenonContract", partenonContract)
                .append("iban", iban)
                .append("multiCountryIndicator", multiCountryIndicator)
                .append("country", country)
                .append("searchType", searchType)
                .toString();
    }
}

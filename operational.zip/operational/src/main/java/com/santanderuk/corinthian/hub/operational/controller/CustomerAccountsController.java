package com.santanderuk.corinthian.hub.operational.controller;

import com.santanderuk.corinthian.hub.commons.classes.PartenonAccountNumber;
import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.commons.utilities.ServiceInfo;
import com.santanderuk.corinthian.hub.commons.utilities.ServiceInfoCreator;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.CustomerAccountsControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.DataResponse;
import com.santanderuk.corinthian.hub.operational.services.customeraccounts.CustomerAccountsServiceInterface;
import com.santanderuk.corinthian.hub.operational.uidverifier.UidVerifier;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;


@RestController
@Slf4j
public class CustomerAccountsController {

    private final CustomerAccountsServiceInterface customerAccountsService;

    @Autowired
    public CustomerAccountsController(CustomerAccountsServiceInterface customerAccountsService) {
        this.customerAccountsService = customerAccountsService;
    }

    @ApiOperation("Endpoint used to get the accounts with balance for a used id.")
    @RequestMapping(
            path = "/customer-accounts/{ldapuid}",
            method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CustomerAccountsControllerResponse> operationIoc(@RequestHeader(name = "authorization", required = true) String jwtAuth, @PathVariable(value = "ldapuid") String ldapUid) throws ConnectionException, ValidationsException {
        log.info("CustomerAccountsController Controller. Request received:");
        HttpStatus httpStatus = HttpStatus.OK;
        ServiceInfo serviceInfo;
        DataResponse data;
        try {
            UidVerifier.getInstance().verify(jwtAuth, ldapUid);
            data = customerAccountsService.getCustomerAccounts(ldapUid, jwtAuth);
            if (!hasContracts(data)) {
                log.info("Data generated WAS NULL");
                data.setAccounts(new ArrayList<>());
                serviceInfo = new ServiceInfo("ko", "EXC_BUS_NO_INTERNAL_ACCOUNTS", "No accounts for customer");
            } else {
                serviceInfo = ServiceInfoCreator.ok();
            }
        } catch (ExcBusViewOnly e) {
            data = new DataResponse();
            data.setAccounts(new ArrayList<>());
            data.setMccContract(new PartenonAccountNumber("", "", "", ""));
            log.info("iocCore Controller. VIEW ONLY CREDENTIALS EXCEPTION: ");
            serviceInfo = new ServiceInfo("ko", ExcBusViewOnly.EXC_BUS_CODE, ExcBusViewOnly.EXC_BUS_MSG);
        } catch (GeneralException e) {
            data = new DataResponse();
            data.setAccounts(new ArrayList<>());
            data.setMccContract(new PartenonAccountNumber("", "", "", ""));
            log.info("iocCore Controller. EXCEPTION: ");
            serviceInfo = ServiceInfoCreator.exception(e);
        }

        CustomerAccountsControllerResponse response = new CustomerAccountsControllerResponse(data, serviceInfo);
        if (log.isDebugEnabled()) {
            log.debug(String.format("CustomerAccountsController Controller. Response:%n%s", response));
        }
        return new ResponseEntity<>(response, httpStatus);

    }

    public boolean hasContracts(DataResponse data) {
        try {
            return null != data.getAccounts();
        } catch (Exception e) {
            return false;
        }
    }
}


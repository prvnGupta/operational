package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.ServiceInfo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

/**
 * Created by C0229411 on 05/09/2017.
 **/

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "info",
        "dataResponse"

})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ContractsInMccControllerResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("info")
    private ServiceInfo info;
    @JsonProperty("dataResponse")
    private ContractsInMccDataResponse dataResponse;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("info", info)
                .append("dataResponse", dataResponse)
                .toString();
    }
}

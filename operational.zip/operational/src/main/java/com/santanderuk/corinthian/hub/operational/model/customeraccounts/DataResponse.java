package com.santanderuk.corinthian.hub.operational.model.customeraccounts;

import com.santanderuk.corinthian.hub.commons.classes.PartenonAccountNumber;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.util.List;

@Data
public class DataResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private PartenonAccountNumber mccContract;
    private List<Account> accounts = null;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("accounts", accounts)
                .toString();
    }
}
package com.santanderuk.corinthian.hub.operational.model.core.customerprofile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CustomerProfile {

    private String customerNumber;
    private String segmentCode;
    private String segmentName;
    private String brand;
    private String mcc1;
    private String mcc2;
    private String mccCode;
    private String mccContract;

}

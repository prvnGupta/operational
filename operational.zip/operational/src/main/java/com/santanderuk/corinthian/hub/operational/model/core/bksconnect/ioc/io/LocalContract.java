package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "localContractType",
        "localContractNumber"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LocalContract implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("localContractType")
    private String localContractType;
    @JsonProperty("localContractNumber")
    private String localContractNumber;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("localContractType", localContractType)
                .append("localContractNumber", localContractNumber)
                .toString();
    }
}

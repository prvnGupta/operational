package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Profile;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "profile",
        "company",
        "conexionChannel",
        "mccPartenonContract"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveMccInfoDataRequest implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("profile")
    private Profile profile;
    @JsonProperty("company")
    private String company;
    @JsonProperty("conexionChannel")
    private String conexionChannel;
    @JsonProperty("mccPartenonContract")
    private PartenonContract mccPartenonContract;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("profile", profile)
                .append("company", company)
                .append("conexionChannel", conexionChannel)
                .append("mccPartenonContract", mccPartenonContract)
                .toString();
    }
}

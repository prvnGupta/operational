package com.santanderuk.corinthian.hub.operational.model.customeraccounts;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.AccountBalanceControllerResponse;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import lombok.Data;

import java.io.Serializable;

@Data
public class OperationalIocData implements Serializable {

    private static final long serialVersionUID = 1L;

    private RetrieveMccControllerResponse retrieveMccControllerResponse;
    private RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse;
    private ContractsInMccControllerResponse contractsInMccControllerResponse;
    private AccountBalanceControllerResponse accountBalanceControllerResponse;
    private AccountBalancesResponse accountBalancesResponse;
}

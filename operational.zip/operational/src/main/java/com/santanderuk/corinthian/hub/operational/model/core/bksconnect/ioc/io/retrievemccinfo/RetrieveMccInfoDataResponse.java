package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.BdpCustomer;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.KcError;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "kcError",
        "bdpCustomer",
        "ldapUid",
        "mccType",
        "mccOrigin"
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RetrieveMccInfoDataResponse implements Serializable {
    private static final long serialVersionUID = 1L;

    @JsonProperty("kcError")
    private KcError kcError;
    @JsonProperty("bdpCustomer")
    private BdpCustomer bdpCustomer;
    @JsonProperty("ldapUid")
    private String ldapUid;
    @JsonProperty("mccType")
    private String mccType;
    @JsonProperty("mccOrigin")
    private String mccOrigin;

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("kcError", kcError)
                .append("bdpCustomer", bdpCustomer)
                .append("ldapUid", ldapUid)
                .append("mccType", mccType)
                .append("mccOrigin", mccOrigin)
                .toString();
    }
}

package com.santanderuk.corinthian.hub.operational.api.directdebit;

import com.santanderuk.corinthian.hub.operational.api.directdebit.io.DirectDebitAccounts;
import com.santanderuk.corinthian.hub.operational.exception.NoDirectDebitAccountException;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.AccountBalancesClient;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.clients.directdebit.InternalAccountsClient;
import com.santanderuk.corinthian.services.commons.clients.directdebit.io.InternalAccountsResponse;
import com.santanderuk.corinthian.services.commons.clients.directdebit.io.QueryParams;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class DirectDebitAccountsService {

    private final InternalAccountsClient accountsClient;
    private final AccountBalancesClient balancesClient;
    private final DirectDebitAccountsMapper mapper;
    @Value("${customer-access-entitlement.url}")
    private String url;
    @Value("${customer-access-entitlement.query-operation}")
    private String queryOperation;
    @Value("${operational.endpoints.accountBalances}")
    private String accountsBalancesUrl;

    public DirectDebitAccountsService(InternalAccountsClient internalAccountsClient, AccountBalancesClient accountBalancesClient, DirectDebitAccountsMapper mapper) {
        this.accountsClient = internalAccountsClient;
        this.balancesClient = accountBalancesClient;
        this.mapper = mapper;
    }

    public DirectDebitAccounts getDirectDebitAccounts(String ldapUid) throws GeneralException, NoDirectDebitAccountException {
        InternalAccountsResponse accountsApiResponse = accountsClient.directDebitEligibleAccounts(url, createQueryParams(ldapUid));
        if (accountsApiResponse.getAccounts().isEmpty()) {
            throw new NoDirectDebitAccountException("NO_DIRECT_DEBIT_INTERNAL_ACCOUNTS", "No eligible direct debit account found");
        }
        AccountBalancesResponse accountsWithBalances = balancesClient.fetchBalances(accountsBalancesUrl, getPartenonContractIds(accountsApiResponse));
        return mapper.mapDirectDebitAccounts(accountsApiResponse, accountsWithBalances);
    }

    private List<String> getPartenonContractIds(InternalAccountsResponse directDebitAccounts) {
        ArrayList<String> partenonContractsIds = new ArrayList<>();
        directDebitAccounts.getAccounts().forEach(account -> partenonContractsIds.add(account.getPartenonContract()));
        return partenonContractsIds;
    }

    private QueryParams createQueryParams(String ldapUid) {
        QueryParams queryParams = new QueryParams();
        queryParams.setUid(ldapUid);
        queryParams.setOperation(queryOperation);
        return queryParams;
    }
}

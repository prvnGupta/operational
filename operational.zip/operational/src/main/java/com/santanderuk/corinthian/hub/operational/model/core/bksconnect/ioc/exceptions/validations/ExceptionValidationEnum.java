package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.validations;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by C0229411 on 12/09/2017.
 **/

public enum ExceptionValidationEnum {
    EXC_VAL_DATAREQUEST_EMPTY("EXC_VAL_DATAREQUEST_EMPTY", "Mandatory Input dataRequest field is empty"),
    EXC_VAL_SERVICE_EMPTY("EXC_VAL_SERVICE_EMPTY", "Mandatory Input input.service field is empty"),
    EXC_VAL_INPUT_PROFILE_EMPTY("EXC_VAL_INPUT_PROFILE_EMPTY", "Mandatory Input profile field is empty"),
    EXC_VAL_INPUT_CHANNEL_EMPTY("EXC_VAL_INPUT_CHANNEL_EMPTY", "Mandatory Input inputChannel field is empty"),
    EXC_VAL_INPUT_OPTION_EMPTY("EXC_VAL_INPUT_OPTION_EMPTY", "Mandatory Input option field is empty"),
    EXC_VAL_INPUT_COMPANY_EMPTY("EXC_VAL_INPUT_COMPANY_EMPTY", "Mandatory Input company field is empty"),
    EXC_VAL_INPUT_LDAPUID_EMPTY("EXC_VAL_INPUT_LDAPUID_EMPTY", "Mandatory Input ldapUid field is empty"),
    EXC_VAL_BDPCUSTOMERNUMBER_EMPTY("EXC_VAL_BDPCUSTOMERNUMBER_EMPTY", "Mandatory Input input.BdpCustomer field is empty"),
    EXC_VAL_BDPCUSTOMERNUMBER("EXC_VAL_BDPCUSTOMERNUMBER", "Input input.BdpCustomer field format invalid"),
    EXC_VAL_PARTENONCONTRACT("EXC_VAL_PARTENONCONTRACT", "Input field partenonContract format is not valid"),
    EXC_VAL_COMPANY("EXC_VAL_COMPANY", "Input company field format is not valid"),
    EXC_VAL_PROFILE("EXC_VAL_PROFILE", "Input profile field format is not valid"),
    EXC_VAL_MCCPARTENONCONTRACT_EMPTY("EXC_VAL_MCCPARTENONCONTRACT_EMPTY", "Mandatory Input input.mccPartenonContract field is empty"),
    EXC_VAL_PARTENONCONTRACT_EMPTY("EXC_VAL_PARTENONCONTRACT_EMPTY", "Mandatory Input partenonContract field is empty"),
    EXC_VAL_SECURITYINPUT_EMPTY("EXC_VAL_SECURITYINPUT_EMPTY", "Mandatory Input securityInput field is empty"),
    EXC_VAL_SECURITYINPUTCHANNEL_EMPTY("EXC_VAL_SECURITYINPUTCHANNEL_EMPTY", "Mandatory Input securityInput.channel field is empty"),
    EXC_VAL_INPUT_OPERATION_EMPTY("EXC_VAL_INPUT_OPERATION_EMPTY", "Mandatory Input Input.operation field is empty"),
    EXC_VAL_INPUT_EMPTY("EXC_VAL_INPUT_EMPTY", "Mandatory Input input field is empty"),
    EXC_VAL_CONNECTIONCHANNEL_EMPTY("EXC_VAL_CONNECTIONCHANNEL_EMPTY", "Mandatory input input.connectionChannel field is empty"),
    EXC_VAL_ELECTRONICCHANNEL_EMPTY("EXC_VAL_ELECTRONICCHANNEL_EMPTY", "Mandatory input input.electronicChannel field is empty"),
    EXC_VAL_PERSONALIZATIONCHANNEL_EMPTY("EXC_VAL_PERSONALIZATIONCHANNEL_EMPTY", "Mandatory input input.personalizationChannel field is empty"),
    EXC_VAL_OPERATION("EXC_VAL_OPERATION", "input operation field format is not valid"),
    EXC_VAL_CHANNEL("EXC_VAL_CHANNEL", "Input field inputChannel format is not valid");


    private String errorCode;
    private String errorMessage;

    ExceptionValidationEnum(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("errorCode", errorCode)
                .append("errorMessage", errorMessage)
                .toString();
    }
}

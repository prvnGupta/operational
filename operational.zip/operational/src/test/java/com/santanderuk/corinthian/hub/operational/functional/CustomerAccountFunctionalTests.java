package com.santanderuk.corinthian.hub.operational.functional;

import com.jayway.restassured.response.Header;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class CustomerAccountFunctionalTests extends FunctionalTest {

    String customerAccountBaseUrl;
    Header authorizationHeader;

    @Before
    public void setup() {

        customerAccountBaseUrl = String.format("http://localhost:%s/operational/customer-accounts", serverPort);

        authorizationHeader = new Header("authorization", jwtAuth);
    }

    @Test
    public void testWeGetReadOnlyAccountWhenBKSReturnsEXC_BUS_VIEW_ONLY() {

        stubBKSReadOnly();

        given().
                header(authorizationHeader).
                when().
                get(customerAccountBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_BUS_VIEW_ONLY"),
                        "info.message", equalTo("Credential is View Only")
                );
    }

    @Test
    public void testWeGetErrorWhenCallToAccountBalanceFails() {

        stubBKSHasMccAccounts();
        stubAccountBalancesServiceDown();

        given().
                header(authorizationHeader).
                when().
                get(customerAccountBaseUrl + "/6x1WB78G").
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("ACCOUNT_BALANCES_UNAVAILABLE"),
                        "info.message", equalTo("Exception while calling Account Balances API")
                );
    }

    @Test
    public void testWeGetAccountInfoOnHappyPath() {

        stubBKSHasMccAccounts();
        stubAccountBalancesService();

        given().
                header(authorizationHeader).
                when().
                get(customerAccountBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ok"),
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "dataResponse.accounts[0].localContractSortCode", equalTo("123455"),
                        "dataResponse.accounts[0].partenonAccountNumber.company", equalTo("0015"),
                        "dataResponse.accounts[0].partenonAccountNumber.centre", equalTo("4247"),
                        "dataResponse.accounts[0].partenonAccountNumber.product", equalTo("300"),
                        "dataResponse.accounts[0].partenonAccountNumber.contract", equalTo("0010378"),
                        "dataResponse.accounts[0].balance", equalTo(new BigDecimal("190.00")),
                        "dataResponse.accounts[0].balanceIncPending", equalTo(new BigDecimal("190.00")),
                        "dataResponse.accounts[0].overdraftRemaining", equalTo(new BigDecimal("300.00")),
                        "dataResponse.accounts[0].overdraftAuthorisedFlag", equalTo(true),
                        "dataResponse.accounts[0].currency", equalTo("GBP"),
                        "dataResponse.accounts[1].localContractSortCode", equalTo("123455"),
                        "dataResponse.accounts[1].partenonAccountNumber.company", equalTo("0015"),
                        "dataResponse.accounts[1].partenonAccountNumber.centre", equalTo("4247"),
                        "dataResponse.accounts[1].partenonAccountNumber.product", equalTo("300"),
                        "dataResponse.accounts[1].partenonAccountNumber.contract", equalTo("0010379"),
                        "dataResponse.accounts[1].balance", equalTo(new BigDecimal("4250.31")),
                        "dataResponse.accounts[1].balanceIncPending", equalTo(new BigDecimal("-4250.31")),
                        "dataResponse.accounts[1].overdraftRemaining", equalTo(new BigDecimal("300.00")),
                        "dataResponse.accounts[1].overdraftAuthorisedFlag", equalTo(true),
                        "dataResponse.accounts[1].currency", equalTo("GBP"),
                        "dataResponse.mccContract.company", equalTo("YOUR MUM INC")
                );
    }

    @Test
    public void testWeGetMccContractNoInternalAccount() {

        stubBKSHasMccButNoInternalAccounts();

        given().
                header(authorizationHeader).
                when().
                get(customerAccountBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_BUS_NO_INTERNAL_ACCOUNTS"),
                        "dataResponse.mccContract.company", equalTo("0015"),
                        "dataResponse.mccContract.centre", equalTo("9473"),
                        "dataResponse.mccContract.product", equalTo("520"),
                        "dataResponse.mccContract.contract", equalTo("1152557")

                );
    }

    @Test
    public void testWeGetUnauthorizedForBadLdapUid() {

        given().
                header(authorizationHeader).
                when().
                get(customerAccountBaseUrl + "/fhaiufghaih").
                then().
                statusCode(200).
                and().
                body(
                        "info.code", equalTo("EXC_SEC_NO_VALID_TOKEN"),
                        "info.message", equalTo("Authorization Token received is not valid")
                );
    }
}

package com.santanderuk.corinthian.hub.operational.testdata;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.*;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.*;

import java.util.Arrays;

public class ContractsInMccControllerResponseTestData {

    public static ContractsInMccControllerResponse singleAccount() {

        Cesta cesta = new Cesta();
        cesta.setCestaCompany("CESTA_COMPANY");
        cesta.setCestaCode("CESTA_CODE");

        Centre centre = new Centre();
        centre.setCompany("0123");
        centre.setCentreCode("4567");

        PartenonContract partenonContract = new PartenonContract();
        partenonContract.setCentre(centre);
        partenonContract.setContractNumber("1234567");
        partenonContract.setProductTypeCode("890");

        LocalContract localContract = new LocalContract();
        localContract.setLocalContractNumber("123455667979879");

        ContractDetails contractDetails = new ContractDetails();
        contractDetails.setPartenonContract(partenonContract);
        contractDetails.setLocalContract(localContract);

        ProductType productType = new ProductType();
        productType.setProductTypeCode("PRODUCT_TYPE_CODE");
        productType.setCompany("PRODUCT_COMPANY");

        ProductSubtype subtype = new ProductSubtype();
        subtype.setProductSubtypeCode("SUB_TYPE_CODE");
        subtype.setProductType(productType);

        ContractElement contractElement = new ContractElement();
        contractElement.setOutCesta(cesta);
        contractElement.setContractDetails(contractDetails);
        contractElement.setProductSubtype(subtype);

        DataList dataList = new DataList();
        dataList.setContractElement(Arrays.asList(contractElement));

        ContractsInMccDataResponse contractsInMccDataResponse = new ContractsInMccDataResponse();
        contractsInMccDataResponse.setDataList(dataList);

        ContractsInMccControllerResponse contractsInMccControllerResponse = new ContractsInMccControllerResponse();
        contractsInMccControllerResponse.setDataResponse(contractsInMccDataResponse);

        return contractsInMccControllerResponse;
    }

    public static ContractsInMccControllerResponse multipleAccounts() {

        Cesta cesta = new Cesta();
        cesta.setCestaCompany("CESTA_COMPANY");
        cesta.setCestaCode("CESTA_CODE");

        Centre centre = new Centre();
        centre.setCompany("0123");
        centre.setCentreCode("4567");

        Centre centre1 = new Centre();
        centre1.setCompany("1234");
        centre1.setCentreCode("5678");

        PartenonContract partenonContract = new PartenonContract();
        partenonContract.setCentre(centre);
        partenonContract.setContractNumber("1234567");
        partenonContract.setProductTypeCode("890");

        PartenonContract partenonContract1 = new PartenonContract();
        partenonContract1.setCentre(centre1);
        partenonContract1.setContractNumber("2345678");
        partenonContract1.setProductTypeCode("901");

        LocalContract localContract = new LocalContract();
        localContract.setLocalContractNumber("123455667979879");

        ContractDetails contractDetails = new ContractDetails();
        contractDetails.setPartenonContract(partenonContract);
        contractDetails.setLocalContract(localContract);

        ContractDetails contractDetails1 = new ContractDetails();
        contractDetails1.setPartenonContract(partenonContract1);
        contractDetails1.setLocalContract(localContract);

        ProductType productType = new ProductType();
        productType.setProductTypeCode("PRODUCT_TYPE_CODE");
        productType.setCompany("PRODUCT_COMPANY");

        ProductSubtype subtype = new ProductSubtype();
        subtype.setProductSubtypeCode("SUB_TYPE_CODE");
        subtype.setProductType(productType);

        ContractElement contractElementOne = new ContractElement();
        contractElementOne.setOutCesta(cesta);
        contractElementOne.setContractDetails(contractDetails);
        contractElementOne.setProductSubtype(subtype);

        ContractElement contractElementTwo = new ContractElement();
        contractElementTwo.setOutCesta(cesta);
        contractElementTwo.setContractDetails(contractDetails1);
        contractElementTwo.setProductSubtype(subtype);

        DataList dataList = new DataList();
        dataList.setContractElement(Arrays.asList(contractElementOne, contractElementTwo));

        ContractsInMccDataResponse contractsInMccDataResponse = new ContractsInMccDataResponse();
        contractsInMccDataResponse.setDataList(dataList);

        ContractsInMccControllerResponse contractsInMccControllerResponse = new ContractsInMccControllerResponse();
        contractsInMccControllerResponse.setDataResponse(contractsInMccDataResponse);

        return contractsInMccControllerResponse;
    }
}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusIoc;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.validations.*;
import org.junit.Assert;
import org.junit.Test;

public class ExceptionsTest {

    @Test
    public void checkExcValidationBdpCustomerNumber() {
        ExcValidationBdpCustomerNumber excValidationBdpCustomerNumber = new ExcValidationBdpCustomerNumber();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_BDPCUSTOMERNUMBER.getErrorMessage().equals(excValidationBdpCustomerNumber.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_BDPCUSTOMERNUMBER.getErrorCode().equals(excValidationBdpCustomerNumber.getCode())
        );

        Assert.assertTrue(excValidationBdpCustomerNumber.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_BDPCUSTOMERNUMBER\",\"message\":\"Input input.BdpCustomer field format invalid\"}"));
    }

    @Test
    public void checkExcValidationBdpCustomerNumberEmpty() {
        ExcValidationBdpCustomerNumberEmpty excValidationBdpCustomerNumberEmpty = new ExcValidationBdpCustomerNumberEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_BDPCUSTOMERNUMBER_EMPTY.getErrorMessage().equals(excValidationBdpCustomerNumberEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_BDPCUSTOMERNUMBER_EMPTY.getErrorCode().equals(excValidationBdpCustomerNumberEmpty.getCode())
        );
        Assert.assertTrue(excValidationBdpCustomerNumberEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_BDPCUSTOMERNUMBER_EMPTY\",\"message\":\"Mandatory Input input.BdpCustomer field is empty\"}"));
    }

    @Test
    public void checkExcValidationChannel() {
        ExcValidationChannel excValidationChannel = new ExcValidationChannel();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_CHANNEL.getErrorMessage().equals(excValidationChannel.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_CHANNEL.getErrorCode().equals(excValidationChannel.getCode())
        );
        Assert.assertTrue(excValidationChannel.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_CHANNEL\",\"message\":\"Input field inputChannel format is not valid\"}"));
    }

    @Test
    public void checkExcValidationCompany() {
        ExcValidationCompany excValidationCompany = new ExcValidationCompany();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_COMPANY.getErrorMessage().equals(excValidationCompany.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_COMPANY.getErrorCode().equals(excValidationCompany.getCode())
        );
        Assert.assertTrue(excValidationCompany.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_COMPANY\",\"message\":\"Input company field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationConectionChannelEmpty() {
        ExcValidationConectionChannelEmpty excValidationConectionChannelEmpty = new ExcValidationConectionChannelEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_CONNECTIONCHANNEL_EMPTY.getErrorMessage().equals(excValidationConectionChannelEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_CONNECTIONCHANNEL_EMPTY.getErrorCode().equals(excValidationConectionChannelEmpty.getCode())
        );

        Assert.assertTrue(excValidationConectionChannelEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_CONNECTIONCHANNEL_EMPTY\",\"message\":\"Mandatory input input.connectionChannel field is empty\"}"));
    }

    @Test
    public void checkExcValidationDataRequestEmpty() {
        ExcValidationDataRequestEmpty excValidationDataRequestEmpty = new ExcValidationDataRequestEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_DATAREQUEST_EMPTY.getErrorMessage().equals(excValidationDataRequestEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_DATAREQUEST_EMPTY.getErrorCode().equals(excValidationDataRequestEmpty.getCode())
        );
        Assert.assertTrue(excValidationDataRequestEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_DATAREQUEST_EMPTY\",\"message\":\"Mandatory Input dataRequest field is empty\"}"));
    }

    @Test
    public void checkExcValidationElectronicChannelEmpty() {
        ExcValidationElectronicChannelEmpty excValidationElectronicChannelEmpty = new ExcValidationElectronicChannelEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_ELECTRONICCHANNEL_EMPTY.getErrorMessage().equals(excValidationElectronicChannelEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_ELECTRONICCHANNEL_EMPTY.getErrorCode().equals(excValidationElectronicChannelEmpty.getCode())
        );

        Assert.assertTrue(excValidationElectronicChannelEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_ELECTRONICCHANNEL_EMPTY\",\"message\":\"Mandatory input input.electronicChannel field is empty\"}"));
    }

    @Test
    public void checkExcValidationInputChannelEmpty() {
        ExcValidationInputChannelEmpty excValidationInputChannelEmpty = new ExcValidationInputChannelEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_INPUT_CHANNEL_EMPTY.getErrorMessage().equals(excValidationInputChannelEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_INPUT_CHANNEL_EMPTY.getErrorCode().equals(excValidationInputChannelEmpty.getCode())
        );
        Assert.assertTrue(excValidationInputChannelEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_INPUT_CHANNEL_EMPTY\",\"message\":\"Mandatory Input inputChannel field is empty\"}"));
    }

    @Test
    public void checkExcValidationInputCompanyEmpty() {
        ExcValidationInputCompanyEmpty excValidationInputCompanyEmpty = new ExcValidationInputCompanyEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_INPUT_COMPANY_EMPTY.getErrorMessage().equals(excValidationInputCompanyEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_INPUT_COMPANY_EMPTY.getErrorCode().equals(excValidationInputCompanyEmpty.getCode())
        );

        Assert.assertTrue(excValidationInputCompanyEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_INPUT_COMPANY_EMPTY\",\"message\":\"Mandatory Input company field is empty\"}"));
    }

    @Test
    public void checkExcValidationInputEmpty() {
        ExcValidationInputEmpty excValidationInputEmpty = new ExcValidationInputEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_INPUT_EMPTY.getErrorMessage().equals(excValidationInputEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_INPUT_EMPTY.getErrorCode().equals(excValidationInputEmpty.getCode())
        );
        Assert.assertTrue(excValidationInputEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_INPUT_EMPTY\",\"message\":\"Mandatory Input input field is empty\"}"));
    }

    @Test
    public void checkExcValidationInputLdapUidEmpty() {
        ExcValidationInputLdapUidEmpty excValidationInputLdapUidEmpty = new ExcValidationInputLdapUidEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_INPUT_LDAPUID_EMPTY.getErrorMessage().equals(excValidationInputLdapUidEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_INPUT_LDAPUID_EMPTY.getErrorCode().equals(excValidationInputLdapUidEmpty.getCode())
        );
        Assert.assertTrue(excValidationInputLdapUidEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_INPUT_LDAPUID_EMPTY\",\"message\":\"Mandatory Input ldapUid field is empty\"}"));
    }

    @Test
    public void checkExcValidationInputOperationEmpty() {
        ExcValidationInputOperationEmpty excValidationInputOperationEmpty = new ExcValidationInputOperationEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_INPUT_OPERATION_EMPTY.getErrorMessage().equals(excValidationInputOperationEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_INPUT_OPERATION_EMPTY.getErrorCode().equals(excValidationInputOperationEmpty.getCode())
        );
        Assert.assertTrue(excValidationInputOperationEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_INPUT_OPERATION_EMPTY\",\"message\":\"Mandatory Input Input.operation field is empty\"}"));
    }

    @Test
    public void checkExcValidationInputOptionEmpty() {
        ExcValidationInputOptionEmpty excValidationInputOptionEmpty = new ExcValidationInputOptionEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_INPUT_OPTION_EMPTY.getErrorMessage().equals(excValidationInputOptionEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_INPUT_OPTION_EMPTY.getErrorCode().equals(excValidationInputOptionEmpty.getCode())
        );
        Assert.assertTrue(excValidationInputOptionEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_INPUT_OPTION_EMPTY\",\"message\":\"Mandatory Input option field is empty\"}"));
    }

    @Test
    public void checkExcValidationInputProfileEmpty() {
        ExcValidationInputProfileEmpty excValidationInputProfileEmpty = new ExcValidationInputProfileEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_INPUT_PROFILE_EMPTY.getErrorMessage().equals(excValidationInputProfileEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_INPUT_PROFILE_EMPTY.getErrorCode().equals(excValidationInputProfileEmpty.getCode())
        );

        Assert.assertTrue(excValidationInputProfileEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_INPUT_PROFILE_EMPTY\",\"message\":\"Mandatory Input profile field is empty\"}"));
    }

    @Test
    public void checkExcValidationMccPartenonContractEmpty() {
        ExcValidationMccPartenonContractEmpty excValidationMccPartenonContractEmpty = new ExcValidationMccPartenonContractEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_MCCPARTENONCONTRACT_EMPTY.getErrorMessage().equals(excValidationMccPartenonContractEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_MCCPARTENONCONTRACT_EMPTY.getErrorCode().equals(excValidationMccPartenonContractEmpty.getCode())
        );
        Assert.assertTrue(excValidationMccPartenonContractEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_MCCPARTENONCONTRACT_EMPTY\",\"message\":\"Mandatory Input input.mccPartenonContract field is empty\"}"));
    }

    @Test
    public void checkExcValidationOperation() {
        ExcValidationOperation excValidationOperation = new ExcValidationOperation();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_OPERATION.getErrorMessage().equals(excValidationOperation.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_OPERATION.getErrorCode().equals(excValidationOperation.getCode())
        );
        Assert.assertTrue(excValidationOperation.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_OPERATION\",\"message\":\"input operation field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationPartenonContract() {
        ExcValidationPartenonContract excValidationPartenonContract = new ExcValidationPartenonContract();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_PARTENONCONTRACT.getErrorMessage().equals(excValidationPartenonContract.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_PARTENONCONTRACT.getErrorCode().equals(excValidationPartenonContract.getCode())
        );
        Assert.assertTrue(excValidationPartenonContract.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_PARTENONCONTRACT\",\"message\":\"Input field partenonContract format is not valid\"}"));
    }

    @Test
    public void checkExcValidationPartenonContractEmpty() {
        ExcValidationPartenonContractEmpty ExcValidationPartenonContractEmpty = new ExcValidationPartenonContractEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_PARTENONCONTRACT_EMPTY.getErrorMessage().equals(ExcValidationPartenonContractEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_PARTENONCONTRACT_EMPTY.getErrorCode().equals(ExcValidationPartenonContractEmpty.getCode())
        );
        Assert.assertTrue(ExcValidationPartenonContractEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_PARTENONCONTRACT_EMPTY\",\"message\":\"Mandatory Input partenonContract field is empty\"}"));
    }

    @Test
    public void checkExcValidationPersonalizationChannelEmpty() {
        ExcValidationPersonalizationChannelEmpty excValidationPersonalizationChannelEmpty = new ExcValidationPersonalizationChannelEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_PERSONALIZATIONCHANNEL_EMPTY.getErrorMessage().equals(excValidationPersonalizationChannelEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_PERSONALIZATIONCHANNEL_EMPTY.getErrorCode().equals(excValidationPersonalizationChannelEmpty.getCode())
        );
        Assert.assertTrue(excValidationPersonalizationChannelEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_PERSONALIZATIONCHANNEL_EMPTY\",\"message\":\"Mandatory input input.personalizationChannel field is empty\"}"));
    }

    @Test
    public void checkExcValidationProfile() {
        ExcValidationProfile excValidationProfile = new ExcValidationProfile();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_PROFILE.getErrorMessage().equals(excValidationProfile.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_PROFILE.getErrorCode().equals(excValidationProfile.getCode())
        );
        Assert.assertTrue(excValidationProfile.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_PROFILE\",\"message\":\"Input profile field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationSecurityInputChannelEmpty() {
        ExcValidationSecurityInputChannelEmpty excValidationSecurityInputChannelEmpty = new ExcValidationSecurityInputChannelEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_SECURITYINPUTCHANNEL_EMPTY.getErrorMessage().equals(excValidationSecurityInputChannelEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_SECURITYINPUTCHANNEL_EMPTY.getErrorCode().equals(excValidationSecurityInputChannelEmpty.getCode())
        );
        Assert.assertTrue(excValidationSecurityInputChannelEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_SECURITYINPUTCHANNEL_EMPTY\",\"message\":\"Mandatory Input securityInput.channel field is empty\"}"));
    }

    @Test
    public void checkExcValidationSecurityInputEmpty() {
        ExcValidationSecurityInputEmpty excValidationSecurityInputEmpty = new ExcValidationSecurityInputEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_SECURITYINPUT_EMPTY.getErrorMessage().equals(excValidationSecurityInputEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_SECURITYINPUT_EMPTY.getErrorCode().equals(excValidationSecurityInputEmpty.getCode())
        );
        Assert.assertTrue(excValidationSecurityInputEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_SECURITYINPUT_EMPTY\",\"message\":\"Mandatory Input securityInput field is empty\"}"));
    }

    @Test
    public void checkExcValidationServiceEmpty() {
        ExcValidationServiceEmpty excValidationServiceEmpty = new ExcValidationServiceEmpty();
        Assert.assertTrue(
                ExceptionValidationEnum.EXC_VAL_SERVICE_EMPTY.getErrorMessage().equals(excValidationServiceEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_SERVICE_EMPTY.getErrorCode().equals(excValidationServiceEmpty.getCode())
        );
        Assert.assertTrue(excValidationServiceEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_SERVICE_EMPTY\",\"message\":\"Mandatory Input input.service field is empty\"}"));
    }

    @Test
    public void checkExcBusIsc() {
        ExcBusIoc excBusIoc = new ExcBusIoc();
        Assert.assertTrue(excBusIoc.toString().equalsIgnoreCase("{\"code\":\"EXC_BUS_IOC\",\"message\":\"Error detected in IOC response\"}"));
    }

    @Test
    public void checkExcBusViewOnly() {
        String expectedCode = "EXC_BUS_VIEW_ONLY";
        String expectedMessage = "Credential is View Only";

        ExcBusViewOnly exc = new ExcBusViewOnly();
        Assert.assertEquals("Exception ExcBusViewOnly code not as expected ", expectedCode, exc.getCode());
        Assert.assertEquals("Exception ExcBusViewOnly message not as expected ", expectedMessage, exc.getMessage());
        Assert.assertTrue("toString() is not showing the proper values", exc.toString().equalsIgnoreCase("{\"code\":\"EXC_BUS_VIEW_ONLY\",\"message\":\"Credential is View Only\"}"));
    }


}

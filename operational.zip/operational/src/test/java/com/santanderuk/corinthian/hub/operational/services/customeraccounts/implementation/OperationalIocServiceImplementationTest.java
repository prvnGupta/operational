package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccDataResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities.IOCConnection;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.DataResponse;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.OperationalIocData;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

@ExtendWith(MockitoExtension.class)
public class OperationalIocServiceImplementationTest {

    @Mock
    OperationIocDataConverter operationIocDataConverter;
    @MockBean
    IOCConnection iocConnection;
    @InjectMocks
    OperationalIocServiceImplementation serviceImplementation;
    @Mock
    private OperationalIocDataAccess operationalIocDataAccess;

    @Before
    public void setUp() {
        initMocks(this);
    }

    @Test
    public void testHappyPath() throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {
        String ldapUid = "ldap-uid";
        String jwtAuth = "jwt-auth";

        OperationalIocData mockData = new OperationalIocData();
        ContractsInMccControllerResponse contractsInMccControllerResponse = new ContractsInMccControllerResponse();
        contractsInMccControllerResponse.setDataResponse(new ContractsInMccDataResponse());
        mockData.setContractsInMccControllerResponse(contractsInMccControllerResponse);
        DataResponse dataResponse = new DataResponse();

        when(operationalIocDataAccess.getData(ldapUid, jwtAuth)).thenReturn(mockData);
        when(operationIocDataConverter.iocToCorinthian(mockData)).thenReturn(dataResponse);

        DataResponse response = serviceImplementation.getCustomerAccounts(ldapUid, jwtAuth);
        assertThat(response, equalTo(dataResponse));
    }
}

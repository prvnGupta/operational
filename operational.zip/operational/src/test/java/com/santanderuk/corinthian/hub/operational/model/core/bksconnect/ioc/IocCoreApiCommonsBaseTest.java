package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.*;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.*;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccDataRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccDataResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoDataRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoDataResponse;
import com.santanderuk.corinthian.hub.operational.utils.FixtureReader;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

/**
 * Created by C0229411 on 15/12/2017.
 */
@RunWith(SpringRunner.class)
public abstract class IocCoreApiCommonsBaseTest {

    public static Profile genericProfile() {
        Profile profile = new Profile();
        profile.setChannel("OFI");
        profile.setCompany("0015");
        return profile;
    }

    public static PartenonContract genericPartenonContract() {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany("0015");
        centre.setCentreCode("0075");
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode("300");
        partenonContract.setContractNumber("1234567");
        return partenonContract;
    }

    public static PartenonContract customePartenonContract(String company, String centreStr, String product, String number) {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany(company);
        centre.setCentreCode(centreStr);
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode(product);
        partenonContract.setContractNumber(number);
        return partenonContract;
    }

    public static ServiceInfo genericServiceInfo() {
        return new ServiceInfo("Status", "Code", "Message");
    }

    public static ServiceInfo generateDefaultServiceInfo() {
        return new ServiceInfo("Status", "Code", "Message");
    }

    public static ServiceInfo generateCustomServiceInfo(String status, String code, String message) {
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setStatus(status);
        serviceInfo.setCode(code);
        serviceInfo.setMessage(message);
        return serviceInfo;
    }

    public RetrieveMccControllerRequest generateDefaultRequestRetrieveMcc() {
        RetrieveMccControllerRequest retrieveMccControllerRequest = new RetrieveMccControllerRequest();
        RetrieveMccDataRequest dataRequest = new RetrieveMccDataRequest();
        dataRequest.setProfile(genericProfile());
        dataRequest.setLdapUid("78p0KPs6");
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany("0015");
        partenonContract.setCentre(centre);
        dataRequest.setPartenonContract(partenonContract);
        dataRequest.setOption("2");
        dataRequest.setInputChannel("INT");
        dataRequest.setOperation("L");
        retrieveMccControllerRequest.setDataRequest(dataRequest);
        return retrieveMccControllerRequest;
    }

    public RetrieveMccInfoControllerRequest generateDefaultRequestRetrieveMccInfo() {
        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = new RetrieveMccInfoControllerRequest();

        RetrieveMccInfoDataRequest dataRequest = new RetrieveMccInfoDataRequest();
        dataRequest.setCompany("0015");
        dataRequest.setProfile(genericProfile());
        dataRequest.setConexionChannel("INT");
        dataRequest.setMccPartenonContract(generateDefaultPartenonContract());
        retrieveMccInfoControllerRequest.setDataRequest(dataRequest);
        return retrieveMccInfoControllerRequest;
    }

    public ContractsInMccControllerRequest generateDefaultRequestContractsInMcc() {
        ContractsInMccControllerRequest contractsInMccControllerRequest = new ContractsInMccControllerRequest();
        ContractsInMccDataRequest dataRequest = new ContractsInMccDataRequest();
        SecurityInput securityInput = new SecurityInput();
        securityInput.setChannel("OFI");
        securityInput.setBdpCustomer(generateDefaultBdpCustomer());
        securityInput.setPartenonContract(generateDefaultPartenonContract());
        dataRequest.setSecurityInput(securityInput);

        Input input = new Input();
        input.setService("50000193");
        input.setCompany("0015");
        input.setMccPartenonContract(generateDefaultPartenonContract());
        input.setBdpCustomer(generateDefaultBdpCustomer());
        input.setPersonalizationChannel("INT");
        input.setConexionChannel("INT");
        input.setElectronicChannel("INT");
        input.setOperation("L");
        input.setProfile(genericProfile());
        dataRequest.setInput(input);
        contractsInMccControllerRequest.setDataRequest(dataRequest);
        return contractsInMccControllerRequest;
    }

    public RetrieveMccControllerResponse generateDefaultResponseRetrieveMcc() {
        RetrieveMccControllerResponse retrieveMccControllerResponse = new RetrieveMccControllerResponse();
        ServiceInfo serviceInfo;
        serviceInfo = generateDefaultServiceInfo();
        retrieveMccControllerResponse.setInfo(serviceInfo);
        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setEndList("S");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(generateDefaultPartenonContract());

        dataResponse.setMccContract(mccContract);

        dataResponse.setLdapUid("78p0KPs6");
        dataResponse.setCurrency("GBP");
        dataResponse.setStatus("ACT");
        dataResponse.setModCapta("11");

        retrieveMccControllerResponse.setDataResponse(dataResponse);
        return retrieveMccControllerResponse;
    }

    private Centre generateDefaultCentre() {
        Centre centre = new Centre();
        centre.setCompany("0015");
        centre.setCentreCode("7740");
        return centre;
    }

    public RetrieveMccInfoControllerResponse generateDefaultResponseRetrieveMccInfo() {
        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = new RetrieveMccInfoControllerResponse();

        ServiceInfo serviceInfo;
        serviceInfo = generateDefaultServiceInfo();
        retrieveMccInfoControllerResponse.setInfo(serviceInfo);
        RetrieveMccInfoDataResponse dataResponse = new RetrieveMccInfoDataResponse();

        dataResponse.setBdpCustomer(generateDefaultBdpCustomer());

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setLdapUid("78p0KPs6");

        dataResponse.setMccType("0005");

        dataResponse.setMccOrigin("001");

        retrieveMccInfoControllerResponse.setDataResponse(dataResponse);

        return retrieveMccInfoControllerResponse;
    }

    private BdpCustomer generateDefaultBdpCustomer() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("F");
        bdpCustomer.setBdpCustomerCode(12345678);
        return bdpCustomer;
    }

    public static ContractsInMccControllerResponse generateDefaultResponseContractsInMcc() throws IOException {
        return FixtureReader.get("bks-connect-contracts-in-mcc-response-test.json", ContractsInMccControllerResponse.class);
    }


    public RetrieveMccControllerResponse generateOkResponseRetrieveMcc() {
        RetrieveMccControllerResponse retrieveMccControllerResponse = new RetrieveMccControllerResponse();
        retrieveMccControllerResponse.setInfo(generateCustomServiceInfo("ok", "", "Data found"));
        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setEndList("S");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(generateDefaultPartenonContract());

        dataResponse.setMccContract(mccContract);

        dataResponse.setLdapUid("78p0KPs6");
        dataResponse.setCurrency("GBP");
        dataResponse.setStatus("ACT");
        dataResponse.setModCapta("11");


        retrieveMccControllerResponse.setDataResponse(dataResponse);
        return retrieveMccControllerResponse;
    }

    public RetrieveMccInfoControllerResponse generateOkResponseRetrieveMccInfo() {
        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = new RetrieveMccInfoControllerResponse();

        retrieveMccInfoControllerResponse.setInfo(generateCustomServiceInfo("ok", "", "Data found"));
        RetrieveMccInfoDataResponse dataResponse = new RetrieveMccInfoDataResponse();

        dataResponse.setBdpCustomer(generateDefaultBdpCustomer());

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setLdapUid("78p0KPs6");

        dataResponse.setMccType("0005");

        dataResponse.setMccOrigin("001");

        retrieveMccInfoControllerResponse.setDataResponse(dataResponse);

        return retrieveMccInfoControllerResponse;
    }

    public ContractsInMccControllerResponse generateOkResponseContractsInMcc() throws IOException {

        return FixtureReader.get("bks-connect-contracts-in-mcc-response.json", ContractsInMccControllerResponse.class);
    }


    private PartenonContract generateDefaultPartenonContract() {
        PartenonContract partenonContract = new PartenonContract();
        partenonContract.setCentre(generateDefaultCentre());
        partenonContract.setProductTypeCode("520");
        partenonContract.setContractNumber("7589273");
        return partenonContract;
    }


    private KcError generateDefaultKcError() {
        KcError kcError = new KcError();
        kcError.setCodError("CodError");
        kcError.setDescError("DescError");
        kcError.setNext("next");
        kcError.setNextTRX("nextTrx");
        return kcError;
    }


    public RetrieveMccControllerResponse generate500ResponseRetrieveMcc() {
        RetrieveMccControllerResponse retrieveMccControllerResponse = new RetrieveMccControllerResponse();
        retrieveMccControllerResponse.setInfo(generateCustomServiceInfo("ko", "500", "Internal Server Error"));
        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setEndList("S");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(generateDefaultPartenonContract());

        dataResponse.setMccContract(mccContract);

        dataResponse.setLdapUid("78p0KPs6");
        dataResponse.setCurrency("GBP");
        dataResponse.setStatus("ACT");
        dataResponse.setModCapta("11");


        retrieveMccControllerResponse.setDataResponse(dataResponse);
        return retrieveMccControllerResponse;
    }


    public RetrieveMccInfoControllerResponse generate500ResponseRetrieveMccInfo() {
        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = new RetrieveMccInfoControllerResponse();

        retrieveMccInfoControllerResponse.setInfo(generateCustomServiceInfo("ko", "500", "Internal Server Error"));
        RetrieveMccInfoDataResponse dataResponse = new RetrieveMccInfoDataResponse();

        dataResponse.setBdpCustomer(generateDefaultBdpCustomer());

        dataResponse.setKcError(generateDefaultKcError());

        dataResponse.setLdapUid("78p0KPs6");

        dataResponse.setMccType("0005");

        dataResponse.setMccOrigin("001");

        retrieveMccInfoControllerResponse.setDataResponse(dataResponse);

        return retrieveMccInfoControllerResponse;
    }

    public ContractsInMccControllerResponse generate500ResponseContractsInMcc() {
        ContractsInMccControllerResponse contractsInMccControllerResponse = new ContractsInMccControllerResponse();
        contractsInMccControllerResponse.setInfo(generateCustomServiceInfo("ko", "500", "Internal Server Error"));


        return contractsInMccControllerResponse;
    }

}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.io;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.IocCoreApiCommonsBaseTest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerResponse;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;


public class ContractsInMccModelTests extends IocCoreApiCommonsBaseTest {


    @Test()
    public void contractsInMccControllerRequestToStringTest() {
        ContractsInMccControllerRequest contractsInMccControllerRequest = generateDefaultRequestContractsInMcc();

        Assert.assertTrue(contractsInMccControllerRequest.toString().equalsIgnoreCase("{\"dataRequest\":{\"input\":{\"profile\":{\"company\":\"0015\",\"channel\":\"OFI\"},\"operation\":\"L\",\"conexionChannel\":\"INT\",\"electronicChannel\":\"INT\",\"personalizationChannel\":\"INT\",\"reposCardPan\":null,\"cesta\":null,\"reposCesta\":null,\"bdpCustomer\":{\"bdpCustomertype\":\"F\",\"bdpCustomerCode\":12345678},\"mccPartenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":\"7740\"},\"productTypeCode\":\"520\",\"contractNumber\":\"7589273\"},\"reposPartenonContract\":null,\"company\":\"0015\",\"service\":\"50000193\",\"reposPresOrder\":null},\"securityInput\":{\"partenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":\"7740\"},\"productTypeCode\":\"520\",\"contractNumber\":\"7589273\"},\"bdpCustomer\":{\"bdpCustomertype\":\"F\",\"bdpCustomerCode\":12345678},\"channel\":\"OFI\"}}}"));
    }

    @Test()
    public void contractsInMccControllerResponseToStringTest() throws IOException {
        ContractsInMccControllerResponse contractsInMccControllerResponse = generateDefaultResponseContractsInMcc();
        assertEquals("{\"operativeSecurityOutput\":{\"center\":\"0075\",\"erorMessage\":\"Error\",\"errorCode\":\"12\"},\"kcError\":{\"descError\":\"DescError\",\"nextTRX\":\"NextTRX\",\"next\":\"Next\",\"codError\":\"CodError\",\"codMessage\":\"CodMessage\"},\"listEnd\":\"S\",\"repos\":{\"reposCesta\":{\"cestaCompany\":\"0015\",\"cestaCode\":\"BIAC\"},\"reposPartenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":\"7740\"},\"productTypeCode\":\"520\",\"contractNumber\":\"7589273\"},\"reposPresOrder\":0,\"reposCardPan\":\"1234123456789876\"},\"dataList\":{\"contractElement\":[{\"endDate\":\"9999-12-31T00:00:00.000Z\",\"alias\":\"BUSINESS SAVINGS ACCOUNT\",\"cardPan\":\"1234123412341234\",\"outCesta\":{\"cestaCompany\":\"0015\",\"cestaCode\":\"BIAC\"},\"productSubtype\":{\"productType\":{\"company\":\"0015\",\"productTypeCode\":\"300\"},\"productSubtypeCode\":\"701\"},\"contractDetails\":{\"localContract\":{\"localContractType\":\"07\",\"localContractNumber\":\"09012345678912\"},\"partenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":\"7740\"},\"productTypeCode\":\"520\",\"contractNumber\":\"7589273\"},\"iban\":{\"countryCode\":\"GB\",\"checkDigits\":\"01\",\"accNumber\":\"09012345678123\"},\"multiCountryIndicator\":\"N\",\"country\":\"GB\",\"searchType\":\"L\"},\"intervinientInd\":\"o\",\"relationInd\":\"relationInd\",\"statusIndicator\":\"A\",\"presOrder\":1,\"interventionType\":\"01\",\"intervinientQuality\":\"01\",\"cardCaducity\":12,\"pcasConcept\":{\"company\":\"0015\",\"pcasConceptCode\":\"12\",\"pcasConceptValue\":\"VISA\"},\"subTypeName\":\"SubtypeName\",\"interventionForm\":\"01\"}]},\"mccAccessType\":{\"company\":\"0015\",\"mccAccessTypeCode\":\"12\"},\"mccType\":\"MccType\"}", contractsInMccControllerResponse.getDataResponse().toString());
    }


}

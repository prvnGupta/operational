package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.IocCoreApiCommonsBaseTest;
import org.junit.Assert;
import org.junit.Test;

public class RetrieveMccModelTests extends IocCoreApiCommonsBaseTest {

    @Test()
    public void retrieveMccControllerRequestToStringTest() {
        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();
        Assert.assertTrue(retrieveMccControllerRequest.toString().equalsIgnoreCase("{\"dataRequest\":{\"profile\":{\"company\":\"0015\",\"channel\":\"OFI\"},\"operation\":\"L\",\"inputChannel\":\"INT\",\"option\":\"2\",\"partenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":null},\"productTypeCode\":null,\"contractNumber\":null},\"ldapUid\":\"78p0KPs6\"}}"));
    }

    @Test()
    public void retrieveMccControllerResponseToStringTest() {
        RetrieveMccControllerResponse retrieveMccControllerResponse = generateDefaultResponseRetrieveMcc();
        Assert.assertTrue(retrieveMccControllerResponse.getDataResponse().toString().equalsIgnoreCase("{\"kcError\":{\"codError\":\"CodError\",\"descError\":\"DescError\",\"next\":\"next\",\"nextTRX\":\"nextTrx\"},\"endList\":\"S\",\"mccContract\":{\"localContract\":null,\"partenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":\"7740\"},\"productTypeCode\":\"520\",\"contractNumber\":\"7589273\"},\"iban\":null},\"ldapUid\":\"78p0KPs6\",\"currency\":\"GBP\",\"status\":\"ACT\",\"modCapta\":\"11\"}"));
    }


}

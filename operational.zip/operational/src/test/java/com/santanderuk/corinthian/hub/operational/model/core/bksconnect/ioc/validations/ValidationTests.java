package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.validations;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.IocCoreApiCommonsBaseTest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.BdpCustomer;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Profile;
import org.junit.Assert;
import org.junit.Test;

public class ValidationTests extends IocCoreApiCommonsBaseTest {


    @Test
    public void isPartenonContract() {
        Assert.assertTrue(Validations.isPartenonContract(genericPartenonContract()));
    }

    @Test
    public void isPartenonContract2() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("qwer", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract3() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("!234", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract4() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("123", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract5() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("12345", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract6() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "!234", "520", "1234567")));
    }

    @Test
    public void isPartenonContract7() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "qwer", "520", "1234567")));
    }

    @Test
    public void isPartenonContract8() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "123", "520", "1234567")));
    }

    @Test
    public void isPartenonContract9() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "12345", "520", "1234567")));
    }

    @Test
    public void isPartenonContract10() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "!23", "1234567")));
    }

    @Test
    public void isPartenonContract11() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "qwe", "1234567")));
    }

    @Test
    public void isPartenonContract12() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "12", "1234567")));
    }

    @Test
    public void isPartenonContract13() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "1234", "1234567")));
    }

    @Test
    public void isPartenonContract14() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "!234567")));
    }

    @Test
    public void isPartenonContract15() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "qwertyu")));
    }

    @Test
    public void isPartenonContract16() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "123456")));
    }

    @Test
    public void isPartenonContract17() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "12345678")));
    }

    ////////////////////////////////////
    ///   isChannel                  ///
    ////////////////////////////////////
    @Test
    public void isChannel_null_OK() {
        Assert.assertTrue(Validations.isChannel(null));
    }

    @Test
    public void isChannel_emptyString_OK() {
        Assert.assertTrue(Validations.isChannel(""));
    }

    @Test
    public void isChannel_threeLetters_OK() {
        Assert.assertTrue(Validations.isChannel("OFI"));
    }

    @Test
    public void isChannel_threeNumbers_OK() {
        Assert.assertTrue(Validations.isChannel("123"));
    }

    @Test
    public void isChannel_twoLettersOneNumber_OK() {
        Assert.assertTrue(Validations.isChannel("OF8"));
    }

    @Test
    public void isChannel_oneLetterTwoNumbers_OK() {
        Assert.assertTrue(Validations.isChannel("0F8"));
    }

    @Test
    public void isChannel_oneLetter_KO() {
        Assert.assertFalse(Validations.isChannel("A"));
    }

    @Test
    public void isChannel_twoLetters_KO() {
        Assert.assertFalse(Validations.isChannel("AB"));
    }

    @Test
    public void isChannel_fourLetters_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_oneNumber_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_twoNumbers_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_fourNumbers_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_specialCharacters_KO() {
        Assert.assertFalse(Validations.isChannel("A£CD"));
    }

    ////////////////////////////////////
    ///   isProfile                  ///
    ////////////////////////////////////
    @Test
    public void isProfile_null_OK() {
        Assert.assertTrue(Validations.isProfile(null));
    }

    @Test
    public void isProfile_nullChannel_nullCompany_OK() {
        Profile profile = new Profile();
        profile.setChannel(null);
        profile.setCompany(null);
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_nullChannel_emptyCompany_OK() {
        Profile profile = new Profile();
        profile.setChannel(null);
        profile.setCompany("");
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_nullChannel_correctCompany_OK() {
        Profile profile = genericProfile();
        profile.setChannel(null);
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_nullChannel_lettersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel(null);
        profile.setCompany("ASBD");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_nullChannel_threeNumbersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel(null);
        profile.setCompany("123");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_nullChannel_fiveNumbersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel(null);
        profile.setCompany("12345");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_nullChannel_specialCharactersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel(null);
        profile.setCompany("123$");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_emptyChannel_nullCompany_OK() {
        Profile profile = new Profile();
        profile.setChannel("");
        profile.setCompany(null);
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_emptyChannel_emptyCompany_OK() {
        Profile profile = new Profile();
        profile.setChannel("");
        profile.setCompany("");
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_emptyChannel_correctCompany_OK() {
        Profile profile = genericProfile();
        profile.setChannel("");
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_emptyChannel_lettersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel("");
        profile.setCompany("ASBD");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_emptyChannel_threeNumbersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel("");
        profile.setCompany("123");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_emptyChannel_fiveNumbersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel("");
        profile.setCompany("12345");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_emptyChannel_specialCharactersCompany_KO() {
        Profile profile = new Profile();
        profile.setChannel("");
        profile.setCompany("123$");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_correctChannel_nullCompany_OK() {
        Profile profile = genericProfile();
        profile.setCompany(null);
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_correctChannel_emptyCompany_OK() {
        Profile profile = genericProfile();
        profile.setCompany("");
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_correctChannel_correctCompany_OK() {
        Profile profile = genericProfile();
        Assert.assertTrue(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_correctChannel_lettersCompany_KO() {
        Profile profile = genericProfile();
        profile.setCompany("ASBD");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_correctChannel_threeNumbersCompany_KO() {
        Profile profile = genericProfile();
        profile.setCompany("123");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_correctChannel_fiveNumbersCompany_KO() {
        Profile profile = genericProfile();
        profile.setCompany("12345");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_correctChannel_specialCharactersCompany_KO() {
        Profile profile = genericProfile();
        profile.setCompany("123$");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_longerChannel_correctCompany_KO() {
        Profile profile = genericProfile();
        profile.setChannel("1234");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_shorterChannel_correctCompany_KO() {
        Profile profile = genericProfile();
        profile.setChannel("12");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    @Test
    public void isProfile_specialCharactersChannel_correctCompany_KO() {
        Profile profile = genericProfile();
        profile.setChannel("12$");
        Assert.assertFalse(Validations.isProfile(profile));
    }

    ////////////////////////////////////
    ///   isCompany                  ///
    ////////////////////////////////////
    @Test
    public void isCompany_null_OK() {
        Assert.assertTrue(Validations.isCompany(null));
    }

    @Test
    public void isCompany_empty_OK() {
        Assert.assertTrue(Validations.isCompany(""));
    }

    @Test
    public void isCompany_correctCompany_OK() {
        Assert.assertTrue(Validations.isCompany("0015"));
    }

    @Test
    public void isCompany_shorterCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    @Test
    public void isCompany_longerCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    @Test
    public void isCompany_lettersCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    @Test
    public void isCompany_specialCharactersCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    ////////////////////////////////////
    ///   isOperation                  ///
    ////////////////////////////////////
    @Test
    public void isOperation_null_OK() {
        Assert.assertTrue(Validations.isOperation(null));
    }

    @Test
    public void isOperation_empty_OK() {
        Assert.assertTrue(Validations.isOperation(""));
    }

    @Test
    public void isOperation_L_OK() {
        Assert.assertTrue(Validations.isOperation("L"));
    }

    @Test
    public void isOperation_KO() {
        Assert.assertFalse(Validations.isOperation("!"));
    }

    @Test
    public void isOperation_KO1() {
        Assert.assertFalse(Validations.isOperation("!L"));
    }

    @Test
    public void isOperation_KO2() {
        Assert.assertFalse(Validations.isOperation("QQ"));
    }

    @Test
    public void isOperation_KO3() {
        Assert.assertFalse(Validations.isOperation("LL"));
    }

    @Test
    public void isBdpCustomer_OK() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("F");
        bdpCustomer.setBdpCustomerCode(123489);
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_OK2() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("F");
        bdpCustomer.setBdpCustomerCode(123456789);
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_OK3() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode(123489);
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_OK4() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode(123456789);
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_null_OK() {

        Assert.assertTrue(Validations.isBdpCustomer(null));

    }

    @Test
    public void isBdpCustomer_empty_OK() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("");
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode(1234567891);
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO2() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("F");
        bdpCustomer.setBdpCustomerCode(1234567891);
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO3() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("!");
        bdpCustomer.setBdpCustomerCode(123456789);
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO4() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode(1234567891);
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO5() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("Q");
        bdpCustomer.setBdpCustomerCode(123456789);
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }


}

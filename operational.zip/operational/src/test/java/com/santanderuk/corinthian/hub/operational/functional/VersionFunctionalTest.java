package com.santanderuk.corinthian.hub.operational.functional;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;


@ActiveProfiles("test")
public class VersionFunctionalTest extends FunctionalTest {

    String healthUrl;

    @Before
    public void setup() {
        healthUrl = String.format("http://localhost:%s/operational/version", serverPort);
    }

    @Test
    public void customVersionReturnsUp() throws Exception {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200);

    }

}

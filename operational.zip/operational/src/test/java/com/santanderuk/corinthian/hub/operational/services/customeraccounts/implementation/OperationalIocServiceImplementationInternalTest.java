package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.config.OperationalConfig;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Centre;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.MccContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccDataResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities.IOCConnection;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.OperationalIocData;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.eq;
import static org.mockito.MockitoAnnotations.initMocks;

@ExtendWith(MockitoExtension.class)
public class OperationalIocServiceImplementationInternalTest {

    @MockBean
    IOCConnection iocConnection;
    @InjectMocks
    OperationalIocServiceImplementation serviceImplementation;
    @Mock
    private OperationalIocDataAccess operationalIocDataAccess;
    @Mock
    private OperationIocDataConverter operationIocDataConverter;
    @MockBean
    private OperationalConfig operationalConfig;

    @Before
    public void setUp() {
        initMocks(this);
    }

    @Test
    public void nullDataResponseIsHandledInPostActions() throws GeneralException, com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {
        String ldapUid = "ldap-uid";
        String jwtAuth = "jwt-auth";


        OperationalIocData data = new OperationalIocData();
        final RetrieveMccControllerResponse retrieveMccControllerResponse = generateDefaultMccControllerResponse();
        data.setRetrieveMccControllerResponse(retrieveMccControllerResponse);
        final ContractsInMccControllerResponse contractsInMccControllerResponse = new ContractsInMccControllerResponse();
        data.setContractsInMccControllerResponse(contractsInMccControllerResponse);
        doReturn(data).when(this.operationalIocDataAccess).getData(eq(ldapUid), eq(jwtAuth));
        serviceImplementation.getCustomerAccounts(ldapUid, jwtAuth);
    }

    private RetrieveMccControllerResponse generateDefaultMccControllerResponse() {
        RetrieveMccControllerResponse retrieveMccControllerResponse = new RetrieveMccControllerResponse();
        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();
        retrieveMccControllerResponse.setDataResponse(dataResponse);
        MccContract mccContract = new MccContract();
        dataResponse.setMccContract(mccContract);
        PartenonContract partenonContract = new PartenonContract();
        mccContract.setPartenonContract(partenonContract);
        Centre centre = new Centre();
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode("1");
        partenonContract.setContractNumber("2");
        centre.setCompany("3");
        centre.setCentreCode("4");

        return retrieveMccControllerResponse;
    }

}

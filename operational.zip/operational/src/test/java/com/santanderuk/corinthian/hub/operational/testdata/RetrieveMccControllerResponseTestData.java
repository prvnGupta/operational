package com.santanderuk.corinthian.hub.operational.testdata;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.Centre;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.MccContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.PartenonContract;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccDataResponse;

/**
 * Created by c0253129 on 19/12/2017.
 */
public class RetrieveMccControllerResponseTestData {

    public static RetrieveMccControllerResponse get() {

        PartenonContract partenonContract = new PartenonContract();
        Centre partenonCentre = new Centre();
        partenonCentre.setCompany("0015");
        partenonCentre.setCentreCode("1234");
        partenonContract.setCentre(partenonCentre);
        partenonContract.setProductTypeCode("520");
        partenonContract.setContractNumber("1234567");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(partenonContract);

        RetrieveMccDataResponse retrieveMccDataResponse = new RetrieveMccDataResponse();
        retrieveMccDataResponse.setMccContract(mccContract);

        RetrieveMccControllerResponse retrieveMccControllerResponse = new RetrieveMccControllerResponse();
        retrieveMccControllerResponse.setDataResponse(retrieveMccDataResponse);

        return retrieveMccControllerResponse;

    }
}

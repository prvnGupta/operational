package com.santanderuk.corinthian.hub.operational.testdata;


import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.*;

import java.math.BigDecimal;
import java.util.Arrays;

public class AccountBalanceControllerResponseTestData {

    public static AccountBalanceControllerResponse get() {

        Balance1 balance1 = new Balance1();
        balance1.setAmount(new BigDecimal("100.00"));
        balance1.setCurrency("GBP");

        Balance2 balance2 = new Balance2();
        balance2.setAmount(new BigDecimal("200.00"));
        balance2.setCurrency("GBP");

        OutElement outElement = new OutElement();
        outElement.setBalance1(balance1);
        outElement.setBalance2(balance2);

        OutElementList outElementList = new OutElementList();
        outElementList.setOutElement(Arrays.asList(outElement));

        AccountBalanceDataResponse dataResponse = new AccountBalanceDataResponse();
        dataResponse.setOutElementList(outElementList);

        AccountBalanceControllerResponse response = new AccountBalanceControllerResponse();
        response.setDataResponse(dataResponse);

        return response;
    }
}

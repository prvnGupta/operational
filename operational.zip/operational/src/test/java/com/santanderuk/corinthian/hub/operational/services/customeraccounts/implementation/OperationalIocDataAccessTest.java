package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.config.OperationalConfig;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.*;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.*;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccDataResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoDataResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities.IOCConnection;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities.ServiceInfoCreator;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.OperationalIocData;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.AccountBalancesClient;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalance;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;


@ExtendWith(MockitoExtension.class)
public class OperationalIocDataAccessTest {

    OperationalIocDataAccess iocDataAccess;
    @Mock
    private IOCConnection iocConnection;
    @Mock
    private OperationalConfig operationalConfig;
    @Mock
    private AccountBalancesClient accountBalancesClient;

    @BeforeEach
    public void setUp() {
        initMocks(this);
        iocDataAccess = new OperationalIocDataAccess(iocConnection, operationalConfig, accountBalancesClient);
    }

    @Test
    public void testWeCallAccountBalancesClient() throws ExcBusViewOnly, GeneralException, ConnectionException, ValidationsException {

        when(iocConnection.retrieveMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultRetrieveMccControllerResponse());
        when(iocConnection.retrieveMccInfo(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateRetrieveMccInfoControllerResponse());
        when(iocConnection.contractsInMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultContractsInMccControllerResponse());

        iocDataAccess.getData("ldap-uid", "jwt");

        verify(accountBalancesClient, Mockito.times(1)).fetchBalances(eq(null), eq(Collections.singletonList("012345678901234567")));
    }

    @Test
    public void testWeCallAccountBalancesClientWithCorrectListOfContractIds() throws ExcBusViewOnly, GeneralException, ConnectionException, ValidationsException {

        when(iocConnection.retrieveMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultRetrieveMccControllerResponse());
        when(iocConnection.retrieveMccInfo(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateRetrieveMccInfoControllerResponse());
        when(iocConnection.contractsInMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateMultipleContractsInMccControllerResponse());

        iocDataAccess.getData("ldap-uid", "jwt");

        verify(accountBalancesClient, Mockito.times(1)).fetchBalances(eq(null), eq(Arrays.asList("012345678901234567", "123456789012345678", "234567890123456789")));
    }

    @Test
    void testWeWriteAccountBalancesDataToOperationalIocData() throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {

        when(iocConnection.retrieveMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultRetrieveMccControllerResponse());
        when(iocConnection.retrieveMccInfo(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateRetrieveMccInfoControllerResponse());
        when(iocConnection.contractsInMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultContractsInMccControllerResponse());
        when(accountBalancesClient.fetchBalances(eq(null), eq(Collections.singletonList("012345678901234567")))).thenReturn(generateDefaultAccountBalancesResponse());

        OperationalIocData operationalIocData = iocDataAccess.getData("ldap-uid", "jwt");

        assertAll(() -> {
            assertNotNull(operationalIocData.getAccountBalancesResponse());

            AccountBalance accountBalance = operationalIocData.getAccountBalancesResponse().getAccountBalances().get(0);
            assertThat(accountBalance.getPartenonContractId(), equalTo("01234556789"));
            assertThat(accountBalance.getAuthorizedOverdraft(), equalTo("1000.00 C"));
            assertThat(accountBalance.getFinancialBalance(), equalTo("100.00 C"));
            assertThat(accountBalance.getBalanceIncPending(), equalTo("200.00 C"));
            assertThat(accountBalance.getOverdraftRemaining(), equalTo("600.00 C"));
            assertThat(accountBalance.getTemporaryOverdraft(), equalTo("0.00 C"));
            assertThat(accountBalance.getCurrencyCode(), equalTo("GBP"));
        });
    }

    @Test
    void testWeThrowValidationsExceptionUpTheStack() throws GeneralException, ConnectionException, ValidationsException {

        when(iocConnection.retrieveMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultRetrieveMccControllerResponse());
        when(iocConnection.retrieveMccInfo(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateRetrieveMccInfoControllerResponse());
        when(iocConnection.contractsInMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultContractsInMccControllerResponse());
        when(accountBalancesClient.fetchBalances(eq(null), eq(Collections.singletonList("012345678901234567")))).thenThrow(ValidationsException.class);

        assertThrows(ValidationsException.class, () -> iocDataAccess.getData("ldap-uid", "jwt"));
    }

    @Test
    void testWeThrowConnectionExceptionUpTheStack() throws GeneralException, ConnectionException, ValidationsException {

        when(iocConnection.retrieveMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultRetrieveMccControllerResponse());
        when(iocConnection.retrieveMccInfo(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateRetrieveMccInfoControllerResponse());
        when(iocConnection.contractsInMcc(eq(null), any(), eq("jwt"), eq(null))).thenReturn(generateDefaultContractsInMccControllerResponse());
        when(accountBalancesClient.fetchBalances(eq(null), eq(Collections.singletonList("012345678901234567")))).thenThrow(ConnectionException.class);

        assertThrows(ConnectionException.class, () -> iocDataAccess.getData("ldap-uid", "jwt"));
    }

    private RetrieveMccControllerResponse generateDefaultRetrieveMccControllerResponse() {

        RetrieveMccControllerResponse retrieveMccControllerResponse = new RetrieveMccControllerResponse();

        ServiceInfo info = ServiceInfoCreator.ok();
        retrieveMccControllerResponse.setInfo(info);

        RetrieveMccDataResponse dataResponse = new RetrieveMccDataResponse();
        MccContract mccContract = new MccContract();
        PartenonContract partenonContract = new PartenonContract();
        mccContract.setPartenonContract(partenonContract);
        dataResponse.setMccContract(mccContract);
        retrieveMccControllerResponse.setDataResponse(dataResponse);

        return retrieveMccControllerResponse;
    }

    private RetrieveMccInfoControllerResponse generateRetrieveMccInfoControllerResponse() {

        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = new RetrieveMccInfoControllerResponse();

        RetrieveMccInfoDataResponse dataResponse = new RetrieveMccInfoDataResponse();
        BdpCustomer bdpCustomer = new BdpCustomer();
        dataResponse.setBdpCustomer(bdpCustomer);
        retrieveMccInfoControllerResponse.setDataResponse(dataResponse);

        return retrieveMccInfoControllerResponse;
    }

    private ContractsInMccControllerResponse generateDefaultContractsInMccControllerResponse() {
        ContractsInMccControllerResponse contractsInMccControllerResponse = new ContractsInMccControllerResponse();
        ContractsInMccDataResponse dataResponse = new ContractsInMccDataResponse();
        DataList dataList = new DataList();
        List<ContractElement> contractElements = new ArrayList<>();
        ContractElement contractElement = generateContractElement("0123", "4567", "890", "1234567");
        contractElements.add(contractElement);
        dataList.setContractElement(contractElements);
        dataResponse.setDataList(dataList);
        contractsInMccControllerResponse.setDataResponse(dataResponse);
        return contractsInMccControllerResponse;
    }

    private ContractsInMccControllerResponse generateMultipleContractsInMccControllerResponse() {
        ContractsInMccControllerResponse contractsInMccControllerResponse = generateDefaultContractsInMccControllerResponse();
        List<ContractElement> contractElements = contractsInMccControllerResponse.getDataResponse().getDataList().getContractElement();
        ContractElement contractElementOne = generateContractElement("1234", "5678", "901", "2345678");
        ContractElement contractElementTwo = generateContractElement("2345", "6789", "012", "3456789");
        contractElements.add(contractElementOne);
        contractElements.add(contractElementTwo);
        return contractsInMccControllerResponse;
    }

    private ContractElement generateContractElement(String company, String centreCode, String productCode, String contractNumber) {
        ContractElement contractElement = new ContractElement();
        ContractDetails contractDetails = new ContractDetails();
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany(company);
        centre.setCentreCode(centreCode);
        partenonContract.setProductTypeCode(productCode);
        partenonContract.setContractNumber(contractNumber);
        partenonContract.setCentre(centre);
        contractDetails.setPartenonContract(partenonContract);
        contractElement.setContractDetails(contractDetails);
        return contractElement;
    }

    private AccountBalancesResponse generateDefaultAccountBalancesResponse() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AccountBalance> accountBalances = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setPartenonContractId("01234556789");
        accountBalance.setFinancialBalance("100.00 C");
        accountBalance.setBalanceIncPending("200.00 C");
        accountBalance.setOverdraftRemaining("600.00 C");
        accountBalance.setAuthorizedOverdraft("1000.00 C");
        accountBalance.setTemporaryOverdraft("0.00 C");
        accountBalance.setCurrencyCode("GBP");
        accountBalances.add(accountBalance);
        accountBalancesResponse.setAccountBalances(accountBalances);
        return accountBalancesResponse;
    }
}

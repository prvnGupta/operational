package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.IocCoreApiCommonsBaseTest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.GeneralException;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by c0229411 on 15/12/2017.
 */
public class ServiceInfoCreatorTest extends IocCoreApiCommonsBaseTest {

    @Test
    public void ok_checkCorrectServiceInfo_correctStatus() {
        Assert.assertEquals("ok", ServiceInfoCreator.ok().getStatus());
    }

    @Test
    public void ok_checkCorrectServiceInfo_correctCode() {
        Assert.assertEquals("", ServiceInfoCreator.ok().getCode());
    }

    @Test()
    public void exception_checkCorrectStatus() {
        Assert.assertEquals("ko", ServiceInfoCreator.exception(new GeneralException("CODE", "MESSAGE")).getStatus());
    }

    @Test()
    public void exception_checkCorrectCode() {
        Assert.assertEquals("CODE", ServiceInfoCreator.exception(new GeneralException("CODE", "MESSAGE")).getCode());
    }

    @Test()
    public void exception_checkCorrectMessage() {
        Assert.assertEquals("MESSAGE", ServiceInfoCreator.exception(new GeneralException("CODE", "MESSAGE")).getMessage());
    }
}

package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.utilities;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.commons.exceptions.business.ExcBusIoc;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.IocCoreApiCommonsBaseTest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.contractsinmcc.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemcc.RetrieveMccControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;

public class IOCConnectionTest extends IocCoreApiCommonsBaseTest {


    @InjectMocks
    @Spy
    IOCConnection iocConnection;

    @MockBean
    RestTemplate restTemplate;

    @Before
    public void setUp() {

        restTemplate = mock(RestTemplate.class);

        //inject mocks
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testDefaultRetrieveMcc() throws GeneralException {

        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();

        RetrieveMccControllerResponse retrieveMccControllerResponse = generateDefaultResponseRetrieveMcc();
        ResponseEntity<RetrieveMccControllerResponse> responseEntity
                = new ResponseEntity<>(retrieveMccControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccControllerResponse.class)))
                .thenReturn(responseEntity);

        RetrieveMccControllerResponse response = iocConnection.retrieveMcc("/any/url", retrieveMccControllerRequest, "jwt", "clientId");

        assertEquals("Status", response.getInfo().getStatus());
        assertEquals("Code", response.getInfo().getCode());
        assertEquals("Message", response.getInfo().getMessage());
    }

    @Test
    public void testDefaultRetrieveMccInfo() throws GeneralException {

        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = generateDefaultRequestRetrieveMccInfo();

        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = generateDefaultResponseRetrieveMccInfo();
        ResponseEntity<RetrieveMccInfoControllerResponse> responseEntity
                = new ResponseEntity<>(retrieveMccInfoControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccInfoControllerResponse.class)))
                .thenReturn(responseEntity);

        RetrieveMccInfoControllerResponse response = iocConnection.retrieveMccInfo("/any/url", retrieveMccInfoControllerRequest, "jwt", "clientId");

        assertEquals("Status", response.getInfo().getStatus());
        assertEquals("Code", response.getInfo().getCode());
        assertEquals("Message", response.getInfo().getMessage());
    }

    @Test
    public void testDefaultContractsInMcc() throws GeneralException, IOException {

        ContractsInMccControllerRequest contractsInMccControllerRequest = generateDefaultRequestContractsInMcc();

        ContractsInMccControllerResponse contractsInMccControllerResponse = generateDefaultResponseContractsInMcc();
        ResponseEntity<ContractsInMccControllerResponse> responseEntity
                = new ResponseEntity<>(contractsInMccControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(ContractsInMccControllerResponse.class)))
                .thenReturn(responseEntity);

        ContractsInMccControllerResponse response = iocConnection.contractsInMcc("/any/url", contractsInMccControllerRequest, "jwt", "clientId");

        assertEquals("Status", response.getInfo().getStatus());
        assertEquals("Code", response.getInfo().getCode());
        assertEquals("Message", response.getInfo().getMessage());
    }

    @Test
    public void testHappyPathRetrieveMcc() throws GeneralException {

        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();

        RetrieveMccControllerResponse retrieveMccControllerResponse = generateOkResponseRetrieveMcc();
        ResponseEntity<RetrieveMccControllerResponse> responseEntity
                = new ResponseEntity<>(retrieveMccControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccControllerResponse.class)))
                .thenReturn(responseEntity);

        RetrieveMccControllerResponse response = iocConnection.retrieveMcc("/any/url", retrieveMccControllerRequest, "jwt", "clientId");

        assertEquals("ok", response.getInfo().getStatus());
        assertEquals("", response.getInfo().getCode());
        assertEquals("Data found", response.getInfo().getMessage());
    }

    @Test
    public void testHappyPathRetrieveMccInfo() throws GeneralException {

        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = generateDefaultRequestRetrieveMccInfo();

        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = generateOkResponseRetrieveMccInfo();
        ResponseEntity<RetrieveMccInfoControllerResponse> responseEntity
                = new ResponseEntity<>(retrieveMccInfoControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccInfoControllerResponse.class)))
                .thenReturn(responseEntity);

        RetrieveMccInfoControllerResponse response = iocConnection.retrieveMccInfo("/any/url", retrieveMccInfoControllerRequest, "jwt", "clientId");

        assertEquals("ok", response.getInfo().getStatus());
        assertEquals("", response.getInfo().getCode());
        assertEquals("Data found", response.getInfo().getMessage());
    }

    @Test
    public void testHappyPathContractsInMcc() throws GeneralException, IOException {

        ContractsInMccControllerRequest contractsInMccControllerRequest = generateDefaultRequestContractsInMcc();

        ContractsInMccControllerResponse contractsInMccControllerResponse = generateOkResponseContractsInMcc();
        ResponseEntity<ContractsInMccControllerResponse> responseEntity
                = new ResponseEntity<>(contractsInMccControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(ContractsInMccControllerResponse.class)))
                .thenReturn(responseEntity);

        ContractsInMccControllerResponse response = iocConnection.contractsInMcc("/any/url", contractsInMccControllerRequest, "jwt", "clientId");

        assertEquals("ok", response.getInfo().getStatus());
        assertEquals("", response.getInfo().getCode());
        assertEquals("Data found", response.getInfo().getMessage());
    }

    @Test(expected = GeneralException.class)
    public void testGeneralExceptionRetrieveMcc() throws GeneralException {
        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccControllerResponse.class)))
                .thenThrow(RestClientException.class);
        iocConnection.retrieveMcc("/any/url", retrieveMccControllerRequest, "jwt", "clientId");
    }

    @Test(expected = ExcBusIoc.class)
    public void testIscBusExcRetrieveMcc() throws GeneralException {

        RetrieveMccControllerRequest retrieveMccControllerRequest = generateDefaultRequestRetrieveMcc();

        RetrieveMccControllerResponse retrieveMccControllerResponse = generate500ResponseRetrieveMcc();
        ResponseEntity<RetrieveMccControllerResponse> responseEntity
                = new ResponseEntity<>(retrieveMccControllerResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccControllerResponse.class)))
                .thenReturn(responseEntity);

        iocConnection.retrieveMcc("/any/url", retrieveMccControllerRequest, "jwt", "clientId");
    }

    @Test(expected = GeneralException.class)
    public void testGeneralExceptionRetrieveMccInfo() throws GeneralException {
        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = generateDefaultRequestRetrieveMccInfo();
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccInfoControllerResponse.class)))
                .thenThrow(RestClientException.class);
        iocConnection.retrieveMccInfo("/any/url", retrieveMccInfoControllerRequest, "jwt", "clientId");
    }

    @Test(expected = ExcBusIoc.class)
    public void testIscBusExcRetrieveMccInfo() throws GeneralException {

        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = generateDefaultRequestRetrieveMccInfo();

        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = generate500ResponseRetrieveMccInfo();
        ResponseEntity<RetrieveMccInfoControllerResponse> responseEntity
                = new ResponseEntity<>(retrieveMccInfoControllerResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(RetrieveMccInfoControllerResponse.class)))
                .thenReturn(responseEntity);

        iocConnection.retrieveMccInfo("/any/url", retrieveMccInfoControllerRequest, "jwt", "clientId");
    }

    @Test(expected = GeneralException.class)
    public void testGeneralExceptionContractsInMcc() throws GeneralException {
        ContractsInMccControllerRequest contractsInMccControllerRequest = generateDefaultRequestContractsInMcc();
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(ContractsInMccControllerResponse.class)))
                .thenThrow(RestClientException.class);
        iocConnection.contractsInMcc("/any/url", contractsInMccControllerRequest, "jwt", "clientId");
    }

    @Test(expected = ExcBusIoc.class)
    public void testIscBusExcContractsInMcc() throws GeneralException {

        ContractsInMccControllerRequest contractsInMccControllerRequest = generateDefaultRequestContractsInMcc();

        ContractsInMccControllerResponse contractsInMccControllerResponse = generate500ResponseContractsInMcc();
        ResponseEntity<ContractsInMccControllerResponse> responseEntity
                = new ResponseEntity<>(contractsInMccControllerResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(ContractsInMccControllerResponse.class)))
                .thenReturn(responseEntity);

        iocConnection.contractsInMcc("/any/url", contractsInMccControllerRequest, "jwt", "clientId");
    }


}

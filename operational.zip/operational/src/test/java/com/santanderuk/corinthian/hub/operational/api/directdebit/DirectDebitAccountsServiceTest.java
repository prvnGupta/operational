package com.santanderuk.corinthian.hub.operational.api.directdebit;

import com.santanderuk.corinthian.hub.operational.exception.NoDirectDebitAccountException;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.AccountBalancesClient;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.clients.directdebit.InternalAccountsClient;
import com.santanderuk.corinthian.services.commons.clients.directdebit.io.Account;
import com.santanderuk.corinthian.services.commons.clients.directdebit.io.InternalAccountsResponse;
import com.santanderuk.corinthian.services.commons.clients.directdebit.io.QueryParams;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DirectDebitAccountsServiceTest {

    private DirectDebitAccountsService service;

    @Mock
    private InternalAccountsClient mockAccountsClient;
    @Mock
    private AccountBalancesClient mockBalancesClient;
    @Mock
    private DirectDebitAccountsMapper mockMapper;

    @BeforeEach
    void setUp() {
        service = new DirectDebitAccountsService(mockAccountsClient, mockBalancesClient, mockMapper);
    }

    @Test
    void shouldReturnDirectDebitAccounts() throws GeneralException, NoDirectDebitAccountException {
        when(mockAccountsClient.directDebitEligibleAccounts(any(), any(QueryParams.class))).thenReturn(createAccountsResponse());
        when(mockBalancesClient.fetchBalances(any(), any())).thenReturn(new AccountBalancesResponse());

        service.getDirectDebitAccounts("ldapUid");

        verify(mockAccountsClient, times(1)).directDebitEligibleAccounts(any(), any(QueryParams.class));
        verify(mockBalancesClient, times(1)).fetchBalances(any(), any());
        verify(mockMapper, times(1)).mapDirectDebitAccounts(any(), any());
    }

    @Test
    void shouldThrowNoDirectDebitAccountException() throws GeneralException {

        when(mockAccountsClient.directDebitEligibleAccounts(any(), any(QueryParams.class))).thenReturn(createEmptyAccountsResponse());

        NoDirectDebitAccountException exception = assertThrows(NoDirectDebitAccountException.class, () -> service.getDirectDebitAccounts("ldapUid"));
        assertEquals("NO_DIRECT_DEBIT_INTERNAL_ACCOUNTS", exception.getCode());
        assertEquals("No eligible direct debit account found", exception.getMessage());

        verify(mockAccountsClient, times(1)).directDebitEligibleAccounts(any(), any(QueryParams.class));
        verify(mockBalancesClient, times(0)).fetchBalances(any(), any());
        verify(mockMapper, times(0)).mapDirectDebitAccounts(any(), any());
    }

    @Test
    void shouldThrowGeneralException() throws GeneralException {

        when(mockAccountsClient.directDebitEligibleAccounts(any(), any(QueryParams.class))).thenThrow(new GeneralException("CUSTOMER_ACCESS_ENTITLEMENT_EXC", "Customer-access-entitlement service did not respond correctly"));

        GeneralException exception = assertThrows(GeneralException.class, () -> service.getDirectDebitAccounts("ldapUid"));
        assertEquals("CUSTOMER_ACCESS_ENTITLEMENT_EXC", exception.getCode());
        assertEquals("Customer-access-entitlement service did not respond correctly", exception.getMessage());

        verify(mockAccountsClient, times(1)).directDebitEligibleAccounts(any(), any(QueryParams.class));
        verify(mockBalancesClient, times(0)).fetchBalances(any(), any());
        verify(mockMapper, times(0)).mapDirectDebitAccounts(any(), any());
    }

    private InternalAccountsResponse createAccountsResponse() {
        InternalAccountsResponse accountsWrapper = new InternalAccountsResponse();
        ArrayList<Account> arrayList = new ArrayList<>();
        Account accountOne = new Account();
        accountOne.setPartenonContract("001510363000005188");
        arrayList.add(accountOne);
        Account accountTwo = new Account();
        accountTwo.setPartenonContract("001610363000005189");
        arrayList.add(accountTwo);
        accountsWrapper.setAccounts(arrayList);
        return accountsWrapper;
    }

    private InternalAccountsResponse createEmptyAccountsResponse() {
        InternalAccountsResponse accountsWrapper = new InternalAccountsResponse();
        accountsWrapper.setAccounts(new ArrayList<>());
        return accountsWrapper;
    }

}

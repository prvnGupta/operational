package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions;


import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.business.ExcBusIsc;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.validations.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Created by c0245070 on 08/12/2017.
 */
public class ExceptionsTest {
    @Test
    public void checkExcValidationBdpCustomer() {
        ExcValidationBdpCustomer excValidationBdpCustomer = new ExcValidationBdpCustomer();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_BDPCUSTOMER.getErrorMessage().equals(excValidationBdpCustomer.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_BDPCUSTOMER.getErrorCode().equals(excValidationBdpCustomer.getCode())
        );

        assertTrue(excValidationBdpCustomer.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_BDPCUSTOMER\",\"message\":\"Mandatory Input bdpCustomer field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationChannel() {
        ExcValidationChannel excValidationChannel = new ExcValidationChannel();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_CHANNEL.getErrorMessage().equals(excValidationChannel.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_CHANNEL.getErrorCode().equals(excValidationChannel.getCode())
        );
        assertTrue(excValidationChannel.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_CHANNEL\",\"message\":\"Input channel field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationCompany() {
        ExcValidationCompany excValidationCompany = new ExcValidationCompany();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_COMPANY.getErrorMessage().equals(excValidationCompany.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_COMPANY.getErrorCode().equals(excValidationCompany.getCode())
        );
        assertTrue(excValidationCompany.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_COMPANY\",\"message\":\"Mandatory Input company field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationDataRequestEmpty() {
        ExcValidationDataRequestEmpty excValidationDataRequestEmpty = new ExcValidationDataRequestEmpty();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_DATAREQUEST_EMPTY.getErrorMessage().equals(excValidationDataRequestEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_DATAREQUEST_EMPTY.getErrorCode().equals(excValidationDataRequestEmpty.getCode())
        );
        assertTrue(excValidationDataRequestEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_DATAREQUEST_EMPTY\",\"message\":\"Mandatory Input dataRequest field is empty\"}"));
    }

    @Test
    public void checkExcValidationPartenonContract() {
        ExcValidationPartenonContract excValidationPartenonContract = new ExcValidationPartenonContract();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_PARTENONCONTRACT.getErrorMessage().equals(excValidationPartenonContract.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_PARTENONCONTRACT.getErrorCode().equals(excValidationPartenonContract.getCode())
        );
        assertTrue(excValidationPartenonContract.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_PARTENONCONTRACT\",\"message\":\"Mandatory Input partenonContract field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationCesta() {
        ExcValidationCesta excValidationCesta = new ExcValidationCesta();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_CESTA.getErrorMessage().equals(excValidationCesta.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_CESTA.getErrorCode().equals(excValidationCesta.getCode())
        );
        assertTrue(excValidationCesta.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_CESTA\",\"message\":\"Mandatory Input cesta field format is not valid\"}"));
    }

    @Test
    public void checkExcValidationElementEmpty() {
        ExcValidationElementEmpty excValidationElementEmpty = new ExcValidationElementEmpty();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_ELEMENT_EMPTY.getErrorMessage().equals(excValidationElementEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_ELEMENT_EMPTY.getErrorCode().equals(excValidationElementEmpty.getCode())
        );
        assertTrue(excValidationElementEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_ELEMENT_EMPTY\",\"message\":\"Mandatory Input element field is empty\"}"));
    }

    @Test
    public void checkExcValidationElementListEmpty() {
        ExcValidationElementListEmpty excValidationElementListEmpty = new ExcValidationElementListEmpty();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_ELEMENTLIST_EMPTY.getErrorMessage().equals(excValidationElementListEmpty.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_ELEMENTLIST_EMPTY.getErrorCode().equals(excValidationElementListEmpty.getCode())
        );
        assertTrue(excValidationElementListEmpty.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_ELEMENTLIST_EMPTY\",\"message\":\"Mandatory Input elementList field is empty\"}"));
    }

    @Test
    public void checkExcValidationProductSubType() {
        ExcValidationProductSubType excValidationProductSubType = new ExcValidationProductSubType();
        assertTrue(
                ExceptionValidationEnum.EXC_VAL_PRODUCTSUBTYPE.getErrorMessage().equals(excValidationProductSubType.getMessage())
                        && ExceptionValidationEnum.EXC_VAL_PRODUCTSUBTYPE.getErrorCode().equals(excValidationProductSubType.getCode())
        );
        assertTrue(excValidationProductSubType.toString().equalsIgnoreCase("{\"code\":\"EXC_VAL_PRODUCTSUBTYPE\",\"message\":\"Input productSubType field format is not valid\"}"));
    }

    @Test
    public void checkExcBusIsc() {
        ExcBusIsc excBusIsc = new ExcBusIsc();
        assertTrue(excBusIsc.toString().equalsIgnoreCase("{\"code\":\"EXC_BUS_ISC\",\"message\":\"Error detected in ISC response\"}"));
    }
}

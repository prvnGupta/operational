package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.commons.exceptions.validations.ExcValidationLdapUidEmpty;
import org.junit.Test;

public class OperationalIocDataValidationTest {


    @Test
    public void testValidationsWithLDAPUID() throws GeneralException {
        OperationalIocDataValidation.validate("12445");
    }

    @Test(expected = ExcValidationLdapUidEmpty.class)
    public void testValidationsWithoutLDAPUID() throws GeneralException {
        OperationalIocDataValidation.validate("");
    }

}
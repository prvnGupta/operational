package com.santanderuk.corinthian.hub.operational.functional;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.config.JsonPathConfig;
import com.santanderuk.corinthian.hub.operational.OperationalApplication;
import org.apache.commons.io.IOUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.jayway.restassured.config.JsonConfig.jsonConfig;
import static com.jayway.restassured.config.RestAssuredConfig.newConfig;

@ContextConfiguration(initializers = FunctionalTest.RandomPortInitializer.class)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = OperationalApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
public abstract class FunctionalTest {

    protected String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0QmFja2VuZF9SUzI1NiJ9.eyJpc3MiOiJJbnRlcm5ldEJhY2tlbmQiLCJzdWIiOiI2eDFXQjc4RyIsImF1ZCI6WyJhbm1mIiwicGF5bWVudHMiLCJmcmF1ZCIsImJrcyIsImNhcmRzIiwiQ3VzdG9tZXItUHJvZmlsZS1Db3JlIl0sIm5iZiI6MTUzNTAxNjg3MiwiZXhwIjoxNTM1MDIwNDcyLCJpYXQiOjE1MzUwMTY4NzIsImp0aSI6IjA5NTk4MWQxLWY1NzEtNDQ1OC1hMDkwLTkzNmE2NGMzMzFkZCIsIm1pcyI6IltyOmdhdGV3YXldYTo2QjczNzAxREY5QzUyNDJCNjYwMjIxMkQ6RjE3MjI0OjAwMTU6ZWJhbmtpbmciLCJlbnQiOiJyZXRhaWwiLCJlbnYiOiJpbnRlcm5ldCJ9.ajyD-HNpRrdBdyS1kmbDSfyDeNgArr-P9EVnbq9p7WNXTEMVzO0wFe0tnh-hTft40B3Fz8DwCQ88ZqAXOWcQ4aFZxtTs6ir1fduvdaE5nubqPjzsJp56jH9u19mlD0uG2t3IZ5Tkp74TQnTm_i7DcIc9NU8npprLh-rKoIe8J2r9cWhHX219Nc5IPiD1Vfbcg4pBQA4oIusSxrbZSyKIrF5M_GHMfLDUVmJRHBAxA6A5k7rxttoD-MT50rJV14RwtqgzHK0J6YiQaEQW9QU4XN_ZfQtsEVzPXnPtUpytwjY2WIZHPjoAT0JcLLFiYmsyjHEjd3w8GvdZoH0yYiyyog";
    @LocalServerPort
    protected String serverPort;
    @Value("${brand.endpoint.port}")
    protected int coreBrandWireMockPort;
    @Value("${customers-information.url.port}")
    protected int customersInformationWireMockPort;
    @Value("${bks.port}")
    protected int bksPort;
    @Value("${accountbalances.port}")
    protected int accountBalancesPort;
    @Value("${customer-access-entitlement.port}")
    protected int customerAccessEntitlementPort;

    String testBrandURL = "/sanuk/internal/customer-profile/6x1WB78G";
    String testCustomerInformationUrl = "/sanuk/internal/customers/F000017224";
    String bksRetrieveAccountUrl = "/sanuk/internal/core/bks-connect/ioc-core/retrieve-mcc-from-ldap-user";
    String bksRetrieveMccInfoUrl = "/sanuk/internal/core/bks-connect/ioc-core/retrieve-mcc-info";
    String bksContractsInMCCUrl = "/sanuk/internal/core/bks-connect/ioc-core/contracts-in-mcc";
    String bksAccountBalanceUrl = "/sanuk/internal/core/bks-connect/isc-core/account-balance";
    String accountBalancesUrl = "/sanuk/internal/accounts-balances/v1/balances";
    String customerAccessEntitlementUrl = "/sanuk/internal/customer-access-entitlement/v5/entitled-accounts\\?uid=6x1WB78G&operation=santander.sanuk.retail.olb.payments.directdebits";

    private WireMockServer coreBrandWireMock;
    private WireMockServer customersWireMock;
    private WireMockServer bksIOCWireMock;
    private WireMockServer accountBalancesWiremock;
    private WireMockServer customerAccessEntitlementMock;

    protected static String readFileContents(String filename) {
        InputStream resource;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }

    @Before
    public void setUp() {

        RestAssured.config =
                newConfig().jsonConfig(jsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.BIG_DECIMAL));

        coreBrandWireMock = new WireMockServer(coreBrandWireMockPort);
        coreBrandWireMock.start();

        customersWireMock = new WireMockServer(customersInformationWireMockPort);
        customersWireMock.start();

        bksIOCWireMock = new WireMockServer(bksPort);
        bksIOCWireMock.start();

        accountBalancesWiremock = new WireMockServer(accountBalancesPort);
        accountBalancesWiremock.start();

        customerAccessEntitlementMock = new WireMockServer(customerAccessEntitlementPort);
        customerAccessEntitlementMock.start();
    }

    @After
    public void tearDown() {
        coreBrandWireMock.stop();
        customersWireMock.stop();
        bksIOCWireMock.stop();
        accountBalancesWiremock.stop();
        customerAccessEntitlementMock.stop();
    }

    protected void stubCoreCustomerProfileSuccessPI() {
        coreBrandWireMock.stubFor(get(urlPathEqualTo(testBrandURL)).withHeader("X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("core-customersegment-success-Select-response.json"))));
    }

    protected void stubCoreCustomersInformation() {
        customersWireMock.stubFor(get(urlPathEqualTo(testCustomerInformationUrl)).withHeader("X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("core-customers-information-response.json"))));
    }

    protected void stubCoreCustomersInformationApiDown() {
        customersWireMock.stubFor(get(urlPathEqualTo(testCustomerInformationUrl)).withHeader("X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withStatus(500)));
    }

    protected void stubCoreCustomerProfileSuccessPD() {
        coreBrandWireMock.stubFor(get(urlPathEqualTo(testBrandURL)).withHeader("X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("core-customersegment-success-PersonalBanking-response.json"))));
    }

    protected void stubCoreCustomerProfileSuccessPB() {
        coreBrandWireMock.stubFor(get(urlPathEqualTo(testBrandURL)).withHeader("X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("core-customersegment-success-PrivBanking-response.json"))));
    }

    protected void stubCoreCustomerProfileUnknownError() {
        coreBrandWireMock.stubFor(get(urlPathEqualTo(testBrandURL)).withHeader("X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("core-customersegment-error-response.json"))));
    }

    protected void stubCoreCustomerProfileUnauthorisedError() {
        coreBrandWireMock.stubFor(get(urlPathEqualTo(testBrandURL)).withHeader("X-IBM-Client-Id", containing("9608f35f-9564-49ea-be83-dbe31e9c77a2"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("core-customersegment-unauthorised-response.json"))));
    }

    protected void stubBKSReadOnly() {
        bksIOCWireMock.stubFor(post(urlPathEqualTo(bksRetrieveAccountUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect-read-only-response.json"))));

    }

    protected void stubBKSHasMccAccounts() {
        bksIOCWireMock.stubFor(post(urlPathEqualTo(bksRetrieveAccountUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect-has-mcc-response.json"))));

        bksIOCWireMock.stubFor(post(urlPathEqualTo(bksRetrieveMccInfoUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect-mcc-info-response.json"))));

        bksIOCWireMock.stubFor(post(urlPathEqualTo(bksContractsInMCCUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect-contracts-in-mcc-response.json"))));
    }

    protected void stubBKSHasMccButNoInternalAccounts() {
        bksIOCWireMock.stubFor(post(urlPathEqualTo(bksRetrieveAccountUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect-has-mcc-response-no-internal-account.json"))));

        bksIOCWireMock.stubFor(post(urlPathEqualTo(bksRetrieveMccInfoUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect-mcc-info-response.json"))));

        bksIOCWireMock.stubFor(post(urlPathEqualTo(bksContractsInMCCUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("bks-connect-contracts-in-mcc-response-no-internal-account.json"))));
    }

    protected void stubCustomerAccessEntitlementApi() {
        customerAccessEntitlementMock.stubFor(get(urlMatching(customerAccessEntitlementUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("direct-debit-accounts-response.json"))));
    }

    protected void stubCustomerAccessEntitlementApiNoEligibleAccount() {
        customerAccessEntitlementMock.stubFor(get(urlMatching(customerAccessEntitlementUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents("direct-debit-no-accounts-response.json"))));
    }

    protected void stubAccountBalancesService() {
        accountBalancesWiremock.stubFor(get(urlPathEqualTo(accountBalancesUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("account-balances-response-api.json"))));
    }

    protected void stubAccountBalancesServiceDown() {
        accountBalancesWiremock.stubFor(get(urlPathEqualTo(accountBalancesUrl))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)
                        .withBody(readFileContents("account-balances-response-api-down.json"))));
    }

    public static class RandomPortInitializer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {

            int coreBrandPort = SocketUtils.findAvailableTcpPort();
            int customersInfoPort = SocketUtils.findAvailableTcpPort();
            int bksIOCPort = SocketUtils.findAvailableTcpPort();
            int accountBalancesPort = SocketUtils.findAvailableTcpPort();
            int cAEPort = SocketUtils.findAvailableTcpPort();

            String coreBrandUrl = String.format("http://localhost:%d/sanuk/internal/customer-profile/{ldapuid}", coreBrandPort);
            String customerInformationUrl = String.format("http://localhost:%d/sanuk/internal/customers/{customerId}", customersInfoPort);
            String bksIOCRetrieveMCCFromLdapUser = String.format("http://localhost:%d/sanuk/internal/core/bks-connect/ioc-core/retrieve-mcc-from-ldap-user", bksIOCPort);
            String bksIOCRetrieveMCCInfo = String.format("http://localhost:%d/sanuk/internal/core/bks-connect/ioc-core/retrieve-mcc-info", bksIOCPort);
            String bksIOCContractsInMCC = String.format("http://localhost:%d/sanuk/internal/core/bks-connect/ioc-core/contracts-in-mcc", bksIOCPort);
            String bksAccountBalance = String.format("http://localhost:%d/sanuk/internal/core/bks-connect/isc-core/account-balance", bksIOCPort);
            String accountBalancesUrl = String.format("http://localhost:%d/sanuk/internal/accounts-balances/v1/balances", accountBalancesPort);
            String cAEUrl = String.format("http://localhost:%d/sanuk/internal/customer-access-entitlement/v5/entitled-accounts", cAEPort);


            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "brand.endpoint=" + coreBrandUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "brand.endpoint.port=" + coreBrandPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "customers-information.url=" + customerInformationUrl);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "customers-information.url.port=" + customersInfoPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "operational.endpoints.ioc.retrievemcc=" + bksIOCRetrieveMCCFromLdapUser);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "operational.endpoints.ioc.retrievemccinfo=" + bksIOCRetrieveMCCInfo);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "operational.endpoints.ioc.contractsinmcc=" + bksIOCContractsInMCC);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "operational.endpoints.isc.accountbalance=" + bksAccountBalance);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "bks.port=" + bksIOCPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "accountbalances.port=" + accountBalancesPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "operational.endpoints.accountBalances=" + accountBalancesUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "customer-access-entitlement.port=" + cAEPort);
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext, "customer-access-entitlement.url=" + cAEUrl);
        }

    }

}

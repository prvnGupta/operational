package com.santanderuk.corinthian.hub.operational.utils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FormatFirstNameTest {

    FormatFirstName formatFirstName;

    @BeforeEach
    void setUp() {
        formatFirstName = new FormatFirstName();
    }

    @Test
    void formatFirstName() {
        assertEquals("Goku", formatFirstName.formatFirstName("goku"));
        assertEquals("Goku", formatFirstName.formatFirstName("GOKU"));
        assertEquals("Goku", formatFirstName.formatFirstName("GokU"));
        assertEquals("Goku-San", formatFirstName.formatFirstName("GOKU-SAN"));
        assertEquals("Kakaroto-Goku-San", formatFirstName.formatFirstName("kakaroto-goku-san"));
        assertEquals("", formatFirstName.formatFirstName(""));
        assertEquals("", formatFirstName.formatFirstName(null));
    }
}

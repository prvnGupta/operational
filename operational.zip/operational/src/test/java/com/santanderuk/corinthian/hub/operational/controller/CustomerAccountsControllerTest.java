package com.santanderuk.corinthian.hub.operational.controller;

import com.santanderuk.corinthian.hub.commons.classes.PartenonAccountNumber;
import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.exceptions.business.ExcBusViewOnly;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.CustomerAccountsControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.DataResponse;
import com.santanderuk.corinthian.hub.operational.services.customeraccounts.CustomerAccountsServiceInterface;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
public class CustomerAccountsControllerTest {

    @MockBean
    CustomerAccountsServiceInterface customerAccountsService;

    CustomerAccountsController controller;

    String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";

    @Before
    public void setUp() {
        controller = new CustomerAccountsController(customerAccountsService);
    }

    @Test
    public void testHappyPath() throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {
        DataResponse dataResponse = new DataResponse();
        dataResponse.setAccounts(new ArrayList<>());
        dataResponse.setMccContract(new PartenonAccountNumber("", "", "", ""));
        when(customerAccountsService.getCustomerAccounts(anyString(), anyString())).thenReturn(dataResponse);
        ResponseEntity<CustomerAccountsControllerResponse> response = controller.operationIoc(jwtToken, "pgwe51ZD");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("ok", response.getBody().getInfo().getStatus());

    }

    @Test
    public void testGeneralExceptionThrown() throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {

        when(customerAccountsService.getCustomerAccounts(anyString(), anyString())).thenThrow(GeneralException.class);

        ResponseEntity<CustomerAccountsControllerResponse> response = controller.operationIoc(jwtToken, "pgwe51ZD");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("should be a Ko", "ko", response.getBody().getInfo().getStatus());
        assertNotNull("Should not be null ", response.getBody().getDataResponse());
        assertNotNull("Should not be null ", response.getBody().getDataResponse().getAccounts());
        assertNotNull("Should not be null ", response.getBody().getDataResponse().getMccContract());

    }

    @Test
    public void nullDataResponseIsHandled() throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {

        DataResponse data = new DataResponse();
        data.setMccContract(new PartenonAccountNumber("1", "2", "3", "4"));
        when(customerAccountsService.getCustomerAccounts(anyString(), anyString())).thenReturn(data);

        ResponseEntity<CustomerAccountsControllerResponse> response = controller.operationIoc(jwtToken, "pgwe51ZD");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("should be a Ko", "ko", response.getBody().getInfo().getStatus());
        assertEquals("should be 'No accounts for customer'", "No accounts for customer", response.getBody().getInfo().getErrorMessage());
        assertEquals("should be 'EXC_BUS_NO_INTERNAL_ACCOUNTS'", "EXC_BUS_NO_INTERNAL_ACCOUNTS", response.getBody().getInfo().getCode());
        assertNotNull("should not be null", response.getBody().getInfo().getTimestamp());
        assertNotNull("Should not be null ", response.getBody().getDataResponse());
        assertNotNull("Should not be null ", response.getBody().getDataResponse().getAccounts());
        assertNotNull("Should not be null ", response.getBody().getDataResponse().getMccContract());

    }

    @Test
    public void testViewOnlyThrown() throws GeneralException, ExcBusViewOnly, ConnectionException, ValidationsException {

        when(customerAccountsService.getCustomerAccounts(anyString(), anyString())).thenThrow(ExcBusViewOnly.class);

        ResponseEntity<CustomerAccountsControllerResponse> response = controller.operationIoc(jwtToken, "pgwe51ZD");

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("should be a Ko", "ko", response.getBody().getInfo().getStatus());
        assertEquals("view only exception expected", ExcBusViewOnly.EXC_BUS_CODE, response.getBody().getInfo().getCode());
        assertNotNull("Should not be null ", response.getBody().getDataResponse());
        assertNotNull("Should not be null ", response.getBody().getDataResponse().getAccounts());
        assertNotNull("Should not be null ", response.getBody().getDataResponse().getMccContract());

    }


}

package com.santanderuk.corinthian.hub.operational.testdata;

import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalance;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AdditionalInfo;


import java.util.ArrayList;
import java.util.List;

public class AccountBalancesResponseTestData {

    public static AccountBalancesResponse singleAccountWithOverdraft() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AccountBalance> accountBalances = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setCurrencyCode("GBP");
        accountBalance.setFinancialBalance("200.00 C");
        accountBalance.setTemporaryOverdraft("10.00 C");
        accountBalance.setAuthorizedOverdraft(null);
        accountBalance.setBalanceIncPending("300.00 D");
        accountBalance.setOverdraftRemaining("410.00 C");
        accountBalance.setPartenonContractId("012345678901234567");
        accountBalances.add(accountBalance);
        accountBalancesResponse.setAccountBalances(accountBalances);
        return accountBalancesResponse;
    }

    public static AccountBalancesResponse singleAccountWithNoOverdraft() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AccountBalance> accountBalances = new ArrayList<>();
        AccountBalance accountBalance = new AccountBalance();
        accountBalance.setCurrencyCode("GBP");
        accountBalance.setFinancialBalance("200.00 C");
        accountBalance.setTemporaryOverdraft("0.00 C");
        accountBalance.setAuthorizedOverdraft(null);
        accountBalance.setBalanceIncPending("300.00 D");
        accountBalance.setOverdraftRemaining("0.00 C");
        accountBalance.setPartenonContractId("012345678901234567");
        accountBalances.add(accountBalance);
        accountBalancesResponse.setAccountBalances(accountBalances);
        return accountBalancesResponse;
    }

    public static AccountBalancesResponse multipleAccountsAllWithBalances() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AccountBalance> accountBalances = new ArrayList<>();
        AccountBalance accountBalanceOne = new AccountBalance();
        accountBalanceOne.setCurrencyCode("GBP");
        accountBalanceOne.setFinancialBalance("200.00 C");
        accountBalanceOne.setTemporaryOverdraft("0.00 C");
        accountBalanceOne.setAuthorizedOverdraft("0.00 C");
        accountBalanceOne.setBalanceIncPending("300.00 D");
        accountBalanceOne.setOverdraftRemaining("0.00 C");
        accountBalanceOne.setPartenonContractId("012345678901234567");
        AccountBalance accountBalanceTwo = new AccountBalance();
        accountBalanceTwo.setCurrencyCode("GBP");
        accountBalanceTwo.setFinancialBalance("300.00 C");
        accountBalanceTwo.setTemporaryOverdraft("10.00 C");
        accountBalanceTwo.setAuthorizedOverdraft("300.00 C");
        accountBalanceTwo.setBalanceIncPending("1000.00 C");
        accountBalanceTwo.setOverdraftRemaining("300.00 C");
        accountBalanceTwo.setPartenonContractId("123456789012345678");
        accountBalances.add(accountBalanceOne);
        accountBalances.add(accountBalanceTwo);
        accountBalancesResponse.setAccountBalances(accountBalances);
        return accountBalancesResponse;
    }

    public static AccountBalancesResponse multipleAccountsSomeWithBalances() {
        AccountBalancesResponse accountBalancesResponse = new AccountBalancesResponse();
        List<AccountBalance> accountBalances = new ArrayList<>();
        AccountBalance accountBalanceOne = new AccountBalance();
        accountBalanceOne.setPartenonContractId("012345678901234567");
        accountBalanceOne.setCurrencyCode("GBP");
        accountBalanceOne.setFinancialBalance("200.00 C");
        accountBalanceOne.setTemporaryOverdraft("0.00 C");
        accountBalanceOne.setAuthorizedOverdraft("0.00 C");
        accountBalanceOne.setBalanceIncPending("300.00 D");
        accountBalanceOne.setOverdraftRemaining("0.00 C");
        accountBalances.add(accountBalanceOne);
        accountBalancesResponse.setAccountBalances(accountBalances);
        List<AdditionalInfo> additionalInfos = new ArrayList<>();
        AdditionalInfo additionalInfo = new AdditionalInfo();
        additionalInfo.setPartenonContractId("123456789012345678");
        additionalInfo.setErrorMessage("NO BALANCES FOR ACCOUNT");
        additionalInfos.add(additionalInfo);
        accountBalancesResponse.setAdditionalInfo(additionalInfos);
        return accountBalancesResponse;
    }
}

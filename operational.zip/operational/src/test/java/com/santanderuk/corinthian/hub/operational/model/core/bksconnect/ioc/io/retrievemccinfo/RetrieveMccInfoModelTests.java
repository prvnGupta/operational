package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.IocCoreApiCommonsBaseTest;
import org.junit.Assert;
import org.junit.Test;

public class RetrieveMccInfoModelTests extends IocCoreApiCommonsBaseTest {


    @Test()
    public void retrieveMccInfoControllerRequestToStringTest() {
        RetrieveMccInfoControllerRequest retrieveMccInfoControllerRequest = generateDefaultRequestRetrieveMccInfo();
        Assert.assertTrue(retrieveMccInfoControllerRequest.toString().equalsIgnoreCase("{\"dataRequest\":{\"profile\":{\"company\":\"0015\",\"channel\":\"OFI\"},\"company\":\"0015\",\"conexionChannel\":\"INT\",\"mccPartenonContract\":{\"centre\":{\"company\":\"0015\",\"centreCode\":\"7740\"},\"productTypeCode\":\"520\",\"contractNumber\":\"7589273\"}}}"));
    }

    @Test()
    public void retrieveMccControllerResponseToStringTest() {
        RetrieveMccInfoControllerResponse retrieveMccInfoControllerResponse = generateDefaultResponseRetrieveMccInfo();
        Assert.assertTrue(retrieveMccInfoControllerResponse.getDataResponse().toString().equalsIgnoreCase("{\"kcError\":{\"codError\":\"CodError\",\"descError\":\"DescError\",\"next\":\"next\",\"nextTRX\":\"nextTrx\"},\"bdpCustomer\":{\"bdpCustomertype\":\"F\",\"bdpCustomerCode\":12345678},\"ldapUid\":\"78p0KPs6\",\"mccType\":\"0005\",\"mccOrigin\":\"001\"}"));
    }
}

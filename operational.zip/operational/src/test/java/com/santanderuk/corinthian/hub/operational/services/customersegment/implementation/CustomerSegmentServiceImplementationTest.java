package com.santanderuk.corinthian.hub.operational.services.customersegment.implementation;


import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.config.OperationalConfig;
import com.santanderuk.corinthian.hub.operational.model.core.customerprofile.CustomerProfile;
import com.santanderuk.corinthian.hub.operational.model.core.customerprofile.CustomerProfileResponse;
import com.santanderuk.corinthian.hub.operational.model.customersegment.DataResponse;
import com.santanderuk.corinthian.hub.operational.utils.ExtractCustomerIdFromJwt;
import com.santanderuk.corinthian.hub.operational.utils.FormatFirstName;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.CustomerInformationClient;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerBasicDataEnquire;
import com.santanderuk.corinthian.services.commons.clients.customerInformation.io.response.CustomerInformationResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;


@RunWith(SpringRunner.class)
public class CustomerSegmentServiceImplementationTest {

    @SpyBean
    private CustomerSegmentServiceImplementation customerSegmentServiceImplementation;

    @MockBean
    private RestTemplate restTemplate;
    @MockBean
    private OperationalConfig config;
    @MockBean
    private CustomerInformationClient customerInformationClientMock;
    @MockBean
    private ExtractCustomerIdFromJwt extractCustomerIdFromJwtMock;
    @MockBean
    private FormatFirstName formatFirstNameMock;

    private ResponseEntity<CustomerProfileResponse> response;
    private CustomerProfileResponse customerProfileResponse;
    private CustomerProfile customerProfile;

    String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    @Before
    public void setUp() throws Exception {
        Mockito.when(config.getBrandEndpoint()).thenReturn("https://dummy.url/sanuk/internal/customer-profile/{ldapuid}");
        Mockito.when(config.getCustomerInformationUrl()).thenReturn("https://dummy.url/sanuk/internal/customers/{customerId}");
        Mockito.when(extractCustomerIdFromJwtMock.getCustomerIdZeroLeftPadded(anyString())).thenReturn("F000000554");
        Mockito.when(customerInformationClientMock.getCustomerInformation(anyString(), anyString())).thenReturn(createCustomerInformationResponse());
        Mockito.when(formatFirstNameMock.formatFirstName(anyString())).thenReturn("James").thenReturn("Harris");

    }

    private CustomerInformationResponse createCustomerInformationResponse() {
        CustomerBasicDataEnquire customerBasicDataEnquire = new CustomerBasicDataEnquire();
        customerBasicDataEnquire.setFirstName("James");
        customerBasicDataEnquire.setLastName("Harris");
        CustomerInformationResponse response = new CustomerInformationResponse();
        response.setCustomerBasicDataEnquire(customerBasicDataEnquire);

        return response;
    }

    @Test
    public void shouldCallCoreApi() throws GeneralException, ConnectionException {
        ValidCustomerProfileResponsePD();
        Mockito.when(restTemplate.exchange(eq("https://dummy.url/sanuk/internal/customer-profile/ExampleUid"),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<CustomerProfileResponse>>any())).thenReturn(response);

        customerSegmentServiceImplementation.getCustomerSegment("ExampleUid", jwtToken);

        Mockito.verify(customerSegmentServiceImplementation, Mockito.times(1)).getCustomerProfileCoreService("ExampleUid");
        Mockito.verify(restTemplate, Mockito.times(1)).
                exchange(anyString(),
                        ArgumentMatchers.any(HttpMethod.class),
                        ArgumentMatchers.any(HttpEntity.class),
                        ArgumentMatchers.<Class<CustomerProfileResponse>>any());
    }

    @Test
    public void customerProfileReturnedWhenCoreApiExecutedSuccessfully() throws GeneralException {
        ValidCustomerProfileResponsePD();
        Mockito.when(restTemplate.exchange(eq("https://dummy.url/sanuk/internal/customer-profile/ExampleUid"),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<CustomerProfileResponse>>any())).thenReturn(response);

        CustomerProfileResponse customerProfileResponse = customerSegmentServiceImplementation.getCustomerProfileCoreService("ExampleUid");

        Assert.assertEquals(response.getBody(), customerProfileResponse);

    }

    @Test
    public void customerProfileSegmentReturnedWhenCoreApiExecutedSuccessfullyAndPD() throws GeneralException, ConnectionException {
        ValidCustomerProfileResponsePD();
        Mockito.when(restTemplate.exchange(eq("https://dummy.url/sanuk/internal/customer-profile/ExampleUid"),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<CustomerProfileResponse>>any())).thenReturn(response);

        DataResponse dataResponse = customerSegmentServiceImplementation.getCustomerSegment("ExampleUid", jwtToken);

        Assert.assertEquals("James", dataResponse.getFirstName());
        Assert.assertEquals("Harris", dataResponse.getLastName());
        Assert.assertEquals(response.getBody().getCustomerProfile().getSegmentCode().trim(), dataResponse.getSegmentCode());
        Assert.assertEquals(response.getBody().getCustomerProfile().getSegmentName().trim(), dataResponse.getSegmentName());
    }

    @Test
    public void customerProfileSegmentReturnedWhenCoreApiExecutedSuccessfullyAndPI() throws GeneralException, ConnectionException {
        ValidCustomerProfileResponsePI();
        Mockito.when(restTemplate.exchange(eq("https://dummy.url/sanuk/internal/customer-profile/ExampleUid"),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<CustomerProfileResponse>>any())).thenReturn(response);

        DataResponse dataResponse = customerSegmentServiceImplementation.getCustomerSegment("ExampleUid", jwtToken);

        Assert.assertEquals(response.getBody().getCustomerProfile().getSegmentCode().trim(), dataResponse.getSegmentCode());
        Assert.assertEquals(response.getBody().getCustomerProfile().getSegmentName().trim(), dataResponse.getSegmentName());

    }

    @Test
    public void customerProfileSegmentReturnedWhenCoreApiExecutedSuccessfullyAndPB() throws GeneralException, ConnectionException {
        ValidCustomerProfileResponsePB();
        Mockito.when(restTemplate.exchange(eq("https://dummy.url/sanuk/internal/customer-profile/ExampleUid"),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<CustomerProfileResponse>>any())).thenReturn(response);

        DataResponse dataResponse = customerSegmentServiceImplementation.getCustomerSegment("ExampleUid", jwtToken);

        Assert.assertEquals(response.getBody().getCustomerProfile().getSegmentCode().trim(), dataResponse.getSegmentCode());
        Assert.assertEquals(response.getBody().getCustomerProfile().getSegmentName().trim(), dataResponse.getSegmentName());

    }

    @Test(expected = GeneralException.class)
    public void shouldThrow_GE_whenFromCustomerProfileCoreApiResponseStatusNotOk() throws GeneralException, ConnectionException {

        invalidCustomerProfileResponse();
        Mockito.when(restTemplate.exchange(anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<CustomerProfileResponse>>any())).thenReturn(response);

        customerSegmentServiceImplementation.getCustomerSegment("ExampleUid", jwtToken);
    }

    @Test(expected = GeneralException.class)
    public void shouldThrow_GE_whenExceptionWhileCallingCoreAPI() throws GeneralException, ConnectionException {

        Mockito.when(restTemplate.exchange(anyString(),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<CustomerProfileResponse>>any())).thenThrow(RestClientException.class);

        customerSegmentServiceImplementation.getCustomerSegment("pgwe51ZD", jwtToken);


    }

    private void ValidCustomerProfileResponsePD() {
        response = new ResponseEntity<>(generateValidCustomerProfileResponse("PD", "PERSONAL                     "), HttpStatus.OK);
    }

    private void ValidCustomerProfileResponsePI() {
        response = new ResponseEntity<>(generateValidCustomerProfileResponse("PI", "SELECT                      "), HttpStatus.OK);
    }

    private void ValidCustomerProfileResponsePB() {
        response = new ResponseEntity<>(generateValidCustomerProfileResponse("PB", "PERSONAL BANKING            "), HttpStatus.OK);
    }

    private CustomerProfileResponse generateValidCustomerProfileResponse(String code, String desc) {
        customerProfileResponse = new CustomerProfileResponse();
        customerProfile = new CustomerProfile();
        customerProfile.setBrand("0006");
        customerProfile.setCustomerNumber("F1234");
        customerProfile.setMcc1("0001");
        customerProfile.setMcc2("0001");
        customerProfile.setMccCode("0001");
        customerProfile.setMccContract("0001");
        customerProfile.setSegmentCode(code);
        customerProfile.setSegmentName(desc);

        customerProfileResponse.setCustomerProfile(customerProfile);
        customerProfileResponse.setCode("FCC.PI");
        customerProfileResponse.setMessage("Success");
        return customerProfileResponse;
    }

    private void invalidCustomerProfileResponse() {
        response = new ResponseEntity<>(new CustomerProfileResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private void noDataCustomerProfileResponse() {
        response = new ResponseEntity<>(generateNoDataCustomerProfileResponse(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private CustomerProfileResponse generateNoDataCustomerProfileResponse() {
        CustomerProfileResponse customerProfileResponse = new CustomerProfileResponse();
        customerProfileResponse.setMessage("error");
        customerProfileResponse.setCode("ErrorCode");
        return customerProfileResponse;
    }
}

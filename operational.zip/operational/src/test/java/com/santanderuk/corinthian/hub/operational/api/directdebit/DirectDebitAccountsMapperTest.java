package com.santanderuk.corinthian.hub.operational.api.directdebit;

import com.santanderuk.corinthian.hub.operational.api.directdebit.io.DirectDebitAccounts;
import com.santanderuk.corinthian.hub.operational.utils.FixtureReader;
import com.santanderuk.corinthian.services.commons.clients.accountbalance.io.AccountBalancesResponse;
import com.santanderuk.corinthian.services.commons.clients.directdebit.io.InternalAccountsResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DirectDebitAccountsMapperTest {

    private DirectDebitAccountsMapper mapper;

    @BeforeEach
    void setUp() {
        mapper = new DirectDebitAccountsMapper();
    }

    @Test
    void shouldReturnAccounts() throws IOException {

        AccountBalancesResponse balancesResponse = createBalancesResponse();
        InternalAccountsResponse accountsList = createAccountsList();

        DirectDebitAccounts accounts = mapper.mapDirectDebitAccounts(accountsList, balancesResponse);

        assertEquals("EVERYDAY CURRENT ACCOUNT", accounts.getAccounts().get(0).getAlias());
        assertEquals("090126", accounts.getAccounts().get(0).getSortCode());
        assertEquals("55177871", accounts.getAccounts().get(0).getAccountNumber());
        assertEquals("GBP", accounts.getAccounts().get(0).getCurrency());
        assertEquals(new BigDecimal("490.00"), accounts.getAccounts().get(0).getBalance());
        assertEquals(new BigDecimal("190.00"), accounts.getAccounts().get(0).getBalanceIncPending());

        assertEquals("ZERO CURRENT ACCOUNT", accounts.getAccounts().get(1).getAlias());
        assertEquals("090126", accounts.getAccounts().get(1).getSortCode());
        assertEquals("50357476", accounts.getAccounts().get(1).getAccountNumber());
        assertEquals("GBP", accounts.getAccounts().get(1).getCurrency());
        assertEquals(new BigDecimal("4550.31"), accounts.getAccounts().get(1).getBalance());
        assertEquals(new BigDecimal("-4250.31"), accounts.getAccounts().get(1).getBalanceIncPending());
    }

    private InternalAccountsResponse createAccountsList() throws IOException {
        return FixtureReader.get("direct-debit-accounts-response.json", InternalAccountsResponse.class);
    }

    private AccountBalancesResponse createBalancesResponse() throws IOException {
        return FixtureReader.get("account-balances-response-api.json", AccountBalancesResponse.class);
    }

}

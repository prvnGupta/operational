package com.santanderuk.corinthian.hub.operational.services.customeraccounts.implementation;

import com.santanderuk.corinthian.hub.operational.model.customeraccounts.Account;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.DataResponse;
import com.santanderuk.corinthian.hub.operational.model.customeraccounts.OperationalIocData;
import com.santanderuk.corinthian.hub.operational.testdata.AccountBalancesResponseTestData;
import com.santanderuk.corinthian.hub.operational.testdata.ContractsInMccControllerResponseTestData;
import com.santanderuk.corinthian.hub.operational.testdata.RetrieveMccControllerResponseTestData;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

public class OperationIocDataConverterTest {

    @Test
    public void testWeConvertCorrectlyWhenOverdraftExists() {

        OperationalIocData operationalIocData = new OperationalIocData();
        operationalIocData.setRetrieveMccControllerResponse(RetrieveMccControllerResponseTestData.get());
        operationalIocData.setContractsInMccControllerResponse(ContractsInMccControllerResponseTestData.singleAccount());
        operationalIocData.setAccountBalancesResponse(AccountBalancesResponseTestData.singleAccountWithOverdraft());

        OperationIocDataConverter converter = new OperationIocDataConverter();

        DataResponse response = converter.iocToCorinthian(operationalIocData);

        Account account = response.getAccounts().get(0);

        assertAll(() -> {
            assertEquals("0015", response.getMccContract().getCompany());
            assertEquals("1234", response.getMccContract().getCentre());
            assertEquals("520", response.getMccContract().getProduct());
            assertEquals("1234567", response.getMccContract().getContract());
            assertEquals("667979879", account.getLocalContractAccountNumber());
            assertEquals("123455", account.getLocalContractSortCode());
            assertEquals(new BigDecimal("200.00"), account.getBalance());
            assertEquals("GBP", account.getCurrency());
            assertEquals("0123", account.getPartenonAccountNumber().getCompany());
            assertEquals("4567", account.getPartenonAccountNumber().getCentre());
            assertEquals("890", account.getPartenonAccountNumber().getProduct());
            assertEquals(new BigDecimal("-300.00"), account.getBalanceIncPending());
            assertEquals(new BigDecimal("410.00"), account.getOverdraftRemaining());
            assertTrue(account.isOverdraftAuthorisedFlag());
        });
    }

    @Test
    public void testWeConvertCorrectlyWhenNoOverdraft() {

        OperationalIocData operationalIocData = new OperationalIocData();
        operationalIocData.setRetrieveMccControllerResponse(RetrieveMccControllerResponseTestData.get());
        operationalIocData.setContractsInMccControllerResponse(ContractsInMccControllerResponseTestData.singleAccount());
        operationalIocData.setAccountBalancesResponse(AccountBalancesResponseTestData.singleAccountWithNoOverdraft());

        OperationIocDataConverter converter = new OperationIocDataConverter();

        DataResponse response = converter.iocToCorinthian(operationalIocData);

        Account account = response.getAccounts().get(0);

        assertAll(() -> {
            assertEquals("0015", response.getMccContract().getCompany());
            assertEquals("1234", response.getMccContract().getCentre());
            assertEquals("520", response.getMccContract().getProduct());
            assertEquals("1234567", response.getMccContract().getContract());
            assertEquals("667979879", account.getLocalContractAccountNumber());
            assertEquals("123455", account.getLocalContractSortCode());
            assertEquals(new BigDecimal("200.00"), account.getBalance());
            assertEquals("GBP", account.getCurrency());
            assertEquals("0123", account.getPartenonAccountNumber().getCompany());
            assertEquals("4567", account.getPartenonAccountNumber().getCentre());
            assertEquals("890", account.getPartenonAccountNumber().getProduct());
            assertEquals(new BigDecimal("-300.00"), account.getBalanceIncPending());
            assertEquals(new BigDecimal("0.00"), account.getOverdraftRemaining());
            assertFalse(account.isOverdraftAuthorisedFlag());
        });
    }

    @Test
    public void testWeConvertCorrectlyWhenMultipleAccounts() {

        OperationalIocData operationalIocData = new OperationalIocData();
        operationalIocData.setRetrieveMccControllerResponse(RetrieveMccControllerResponseTestData.get());
        operationalIocData.setContractsInMccControllerResponse(ContractsInMccControllerResponseTestData.multipleAccounts());
        operationalIocData.setAccountBalancesResponse(AccountBalancesResponseTestData.multipleAccountsAllWithBalances());

        OperationIocDataConverter converter = new OperationIocDataConverter();

        DataResponse response = converter.iocToCorinthian(operationalIocData);

        Account firstAccount = response.getAccounts().get(0);
        Account secondAccount = response.getAccounts().get(1);

        assertAll(() -> {
            assertEquals("0015", response.getMccContract().getCompany());
            assertEquals("1234", response.getMccContract().getCentre());
            assertEquals("520", response.getMccContract().getProduct());
            assertEquals("1234567", response.getMccContract().getContract());
            assertEquals("667979879", firstAccount.getLocalContractAccountNumber());
            assertEquals("123455", firstAccount.getLocalContractSortCode());
            assertEquals(new BigDecimal("200.00"), firstAccount.getBalance());
            assertEquals("GBP", firstAccount.getCurrency());
            assertEquals("0123", firstAccount.getPartenonAccountNumber().getCompany());
            assertEquals("4567", firstAccount.getPartenonAccountNumber().getCentre());
            assertEquals("890", firstAccount.getPartenonAccountNumber().getProduct());
            assertEquals(new BigDecimal("-300.00"), firstAccount.getBalanceIncPending());
            assertEquals(new BigDecimal("0.00"), firstAccount.getOverdraftRemaining());
            assertFalse(firstAccount.isOverdraftAuthorisedFlag());

            assertEquals("0015", response.getMccContract().getCompany());
            assertEquals("1234", response.getMccContract().getCentre());
            assertEquals("520", response.getMccContract().getProduct());
            assertEquals("1234567", response.getMccContract().getContract());
            assertEquals("667979879", secondAccount.getLocalContractAccountNumber());
            assertEquals("123455", secondAccount.getLocalContractSortCode());
            assertEquals(new BigDecimal("300.00"), secondAccount.getBalance());
            assertEquals("GBP", secondAccount.getCurrency());
            assertEquals("1234", secondAccount.getPartenonAccountNumber().getCompany());
            assertEquals("5678", secondAccount.getPartenonAccountNumber().getCentre());
            assertEquals("901", secondAccount.getPartenonAccountNumber().getProduct());
            assertEquals(new BigDecimal("1000.00"), secondAccount.getBalanceIncPending());
            assertEquals(new BigDecimal("300.00"), secondAccount.getOverdraftRemaining());
            assertTrue(secondAccount.isOverdraftAuthorisedFlag());
        });
    }

    @Test
    public void testWeFilterAccountsWhichWeDontHaveBalanceFor() {

        OperationalIocData operationalIocData = new OperationalIocData();
        operationalIocData.setRetrieveMccControllerResponse(RetrieveMccControllerResponseTestData.get());
        operationalIocData.setContractsInMccControllerResponse(ContractsInMccControllerResponseTestData.multipleAccounts());
        operationalIocData.setAccountBalancesResponse(AccountBalancesResponseTestData.multipleAccountsSomeWithBalances());

        OperationIocDataConverter converter = new OperationIocDataConverter();

        DataResponse response = converter.iocToCorinthian(operationalIocData);

        Account firstAccount = response.getAccounts().get(0);

        assertAll(() -> {

            assertEquals(response.getAccounts().size(), 1);

            assertEquals("667979879", firstAccount.getLocalContractAccountNumber());
            assertEquals("123455", firstAccount.getLocalContractSortCode());
            assertEquals(new BigDecimal("200.00"), firstAccount.getBalance());
            assertEquals("GBP", firstAccount.getCurrency());
            assertEquals("0123", firstAccount.getPartenonAccountNumber().getCompany());
            assertEquals("4567", firstAccount.getPartenonAccountNumber().getCentre());
            assertEquals("890", firstAccount.getPartenonAccountNumber().getProduct());
            assertEquals("1234567", firstAccount.getPartenonAccountNumber().getContract());
            assertEquals(new BigDecimal("-300.00"), firstAccount.getBalanceIncPending());
            assertEquals(new BigDecimal("0.00"), firstAccount.getOverdraftRemaining());
            assertFalse(firstAccount.isOverdraftAuthorisedFlag());
        });

    }

}

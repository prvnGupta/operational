package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc;


import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.validations.ExceptionValidationEnum;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.*;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by C0229411 on 15/12/2017.
 */
@RunWith(SpringRunner.class)

public abstract class IscCoreApiCommonsBaseTest {

    public static Element generateDefaultElement() {
        Element element = new Element();
        element.setCesta(generateDefaultCesta());
        element.setPartenonContract(generateDefaultPartenonContract());
        element.setProductSubtype(generateDefaulProductSubType());

        return element;
    }

    private static ProductSubtype generateDefaulProductSubType() {
        ProductSubtype productSubtype = new ProductSubtype();
        ProductType productType = new ProductType();
        productType.setCompany("0015");
        productType.setProductTypeCode("103");
        productSubtype.setProductSubtypeCode("700");
        productSubtype.setProductType(productType);
        return productSubtype;
    }

    private static Cesta generateDefaultCesta() {
        Cesta cesta = new Cesta();
        cesta.setCestaCompany("0015");
        cesta.setCestaCode("BIAC");
        return cesta;
    }

    public static OutElement generateDefaultOutElement() {
        OutElement outElement = new OutElement();

        outElement.setBalance1(generateDefaultBalance1());
        outElement.setBalance2(generateDefaultBalance2());
        outElement.setCesta(generateDefaultCesta());
        outElement.setContractStatus("A");
        outElement.setLimit(generateDefaultLimit());
        outElement.setOutReturn("return");
        outElement.setPartenonContract(generateDefaultPartenonContract());
        outElement.setProductSubtype(generateDefaulProductSubType());

        return outElement;
    }

    private static Limit generateDefaultLimit() {
        Limit limit = new Limit();
        limit.setAmount(new BigDecimal(0));
        limit.setCurrency("GBP");
        return limit;
    }

    private static Balance1 generateDefaultBalance1() {
        Balance1 balance1 = new Balance1();

        balance1.setAmount(new BigDecimal(0));
        balance1.setCurrency("GBP");
        return balance1;
    }

    private static Balance2 generateDefaultBalance2() {
        Balance2 balance2 = new Balance2();

        balance2.setAmount(new BigDecimal(0));
        balance2.setCurrency("GBP");
        return balance2;
    }

    public static PartenonContract generateDefaultPartenonContract() {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany("0015");
        centre.setCentreCode("0075");
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode("300");
        partenonContract.setContractNumber("1234567");
        return partenonContract;
    }

    public static ProductSubtype customProductSubtype(String company, String stringProductType, String stringProductSubtype) {
        ProductSubtype productSubtype = new ProductSubtype();
        ProductType productType = new ProductType();
        productType.setCompany(company);
        productType.setProductTypeCode(stringProductType);
        productSubtype.setProductSubtypeCode(stringProductSubtype);
        productSubtype.setProductType(productType);
        return productSubtype;
    }

    public static Cesta customCesta(String cestaCompany, String cestaCode) {
        Cesta cesta = new Cesta();
        cesta.setCestaCode(cestaCode);
        cesta.setCestaCompany(cestaCompany);
        return cesta;

    }

    public static PartenonContract customePartenonContract(String company, String centreStr, String product, String number) {
        PartenonContract partenonContract = new PartenonContract();
        Centre centre = new Centre();
        centre.setCompany(company);
        centre.setCentreCode(centreStr);
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode(product);
        partenonContract.setContractNumber(number);
        return partenonContract;
    }

    public static ServiceInfo generateDefaultServiceInfo() {
        return new ServiceInfo("Status", "Code", "Message");
    }

    public static ServiceInfo generateCustomServiceInfo(String status, String code, String message) {
        ServiceInfo serviceInfo = new ServiceInfo();
        serviceInfo.setStatus(status);
        serviceInfo.setCode(code);
        serviceInfo.setMessage(message);
        return serviceInfo;
    }

    public AccountBalanceControllerRequest generateDefaultRequestAccountBalance() {
        AccountBalanceControllerRequest accountBalanceControllerRequest = new AccountBalanceControllerRequest();

        AccountBalanceDataRequest accountBalanceDataRequest = new AccountBalanceDataRequest();
        accountBalanceDataRequest.setBdpCustomer(generateDefaulBdpCustomer());
        accountBalanceDataRequest.setChannel("INT");
        accountBalanceDataRequest.setCompany("0015");
        ElementList elementList = new ElementList();

        List<Element> element = new ArrayList<>();

        element.add(generateDefaultElement());
        element.add(generateDefaultElement());
        elementList.setElement(element);
        accountBalanceDataRequest.setElementList(elementList);

        accountBalanceControllerRequest.setDataRequest(accountBalanceDataRequest);
        return accountBalanceControllerRequest;
    }

    public AccountBalanceControllerResponse generateDefaultResponseAccountBalance() {
        AccountBalanceControllerResponse accountBalanceControllerResponse = new AccountBalanceControllerResponse();
        accountBalanceControllerResponse.setInfo(generateDefaultServiceInfo());
        AccountBalanceDataResponse dataResponse = new AccountBalanceDataResponse();
        OutElementList outElementList = new OutElementList();
        List<OutElement> outElement = new ArrayList<>();
        outElement.add(generateDefaultOutElement());
        outElement.add(generateDefaultOutElement());
        outElementList.setOutElement(outElement);
        dataResponse.setOutElementList(outElementList);
        accountBalanceControllerResponse.setDataResponse(dataResponse);
        return accountBalanceControllerResponse;
    }

    public BdpCustomer generateDefaulBdpCustomer() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomerCode("123456789");
        bdpCustomer.setBdpCustomertype("F");
        return bdpCustomer;
    }

    public AccountBalanceControllerResponse generateOKResponseAccountBalance() {
        AccountBalanceControllerResponse accountBalanceControllerResponse = new AccountBalanceControllerResponse();
        accountBalanceControllerResponse.setInfo(generateCustomServiceInfo("ok", "", "Data found"));
        AccountBalanceDataResponse dataResponse = new AccountBalanceDataResponse();
        OutElementList outElementList = new OutElementList();
        List<OutElement> outElement = new ArrayList<>();
        outElement.add(generateDefaultOutElement());
        outElement.add(generateDefaultOutElement());
        outElementList.setOutElement(outElement);
        dataResponse.setOutElementList(outElementList);
        accountBalanceControllerResponse.setDataResponse(dataResponse);
        return accountBalanceControllerResponse;
    }

    public AccountBalanceControllerResponse generateNoContractResponseAccountBalance() {
        AccountBalanceControllerResponse accountBalanceControllerResponse = new AccountBalanceControllerResponse();
        accountBalanceControllerResponse.setInfo(generateCustomServiceInfo("ko", "ConsultaSaldoError", "Contract does not exists"));
        AccountBalanceDataResponse dataResponse = new AccountBalanceDataResponse();
        OutElementList outElementList = new OutElementList();
        List<OutElement> outElement = new ArrayList<>();
        outElement.add(generateDefaultOutElement());
        outElement.add(generateDefaultOutElement());
        outElementList.setOutElement(outElement);
        dataResponse.setOutElementList(outElementList);
        accountBalanceControllerResponse.setDataResponse(dataResponse);
        return accountBalanceControllerResponse;
    }

    public AccountBalanceControllerResponse generateKoValidationCestaResponseAccountBalance() {
        AccountBalanceControllerResponse accountBalanceControllerResponse = new AccountBalanceControllerResponse();
        accountBalanceControllerResponse.setInfo(generateCustomServiceInfo("ko", ExceptionValidationEnum.EXC_VAL_CESTA.getErrorCode(), ExceptionValidationEnum.EXC_VAL_CESTA.getErrorMessage()));
        AccountBalanceDataResponse dataResponse = new AccountBalanceDataResponse();
        OutElementList outElementList = new OutElementList();
        List<OutElement> outElement = new ArrayList<>();
        outElement.add(generateDefaultOutElement());
        outElement.add(generateDefaultOutElement());
        outElementList.setOutElement(outElement);
        dataResponse.setOutElementList(outElementList);
        accountBalanceControllerResponse.setDataResponse(dataResponse);
        return accountBalanceControllerResponse;
    }

    public AccountBalanceControllerResponse generateStatus500ResponseAccountBalance() {
        AccountBalanceControllerResponse accountBalanceControllerResponse = new AccountBalanceControllerResponse();
        accountBalanceControllerResponse.setInfo(generateCustomServiceInfo("ko", "500", "Internal Server Error"));
        AccountBalanceDataResponse dataResponse = new AccountBalanceDataResponse();
        OutElementList outElementList = new OutElementList();
        List<OutElement> outElement = new ArrayList<>();
        outElement.add(generateDefaultOutElement());
        outElement.add(generateDefaultOutElement());
        outElementList.setOutElement(outElement);
        dataResponse.setOutElementList(outElementList);
        accountBalanceControllerResponse.setDataResponse(dataResponse);
        return accountBalanceControllerResponse;
    }

    public AccountBalanceControllerResponse generateKOValidationPartenonContract() {
        AccountBalanceControllerResponse accountBalanceControllerResponse = new AccountBalanceControllerResponse();
        accountBalanceControllerResponse.setInfo(generateCustomServiceInfo("ko", "EXC_VAL_PARTENONCONTRACT", "Mandatory Input partenonContract field format is not valid"));
        AccountBalanceDataResponse dataResponse = new AccountBalanceDataResponse();
        OutElementList outElementList = new OutElementList();
        List<OutElement> outElement = new ArrayList<>();
        outElement.add(generateDefaultOutElement());
        outElement.add(generateDefaultOutElement());
        outElementList.setOutElement(outElement);
        dataResponse.setOutElementList(outElementList);
        accountBalanceControllerResponse.setDataResponse(dataResponse);
        return accountBalanceControllerResponse;
    }
}

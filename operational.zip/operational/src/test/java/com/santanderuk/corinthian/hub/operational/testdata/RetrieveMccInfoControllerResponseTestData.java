package com.santanderuk.corinthian.hub.operational.testdata;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.BdpCustomer;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoControllerResponse;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.ioc.io.retrievemccinfo.RetrieveMccInfoDataResponse;

/**
 * Created by c0253129 on 19/12/2017.
 */
public class RetrieveMccInfoControllerResponseTestData {

    public static RetrieveMccInfoControllerResponse get() {

        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("SOME_CUSTOMER_TYPE");

        RetrieveMccInfoDataResponse retrieveMccDataResponse = new RetrieveMccInfoDataResponse();
        retrieveMccDataResponse.setBdpCustomer(bdpCustomer);


        RetrieveMccInfoControllerResponse retrieveMccControllerResponse = new RetrieveMccInfoControllerResponse();
        retrieveMccControllerResponse.setDataResponse(retrieveMccDataResponse);

        return retrieveMccControllerResponse;

    }
}

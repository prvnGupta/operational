package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.validations;


import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.IscCoreApiCommonsBaseTest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.BdpCustomer;
import org.junit.Assert;
import org.junit.Test;


public class ValidationTests extends IscCoreApiCommonsBaseTest {


    @Test
    public void isPartenonContract() {
        Assert.assertTrue(Validations.isPartenonContract(generateDefaultPartenonContract()));
    }

    @Test
    public void isPartenonContract2() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("qwer", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract3() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("!234", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract4() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("123", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract5() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("12345", "0075", "520", "1234567")));
    }

    @Test
    public void isPartenonContract6() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "!234", "520", "1234567")));
    }

    @Test
    public void isPartenonContract7() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "qwer", "520", "1234567")));
    }

    @Test
    public void isPartenonContract8() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "123", "520", "1234567")));
    }

    @Test
    public void isPartenonContract9() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "12345", "520", "1234567")));
    }

    @Test
    public void isPartenonContract10() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "!23", "1234567")));
    }

    @Test
    public void isPartenonContract11() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "qwe", "1234567")));
    }

    @Test
    public void isPartenonContract12() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "12", "1234567")));
    }

    @Test
    public void isPartenonContract13() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "1234", "1234567")));
    }

    @Test
    public void isPartenonContract14() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "!234567")));
    }

    @Test
    public void isPartenonContract15() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "qwertyu")));
    }

    @Test
    public void isPartenonContract16() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "123456")));
    }

    @Test
    public void isPartenonContract17() {
        Assert.assertFalse(Validations.isPartenonContract(customePartenonContract("0015", "0075", "520", "12345678")));
    }

    ////////////////////////////////////
    ///   isChannel                  ///
    ////////////////////////////////////
    @Test
    public void isChannel_null_OK() {
        Assert.assertTrue(Validations.isChannel(null));
    }

    @Test
    public void isChannel_emptyString_KO() {
        Assert.assertFalse(Validations.isChannel(""));
    }

    @Test
    public void isChannel_threeLetters_OK() {
        Assert.assertTrue(Validations.isChannel("OFI"));
    }

    @Test
    public void isChannel_threeNumbers_OK() {
        Assert.assertTrue(Validations.isChannel("123"));
    }

    @Test
    public void isChannel_twoLettersOneNumber_OK() {
        Assert.assertTrue(Validations.isChannel("OF8"));
    }

    @Test
    public void isChannel_oneLetterTwoNumbers_OK() {
        Assert.assertTrue(Validations.isChannel("0F8"));
    }

    @Test
    public void isChannel_oneLetter_KO() {
        Assert.assertFalse(Validations.isChannel("A"));
    }

    @Test
    public void isChannel_twoLetters_KO() {
        Assert.assertFalse(Validations.isChannel("AB"));
    }

    @Test
    public void isChannel_fourLetters_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_oneNumber_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_twoNumbers_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_fourNumbers_KO() {
        Assert.assertFalse(Validations.isChannel("ABCD"));
    }

    @Test
    public void isChannel_specialCharacters_KO() {
        Assert.assertFalse(Validations.isChannel("A£CD"));
    }

    ////////////////////////////////////
    ///   isCompany                  ///
    ////////////////////////////////////
    @Test
    public void isCompany_empty_KO() {
        Assert.assertFalse(Validations.isCompany(""));
    }

    @Test
    public void isCompany_correctCompany_OK() {
        Assert.assertTrue(Validations.isCompany("0015"));
    }

    @Test
    public void isCompany_shorterCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    @Test
    public void isCompany_longerCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    @Test
    public void isCompany_lettersCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    @Test
    public void isCompany_specialCharactersCompany_KO() {
        Assert.assertFalse(Validations.isCompany("123"));
    }

    @Test
    public void isCompany_alphaCompany_KO() {
        Assert.assertFalse(Validations.isCompany("q123"));
    }


    @Test
    public void isBdpCustomer_OK() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("F");
        bdpCustomer.setBdpCustomerCode("123489");
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_OK2() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("F");
        bdpCustomer.setBdpCustomerCode("123456789");
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_OK3() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode("123489");
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_OK4() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode("123456789");
        Assert.assertTrue(Validations.isBdpCustomer(bdpCustomer));

    }

    @Test
    public void isBdpCustomer_empty_KO() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("");
        bdpCustomer.setBdpCustomerCode("");
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode("1234567891");
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO2() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("F");
        bdpCustomer.setBdpCustomerCode("1234567891");
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO3() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("!");
        bdpCustomer.setBdpCustomerCode("123456789");
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO4() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("J");
        bdpCustomer.setBdpCustomerCode("1234567891");
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    @Test
    public void isBdpCustomer_KO5() {
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setBdpCustomertype("Q");
        bdpCustomer.setBdpCustomerCode("23456789");
        Assert.assertFalse(Validations.isBdpCustomer(bdpCustomer));
    }

    ////////////////////////////////////
    ///   isProductSubType           ///
    ////////////////////////////////////
    @Test
    public void isProductSubTypeOK() {
        Assert.assertTrue(Validations.isProductSubtype(customProductSubtype("0015", "300", "719")));
    }

    @Test
    public void isProductSubTypeOK2() {
        Assert.assertTrue(Validations.isProductSubtype(customProductSubtype("0015", "301", "821")));
    }

    @Test
    public void isProductSubTypeKO() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("", "301", "821")));
    }

    @Test
    public void isProductSubTypeKO2() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("123", "301", "821")));
    }

    @Test
    public void isProductSubTypeKO3() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("!234", "301", "821")));
    }

    @Test
    public void isProductSubTypeKO4() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("qwer", "301", "821")));
    }

    @Test
    public void isProductSubTypeKO5() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("12345", "301", "821")));
    }

    @Test
    public void isProductSubTypeKO6() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "31", "821")));
    }

    @Test
    public void isProductSubTypeKO7() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "3112", "821")));
    }

    @Test
    public void isProductSubTypeKO8() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "!23", "821")));
    }

    @Test
    public void isProductSubTypeKO9() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "qwe", "821")));
    }

    @Test
    public void isProductSubTypeKO10() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "123", "12")));
    }

    @Test
    public void isProductSubTypeKO11() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "123", "1234")));
    }

    @Test
    public void isProductSubTypeKO12() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "123", "qwe")));
    }

    @Test
    public void isProductSubTypeKO13() {
        Assert.assertFalse(Validations.isProductSubtype(customProductSubtype("1234", "123", "!23")));
    }

    ////////////////////////////////////
    ///   isCesta                    ///
    ////////////////////////////////////
    @Test
    public void isCestaOK() {
        Assert.assertTrue(Validations.isCesta(customCesta("0015", "BIAC")));
    }

    @Test
    public void isCestaKO() {
        Assert.assertFalse(Validations.isCesta(null));
    }

    @Test
    public void isCestaKO1() {
        Assert.assertFalse(Validations.isCesta(customCesta("", "")));
    }

    @Test
    public void isCestaKO2() {
        Assert.assertFalse(Validations.isCesta(customCesta("0015", "")));
    }

    @Test
    public void isCestaKO3() {
        Assert.assertFalse(Validations.isCesta(customCesta("", "BIAC")));
    }

    @Test
    public void isCestaKO4() {
        Assert.assertFalse(Validations.isCesta(customCesta("0015", "!234")));
    }

    @Test
    public void isCestaKO5() {
        Assert.assertFalse(Validations.isCesta(customCesta("123", "BIAC")));
    }

    @Test
    public void isCestaKO6() {
        Assert.assertFalse(Validations.isCesta(customCesta("12345", "BIAC")));
    }

    @Test
    public void isCestaKO7() {
        Assert.assertFalse(Validations.isCesta(customCesta("qwer", "BIAC")));
    }

    @Test
    public void isCestaKO8() {
        Assert.assertFalse(Validations.isCesta(customCesta("!123", "BIAC")));
    }


}

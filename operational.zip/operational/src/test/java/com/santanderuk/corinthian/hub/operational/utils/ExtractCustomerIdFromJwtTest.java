package com.santanderuk.corinthian.hub.operational.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ExtractCustomerIdFromJwtTest {

    ExtractCustomerIdFromJwt service;

    @BeforeEach
    void setUp() {
        service = new ExtractCustomerIdFromJwt();
    }

    @Test
    void shouldReturnCustomerIdZeroLeftPadded() {
        String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

        String customerId = service.getCustomerIdZeroLeftPadded(jwtWithCustomer554);
        Assertions.assertEquals("F000000554", customerId);
    }
}

package com.santanderuk.corinthian.hub.operational.controller;

import com.santanderuk.corinthian.hub.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.customersegment.DataResponse;
import com.santanderuk.corinthian.hub.operational.services.customersegment.CustomerSegmentServiceInterface;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.anyString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@WebMvcTest(controllers = CustomerSegmentController.class)
@AutoConfigureMockMvc(addFilters = false)
@ActiveProfiles("test")
public class CustomerSegmentControllerTest {

    @Autowired
    MockMvc mockMvc;

    @MockBean
    private CustomerSegmentServiceInterface customerSegmentService;

    private String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";


    @Test
    public void shouldReturnCustomerServiceControllerResponse_CaseOK_personalBanking() throws Exception {
        Mockito.when(customerSegmentService.getCustomerSegment(anyString(), anyString())).thenReturn(generateCustomerSegmentServiceResponseOkPersonalBanking());

        mockMvc.perform(get("/customer/pgwe51ZD")
                .header("Authorization", jwtToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.status", is("200")))
                .andExpect(jsonPath("$.dataResponse.segmentCode", is("PD")))
                .andExpect(jsonPath("$.dataResponse.segmentName", is("PERSONAL")));
    }

    @Test
    public void shouldReturnCustomerServiceControllerResponse_CaseOK_privateBanking() throws Exception {
        Mockito.when(customerSegmentService.getCustomerSegment(anyString(), anyString())).thenReturn(generateCustomerSegmentServiceResponseOkPrivateBanking());
        mockMvc.perform(get("/customer/pgwe51ZD")
                .header("authorization", jwtToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.status", is("200")))
                .andExpect(jsonPath("$.dataResponse.segmentCode", is("PB")))
                .andExpect(jsonPath("$.dataResponse.segmentName", is("PRIVATE BANKING")));
    }

    @Test
    public void shouldReturnCustomerServiceControllerResponse_CaseOK_select() throws Exception {
        Mockito.when(customerSegmentService.getCustomerSegment(anyString(), anyString())).thenReturn(generateCustomerSegmentServiceResponseOkSelect());
        mockMvc.perform(get("/customer/pgwe51ZD")
                .header("authorization", jwtToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.status", is("200")))
                .andExpect(jsonPath("$.dataResponse.segmentCode", is("PI")))
                .andExpect(jsonPath("$.dataResponse.segmentName", is("SELECT")));
    }

    @Test
    public void shouldReturnCustomerServiceControllerResponse_CaseKO_ReturnDefaultPBProfile() throws Exception {
        Mockito.when(customerSegmentService.getCustomerSegment(anyString(), anyString())).thenThrow(GeneralException.class);
        mockMvc.perform(get("/customer/pgwe51ZD")
                .header("authorization", jwtToken)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.info.status", is("200")))
                .andExpect(jsonPath("$.info.code", is("")))
                .andExpect(jsonPath("$.info.message", is("")))
                .andExpect(jsonPath("$.dataResponse.segmentCode", is("PD")))
                .andExpect(jsonPath("$.dataResponse.segmentName", is("PERSONAL")));
    }

    private DataResponse generateCustomerSegmentServiceResponseOkPersonalBanking() {
        DataResponse dataResponse = new DataResponse();
        dataResponse.setSegmentCode("PD");
        dataResponse.setSegmentName("PERSONAL");
        return dataResponse;
    }

    private DataResponse generateCustomerSegmentServiceResponseOkSelect() {
        DataResponse dataResponse = new DataResponse();
        dataResponse.setSegmentCode("PI");
        dataResponse.setSegmentName("SELECT");
        return dataResponse;
    }

    private DataResponse generateCustomerSegmentServiceResponseOkPrivateBanking() {
        DataResponse dataResponse = new DataResponse();
        dataResponse.setSegmentCode("PB");
        dataResponse.setSegmentName("PRIVATE BANKING");
        return dataResponse;
    }
}

package com.santanderuk.corinthian.hub.operational.functional;

import com.jayway.restassured.response.Header;
import org.junit.Before;
import org.junit.Test;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class CustomerSegmentFunctionalTests extends FunctionalTest {

    String customerSegmentBaseUrl;
    Header header;

    @Before
    public void setup() {
        customerSegmentBaseUrl = String.format("http://localhost:%s/operational/customer", serverPort);
        header = new Header("authorization", jwtAuth);
    }

    @Test
    public void testWeGetCustomerSegmentPI() {

        stubCoreCustomerProfileSuccessPI();
        stubCoreCustomersInformation();

        given().
                header(header).
                when().
                get(customerSegmentBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("200"),
                        "info.code", equalTo(""),
                        "info.message", equalTo(""),
                        "dataResponse.segmentCode", equalTo("PI"),
                        "dataResponse.segmentName", equalTo("SELECT")
                );
    }

    @Test
    public void testWeGetCustomerSegmentPD() {
        stubCoreCustomerProfileSuccessPD();
        stubCoreCustomersInformation();

        given().
                header(header).
                when().
                get(customerSegmentBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("200"),
                        "info.code", equalTo(""),
                        "info.message", equalTo(""),
                        "dataResponse.firstName", equalTo("Kakaroto-Goku-San"),
                        "dataResponse.lastName", equalTo("Harris"),
                        "dataResponse.segmentCode", equalTo("PD"),
                        "dataResponse.segmentName", equalTo("PERSONAL")
                );
    }

    @Test
    public void shouldReturn500WhenCustomersApiIsDown() {
        stubCoreCustomerProfileSuccessPD();
        stubCoreCustomersInformationApiDown();

        given().
                header(header).
                when().
                get(customerSegmentBaseUrl + "/6x1WB78G").
                then().
                statusCode(500).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("CUSTOMER_INFORMATION_CLIENT_EXC"),
                        "info.message", equalTo("Exception while calling Customer Information Api: ")
                );
    }

    @Test
    public void testWeGetCustomerSegmentPB() {

        stubCoreCustomerProfileSuccessPB();
        stubCoreCustomersInformation();

        given().
                header(header).
                when().
                get(customerSegmentBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("200"),
                        "info.code", equalTo(""),
                        "info.message", equalTo(""),
                        "dataResponse.segmentCode", equalTo("PB"),
                        "dataResponse.segmentName", equalTo("PRIVATE BANKING")
                );
    }

    @Test
    public void testGetCustomerSegment_ErrorOnCoreService_returnsDefaultProfile() {

        stubCoreCustomerProfileUnknownError();
        stubCoreCustomersInformation();

        given().
                header(header).
                when().
                get(customerSegmentBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("200"),
                        "info.code", equalTo(""),
                        "info.message", equalTo(""),
                        "dataResponse.segmentCode", equalTo("PD"),
                        "dataResponse.segmentName", equalTo("PERSONAL")
                );
    }

    @Test
    public void testUIDVerifier_returnsUnauthorised() {

        given().
                header(header).
                when().
                get(customerSegmentBaseUrl + "/diffLdapUid").
                then().
                statusCode(401).
                and().
                body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("EXC_SEC_NO_VALID_TOKEN"),
                        "info.message", equalTo("Authorization Token received is not valid"),
                        "dataResponse.segmentCode", equalTo(""),
                        "dataResponse.segmentName", equalTo("")
                );
    }

    @Test
    public void testGetCustomerSegment_UnauthorisedErrorOnCoreService_returnsDefaultProfile() {

        stubCoreCustomerProfileUnauthorisedError();
        stubCoreCustomersInformation();

        given().
                header(header).
                when().
                get(customerSegmentBaseUrl + "/6x1WB78G").
                then().
                statusCode(200).
                and().
                body(
                        "info.status", equalTo("200"),
                        "info.code", equalTo(""),
                        "info.message", equalTo(""),
                        "dataResponse.segmentCode", equalTo("PD"),
                        "dataResponse.segmentName", equalTo("PERSONAL")
                );
    }
}

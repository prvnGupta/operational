package com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.utilities;

import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.IscCoreApiCommonsBaseTest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.GeneralException;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.exceptions.business.ExcBusIsc;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.AccountBalanceControllerRequest;
import com.santanderuk.corinthian.hub.operational.model.core.bksconnect.isc.io.AccountBalanceControllerResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.mock;

public class ISCConnectionTest extends IscCoreApiCommonsBaseTest {

    @MockBean
    RestTemplate restTemplate;

    @InjectMocks
    @Spy
    ISCConnection iscConnection;

    @Before
    public void setUp() {

        restTemplate = mock(RestTemplate.class);

        //inject mocks
        MockitoAnnotations.initMocks(this);
    }

//    @Test
//    public void testDefault () throws GeneralException {
//
//        AccountBalanceControllerRequest accountBalanceControllerRequest = generateDefaultRequestAccountBalance();
//
//        AccountBalanceControllerResponse accountBalanceControllerResponse = generateDefaultResponseAccountBalance();
//        ResponseEntity<AccountBalanceControllerResponse> responseEntity
//                = new ResponseEntity<>(accountBalanceControllerResponse, HttpStatus.OK);
//
//        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(AccountBalanceControllerResponse.class)))
//                .thenReturn(responseEntity);
//
//        AccountBalanceControllerResponse response = iscConnection.accountBalance("/any/url",accountBalanceControllerRequest,"jwt");
//
//        assertEquals("Status", response.getInfo().getStatus());
//        assertEquals("Code", response.getInfo().getCode());
//        assertEquals("Message", response.getInfo().message());
//
//    }

    @Test
    public void testHappyPath() throws GeneralException {

        AccountBalanceControllerRequest accountBalanceControllerRequest = generateDefaultRequestAccountBalance();

        AccountBalanceControllerResponse accountBalanceControllerResponse = generateOKResponseAccountBalance();
        ResponseEntity<AccountBalanceControllerResponse> responseEntity
                = new ResponseEntity<>(accountBalanceControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(AccountBalanceControllerResponse.class)))
                .thenReturn(responseEntity);

        AccountBalanceControllerResponse response = iscConnection.accountBalance("/any/url", accountBalanceControllerRequest, "jwt", "clientId");

        assertEquals("ok", response.getInfo().getStatus());
        assertEquals("", response.getInfo().getCode());
        assertEquals("Data found", response.getInfo().getMessage());
    }

//    @Test
//    public void testNonExistentContract () throws GeneralException {
//
//        AccountBalanceControllerRequest accountBalanceControllerRequest = generateDefaultRequestAccountBalance();
//
//        AccountBalanceControllerResponse accountBalanceControllerResponse = generateNoContractResponseAccountBalance();
//        ResponseEntity<AccountBalanceControllerResponse> responseEntity
//                = new ResponseEntity<>(accountBalanceControllerResponse, HttpStatus.OK);
//
//        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(AccountBalanceControllerResponse.class)))
//                .thenReturn(responseEntity);
//
//        AccountBalanceControllerResponse response = iscConnection.accountBalance("/any/url",accountBalanceControllerRequest,"jwt");
//
//        assertEquals("ko", response.getInfo().getStatus());
//        assertEquals("ConsultaSaldoError", response.getInfo().getCode());
//        assertEquals("Contract does not exists", response.getInfo().message());
//
//    }

    @Test(expected = GeneralException.class)
    public void testGeneralException() throws GeneralException {
        AccountBalanceControllerRequest accountBalanceControllerRequest = generateDefaultRequestAccountBalance();
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(AccountBalanceControllerResponse.class)))
                .thenThrow(RestClientException.class);
        iscConnection.accountBalance("/any/url", accountBalanceControllerRequest, "jwt", "clientId");
    }

    @Test(expected = ExcBusIsc.class)
    public void testIscBusExc() throws GeneralException {

        AccountBalanceControllerRequest accountBalanceControllerRequest = generateDefaultRequestAccountBalance();

        AccountBalanceControllerResponse accountBalanceControllerResponse = generateStatus500ResponseAccountBalance();
        ResponseEntity<AccountBalanceControllerResponse> responseEntity
                = new ResponseEntity<>(accountBalanceControllerResponse, HttpStatus.INTERNAL_SERVER_ERROR);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(AccountBalanceControllerResponse.class)))
                .thenReturn(responseEntity);

        iscConnection.accountBalance("/any/url", accountBalanceControllerRequest, "jwt", "clientId");
    }

    @Test(expected = ExcBusIsc.class)
    public void testErrorInInfoObjectInsideResponse() throws GeneralException {

        AccountBalanceControllerRequest accountBalanceControllerRequest = generateDefaultRequestAccountBalance();

        AccountBalanceControllerResponse accountBalanceControllerResponse = generateKOValidationPartenonContract();

        ResponseEntity<AccountBalanceControllerResponse> responseEntity
                = new ResponseEntity<>(accountBalanceControllerResponse, HttpStatus.OK);

        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(AccountBalanceControllerResponse.class)))
                .thenReturn(responseEntity);

        AccountBalanceControllerResponse response = iscConnection.accountBalance("/any/url", accountBalanceControllerRequest, "jwt", "clientId");
    }
}

package com.santanderuk.corinthian.hub.operational.functional;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Header;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;

import static org.hamcrest.CoreMatchers.equalTo;

public class DirectDebitAccountsControllerTest extends FunctionalTest {

    String directDebitAccountsUrl;
    Header header;

    @Before
    public void setup() {
        directDebitAccountsUrl = String.format("http://localhost:%s/operational/{ldapUid}/direct-debit-internal-accounts", serverPort);
        header = new Header("authorization", jwtAuth);
    }

    @Test
    public void shouldReturnDirectDebitEligibleAccounts() {

        stubCustomerAccessEntitlementApi();
        stubAccountBalancesService();

        RestAssured.given()
                .header(header)
                .when()
                .get(directDebitAccountsUrl.replaceFirst("\\{ldapUid}", "6x1WB78G"))
                .then().statusCode(200)
                .and().body(
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found"),
                        "directDebitAccounts.accounts[0].sortCode", equalTo("090126"),
                        "directDebitAccounts.accounts[0].accountNumber", equalTo("55177871"),
                        "directDebitAccounts.accounts[0].alias", equalTo("EVERYDAY CURRENT ACCOUNT"),
                        "directDebitAccounts.accounts[0].balance", equalTo(new BigDecimal("490.00")),
                        "directDebitAccounts.accounts[0].balanceIncPending", equalTo(new BigDecimal("190.00")),
                        "directDebitAccounts.accounts[0].currency", equalTo("GBP"),
                        "directDebitAccounts.accounts[1].sortCode", equalTo("090126"),
                        "directDebitAccounts.accounts[1].accountNumber", equalTo("50357476"),
                        "directDebitAccounts.accounts[1].alias", equalTo("ZERO CURRENT ACCOUNT"),
                        "directDebitAccounts.accounts[1].balance", equalTo(new BigDecimal("4550.31")),
                        "directDebitAccounts.accounts[1].balanceIncPending", equalTo(new BigDecimal("-4250.31")),
                        "directDebitAccounts.accounts[1].currency", equalTo("GBP")
                );
    }

    @Test
    public void shouldReturnNoDirectDebitEligibleAccount() {

        stubCustomerAccessEntitlementApiNoEligibleAccount();

        RestAssured.given()
                .header(header)
                .when()
                .get(directDebitAccountsUrl.replaceFirst("\\{ldapUid}", "6x1WB78G"))
                .then().statusCode(200)
                .and().body(
                        "info.status", equalTo("ko"),
                        "info.message", equalTo("No eligible direct debit account found"),
                        "directDebitAccounts", equalTo(null)
                );
    }

    @Test
    public void shouldReturnGeneralException() {

        RestAssured.given()
                .header(header)
                .when()
                .get(directDebitAccountsUrl.replaceFirst("\\{ldapUid}", "6x1WB78G"))
                .then().statusCode(500)
                .and().body(
                        "info.status", equalTo("ko"),
                        "info.message", equalTo("Customer-access-entitlement service did not respond correctly"),
                        "directDebitAccounts", equalTo(null)
                );
    }

    @Test
    public void shouldReturnUnauthorised401() {
        RestAssured.given()
                .header(header)
                .when()
                .get(directDebitAccountsUrl.replaceFirst("\\{ldapUid}", "wrong_ldap_uid"))
                .then().statusCode(401)
                .and().body(
                        "info.status", equalTo("ko"),
                        "info.message", equalTo("Authorization Token received is not valid")
                );
    }
}

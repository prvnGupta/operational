package com.santanderuk.corinthian.hub.operational.functional;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;


@ActiveProfiles("test")
public class HealthFunctionalTest extends FunctionalTest {

    String healthUrl;
    String healthzUrl;

    @Before
    public void setup() {
        healthUrl = String.format("http://localhost:%s/operational/health", serverPort);
        healthzUrl = String.format("http://localhost:%s/operational/healthz", serverPort);
    }

    @Test
    public void customHealthReturnsUp() throws Exception {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));
    }

    @Test
    public void customHealthZReturnsUp() throws Exception {

        given().
                when().
                get(healthzUrl).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));
    }

}
